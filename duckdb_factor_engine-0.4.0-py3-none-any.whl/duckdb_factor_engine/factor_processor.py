#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
因子处理函数 - 复刻自 duckdb_ic_engine

提供三个独立的因子处理函数：
- fill_na(): 缺失值填充
- winsorize(): 去极值
- normalize(): 标准化

使用示例：
    from duckdb_factor_engine import fill_na, winsorize, normalize
    
    # 1. 缺失值填充
    factor_filled = fill_na(factor_data, method={'median': ['TURNOVER_1M']})
    
    # 2. 去极值
    factor_winsorized = winsorize(factor_filled, std=3.0, method='mad')
    
    # 3. 标准化
    factor_normalized = normalize(factor_winsorized, method='zscore')
"""

from typing import Dict, List, Union, Literal
import pandas as pd
import numpy as np
from scipy.stats import rankdata


def fill_na(
    factor_data: Union[pd.Series, pd.DataFrame, Dict[str, pd.Series]],
    method: Dict[str, List[str]],
    window: int = 20
) -> Union[pd.Series, pd.DataFrame]:
    """
    缺失值填充
    
    完全复刻自 duckdb_ic_engine.FactorProcessor.fill_na
    
    支持的填充方法：
    - 'zero': 填充0
    - 'median': 截面中位数填充
    - 'median_20d': 前20日滚动中位数填充
    - 'mean_20d': 前20日滚动均值填充
    
    Args:
        factor_data: 因子数据，可以是 Series、DataFrame 或 Dict
        method: 填充方法配置，格式为 {方法名: [因子名列表]}
            例如：{'median': ['TURNOVER_1M'], 'zero': ['RETURN_12M']}
        window: 滚动窗口天数，默认20
        
    Returns:
        填充后的因子数据，类型与输入一致
        
    Examples:
        >>> # 单因子填充
        >>> filled = fill_na(factor_series, method={'median': ['factor1']})
        
        >>> # 多因子不同方法填充
        >>> filled = fill_na(
        ...     factor_df,
        ...     method={
        ...         'median': ['TURNOVER_1M', 'TURNOVER_3M'],
        ...         'zero': ['RETURN_12M'],
        ...         'median_20d': ['ATR_1M']
        ...     }
        ... )
    """
    # 处理 Series 输入
    if isinstance(factor_data, pd.Series):
        col_name = factor_data.name if factor_data.name else 'factor'
        factor_data = pd.DataFrame({col_name: factor_data})
        is_series = True
    else:
        is_series = False
    
    # 处理 Dict 输入
    if isinstance(factor_data, dict):
        factor_data = pd.DataFrame(factor_data)
    
    result = factor_data.copy()
    
    for fill_method, factor_list in method.items():
        if not factor_list:
            continue
        
        for factor_name in factor_list:
            if factor_name not in result.columns:
                continue
            
            col_data = result[factor_name]
            
            if fill_method == 'zero':
                # 填充0
                result[factor_name] = col_data.fillna(0)
            
            elif fill_method == 'median':
                # 截面中位数填充
                result[factor_name] = col_data.fillna(col_data.median())
            
            elif fill_method == 'median_20d':
                # 前20日滚动中位数填充（向量化优化）
                # 用前 window 天的滚动中位数填充 NaN，已有值保持不变
                rolling_median = col_data.rolling(window, min_periods=1).median().shift(1)
                result[factor_name] = col_data.fillna(rolling_median).fillna(0)
            
            elif fill_method == 'mean_20d':
                # 前20日滚动均值填充（向量化优化）
                rolling_mean = col_data.rolling(window, min_periods=1).mean().shift(1)
                result[factor_name] = col_data.fillna(rolling_mean).fillna(0)
            
            else:
                raise ValueError(
                    f"未知的填充方法: {fill_method}, "
                    f"请使用 'zero', 'median', 'median_20d' 或 'mean_20d'"
                )
    
    if is_series:
        return result.iloc[:, 0]
    
    return result


def winsorize(
    factor_data: Union[pd.Series, pd.DataFrame],
    std: float = 3.0,
    method: Literal['mad', 'std'] = 'mad'
) -> Union[pd.Series, pd.DataFrame]:
    """
    去极值（Winsorization）
    
    完全复刻自 duckdb_ic_engine.FactorProcessor.winsorize
    
    支持的去极值方法：
    - 'mad': 中位数绝对偏差方法（默认，更稳健）
    - 'std': 标准差方法
    
    Args:
        factor_data: 因子数据，Series 或 DataFrame
        std: 标准差倍数，默认3.0
        method: 去极值方法，'mad' 或 'std'
        
    Returns:
        去极值后的因子数据，类型与输入一致
        
    Examples:
        >>> # 使用 MAD 方法
        >>> winsorized = winsorize(factor_data, std=3.0, method='mad')
        
        >>> # 使用标准差方法
        >>> winsorized = winsorize(factor_data, std=2.5, method='std')
    """
    if method == 'mad':
        return _winsorize_mad(factor_data, std)
    elif method == 'std':
        return _winsorize_std(factor_data, std)
    else:
        raise ValueError(f"未知的去极值方法: {method}，请使用 'mad' 或 'std'")


def _winsorize_mad(
    factor_data: Union[pd.Series, pd.DataFrame],
    std: float
) -> Union[pd.Series, pd.DataFrame]:
    """使用 MAD（中位数绝对偏差）方法去极值"""
    if isinstance(factor_data, pd.DataFrame):
        return factor_data.apply(lambda col: _winsorize_mad(col, std), axis=0)
    
    median = factor_data.median()
    mad = (factor_data - median).abs().median()
    
    if mad == 0:
        return factor_data
    
    lower = median - std * mad
    upper = median + std * mad
    
    return factor_data.clip(lower=lower, upper=upper)


def _winsorize_std(
    factor_data: Union[pd.Series, pd.DataFrame],
    std: float
) -> Union[pd.Series, pd.DataFrame]:
    """使用标准差方法去极值"""
    if isinstance(factor_data, pd.DataFrame):
        return factor_data.apply(lambda col: _winsorize_std(col, std), axis=0)
    
    mean = factor_data.mean()
    std_dev = factor_data.std()
    
    if std_dev == 0 or pd.isna(std_dev):
        return factor_data
    
    lower = mean - std * std_dev
    upper = mean + std * std_dev
    
    return factor_data.clip(lower=lower, upper=upper)


def normalize(
    factor_data: Union[pd.Series, pd.DataFrame],
    method: Literal['zscore', 'rank'] = 'zscore'
) -> Union[pd.Series, pd.DataFrame]:
    """
    标准化
    
    完全复刻自 duckdb_ic_engine.FactorProcessor.normalize
    
    支持的标准化方法：
    - 'zscore': Z-score标准化，均值0标准差1
    - 'rank': 排名标准化，映射到0-1均匀分布
    
    Args:
        factor_data: 因子数据，Series 或 DataFrame
        method: 标准化方法，'zscore' 或 'rank'
        
    Returns:
        标准化后的因子数据，类型与输入一致
        
    Examples:
        >>> # Z-score 标准化
        >>> normalized = normalize(factor_data, method='zscore')
        
        >>> # 排名标准化
        >>> normalized = normalize(factor_data, method='rank')
    """
    if isinstance(factor_data, pd.DataFrame):
        return factor_data.apply(lambda col: normalize(col, method=method), axis=0)
    
    if method == 'zscore':
        mean = factor_data.mean()
        std = factor_data.std()
        if std == 0 or pd.isna(std):
            return pd.Series([0] * len(factor_data), index=factor_data.index)
        return (factor_data - mean) / std
    
    elif method == 'rank':
        ranks = rankdata(factor_data, method='average')
        return pd.Series(ranks / len(factor_data), index=factor_data.index)
    
    else:
        raise ValueError(f"未知的标准化方法: {method}，请使用 'zscore' 或 'rank'")


# 便捷函数：完整处理流水线
def process_factor(
    factor_data: Union[pd.Series, pd.DataFrame],
    factor_names: List[str],
    fill_method: str = 'median',
    winsorize_std: float = 3.0,
    winsorize_method: Literal['mad', 'std'] = 'mad',
    normalize_method: Literal['zscore', 'rank'] = 'zscore',
    window: int = 20
) -> pd.DataFrame:
    """
    因子处理完整流水线
    
    流程：fill_na → winsorize → normalize
    
    Args:
        factor_data: 因子数据 DataFrame
        factor_names: 要处理的因子名称列表
        fill_method: 填充方法
        winsorize_std: 去极值倍数
        winsorize_method: 去极值方法
        normalize_method: 标准化方法
        window: 滚动窗口天数
        
    Returns:
        处理后的因子 DataFrame
        
    Examples:
        >>> processed = process_factor(
        ...     factor_df,
        ...     factor_names=['TURNOVER_1M', 'ATR_1M'],
        ...     fill_method='median',
        ...     winsorize_std=3.0,
        ...     normalize_method='zscore'
        ... )
    """
    result = pd.DataFrame(index=factor_data.index)
    
    for factor_name in factor_names:
        if factor_name not in factor_data.columns:
            continue
        
        factor_series = factor_data[factor_name]

        # 1. 填充
        factor_filled = fill_na(
            factor_series.rename(factor_name),
            method={fill_method: [factor_name]},
            window=window
        )
        
        # 2. 去极值
        factor_winsorized = winsorize(
            factor_filled,
            std=winsorize_std,
            method=winsorize_method
        )
        
        # 3. 标准化
        factor_normalized = normalize(factor_winsorized, method=normalize_method)
        
        result[factor_name] = factor_normalized
    
    return result
