#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
因子生成标准模板 - duckdb_factor_engine v0.2.25

====================================================================
  并行架构：分批线程并行（每批最多 24 并发）
====================================================================
  - 主进程：一次性预计算所有财务共享数据（约 30 秒）
  - 分批处理：每批最多 50 个因子，每个因子一个线程（最多 24 并发）
  - 每个线程独立 DuckDB 连接（4GB 内存，单线程）
  - 每个线程对自己的每个因子：
      → SQL 一次性覆盖 start_dt ~ end_dt 全区间
      → 保存为 {因子名}.parquet
  - 每批内最多 24 个因子同时计算，避免连接数超过系统临界点
  - merge 阶段：Polars 分批 melt 宽表→长表，concat 后排序写出，
    全程内存安全（~100MB/因子，210 因子峰值 ~36GB）

====================================================================
  使用方法（两步）：
====================================================================
  1. 复制本文件到你的工作目录（如 ./run_factors.py）
  2. 修改下方【用户配置区】的 5 个参数，然后运行：
       python run_factors.py

====================================================================
  并行架构：因子并行（每个因子一次性算完全程）
====================================================================
  - 主进程：一次性预计算所有财务共享数据（约 30 秒）
  - spawn n 个 worker，每个 worker 分配约 m/n 个因子
  - 每个 worker 对自己的每个因子：
      → SQL 一次性覆盖 start_dt ~ end_dt 全区间
      → 保存为 {因子名}.parquet
  - n 个 worker 真正同时工作（各自计算不同因子，无 I/O 竞争）
  - 无日期串行——每个因子一次性算完全程
  - merge 阶段：Polars 分批 melt 宽表→长表，concat 后排序写出，
    全程内存安全（~100MB/因子，210 因子峰值 ~36GB）

====================================================================
  模板参数说明（只需要修改【用户配置区】）：
====================================================================
  DATA_DIR    → 数据目录（包含 daily_hfq/, daily_basic/ 等子目录）
  OUTPUT_DIR  → 输出目录（运行后生成 _worker_N/ 和 factors_all.parquet）
  START_DATE  → 起始日期，格式 YYYYMMDD
  END_DATE    → 结束日期，格式 YYYYMMDD
  N_WORKERS   → 并行 worker 数量（建议：可用内存 64GB → 4，128GB → 8）
  FACTOR_SCOPE → 'all'（全部已启用因子）
                或 'valuation' / 'momentum' 等类别名
                或 ['BP', 'TTM_EP', ...] 自定义因子列表

====================================================================
"""

# ============================================================
# ============ 用户配置区（复制后修改这里）====================
# ============================================================

DATA_DIR = '/root/lqq_bot_workspace/data'
OUTPUT_DIR = '/tmp/factor_output'
START_DATE = '20240101'
END_DATE = '20241231'
N_WORKERS = 4
FACTOR_SCOPE = 'all'

# ============================================================
# ============ 以下代码不需要修改 =============================
# ============================================================

import os
import sys
import math
import shutil
import signal
import logging
import multiprocessing as mp
from pathlib import Path
from datetime import datetime

# ── 包路径设置 ────────────────────────────────────────────
_TEMPLATE_DIR = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(_TEMPLATE_DIR) == 'duckdb_factor_engine':
    _PACKAGE_DIR = _TEMPLATE_DIR
else:
    import duckdb_factor_engine as _pkg
    _PACKAGE_DIR = os.path.dirname(os.path.abspath(_pkg.__file__))
sys.path.insert(0, _PACKAGE_DIR)

# ── 日志（兼容 nohup）─────────────────────────────────────
_logger = logging.getLogger()
if not _logger.handlers:
    _h = logging.StreamHandler(sys.stdout)
    _h.setFormatter(logging.Formatter(
        '%(asctime)s [%(levelname)s] %(message)s', datefmt='%H:%M:%S'))
    _logger.addHandler(_h)
    _logger.setLevel(logging.INFO)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S',
    force=True,
)
logger = logging.getLogger('factor_template')

# ── 忽略 SIGTERM（防止 Ctrl+C 误杀子进程）────────────────
signal.signal(signal.SIGTERM, signal.SIG_IGN)

# ── 配置导入 ─────────────────────────────────────────────
def _import_config():
    try:
        import duckdb_factor_engine.config as _cfg
        return _cfg.get_factor_names, _cfg.get_factors_by_category, _cfg.get_factor_config
    except ImportError:
        from config import get_factor_names, get_factors_by_category, get_factor_config
        return get_factor_names, get_factors_by_category, get_factor_config

get_factor_names, get_factors_by_category, get_factor_config = _import_config()


# ── 因子列表解析 ─────────────────────────────────────────
def resolve_factor_list(scope):
    if scope == 'all':
        return get_factor_names(enabled_only=True)
    elif isinstance(scope, str):
        factors = get_factors_by_category(scope)
        if not factors:
            raise ValueError(
                f"类别 '{scope}' 无已启用因子或不存在。"
                f"可用: valuation/momentum/liquidity/volatility/moneyflow/financial/technical"
            )
        return factors
    elif isinstance(scope, (list, tuple)):
        all_enabled = set(get_factor_names(enabled_only=True))
        for f in scope:
            if f not in all_enabled:
                raise ValueError(f"因子 '{f}' 不在已启用列表中")
        return list(scope)
    else:
        raise ValueError(f"FACTOR_SCOPE 类型不支持: {type(scope)}")


# ── 注册数据视图 ─────────────────────────────────────────
def _register_views(con, data_dir):
    views = {
        'prices':               data_dir + '/daily_hfq',
        'daily_basic':          data_dir + '/daily_basic',
        'moneyflow':            data_dir + '/moneyflow',
        'stk_holdernumber':     data_dir + '/stk_holdernumber',
        'stk_factor_pro':       data_dir + '/stk_factor_pro',
        'income_vip':           data_dir + '/income',
        'income_raw':           data_dir + '/income',
        'fina_indicator':      data_dir + '/fina_indicator',
        'fina_cashflow_vip':    data_dir + '/fina_cashflow_vip',
        'fina_balancesheet_vip': data_dir + '/fina_balancesheet',
        'fina_audit':          data_dir + '/fina_audit',
        'dividend':             data_dir + '/dividend',
        'top10_holders':        data_dir + '/top10_holders',
        'top10_floatholders':   data_dir + '/top10_floatholders',
        'stk_holdertrade':      data_dir + '/stk_holdertrade',
        'stk_repurchase':       data_dir + '/stk_repurchase',
        'express':              data_dir + '/express',
        'broker_recommend':     data_dir + '/broker_recommend',
        'hk_hold':             data_dir + '/hk_hold',
        'top_list':             data_dir + '/top_list',
        'stk_limit':            data_dir + '/stk_limit',
        'suspend_d':            data_dir + '/suspend_d.parquet',
        'index_weight':         data_dir + '/index_weight',
        'block_trade':          data_dir + '/block_trade',
    }
    for name, path in views.items():
        if os.path.exists(path):
            pattern = path + '/*.parquet' if os.path.isdir(path) else path
            try:
                con.execute(
                    f"CREATE OR REPLACE VIEW {name} AS "
                    f"SELECT * FROM read_parquet('{pattern}')"
                )
            except Exception:
                pass


# ── Worker 函数 ───────────────────────────────────────────
def _worker_compute(args):
    """
    每个线程的计算逻辑（独立 DuckDB 连接）：
      1. 建立独立 DuckDB 连接（2GB 内存，2 线程）
      2. 注册原始数据视图
      3. 注册 prep 表视图（从 parquet 文件加载）
      4. 对自己的每个因子：
         - 格式化 SQL（一次性覆盖 start_dt ~ end_dt）
         - 执行 SQL，保存 {因子名}.parquet
      5. 返回 (worker_id, [(因子名, 行数, 耗时), ...], [(因子名, 错误), ...])
    """
    wid, factor_names, start_dt, end_dt, output_dir, data_dir, prep_parquet_paths = args

    import duckdb
    from pathlib import Path as P
    from datetime import datetime, timedelta

    con = duckdb.connect()
    con.execute("SET threads = 1")
    con.execute("SET memory_limit = '4GB'")

    # 注册原始数据视图
    _register_views(con, data_dir)

    # 注册 prep 表视图（从 parquet 文件加载）
    for view_name, parquet_path in prep_parquet_paths.items():
        if os.path.exists(parquet_path):
            try:
                con.execute(
                    f"CREATE OR REPLACE VIEW {view_name} AS "
                    f"SELECT * FROM read_parquet('{parquet_path}')"
                )
            except Exception:
                pass

    computed = []
    failed = []

    for fname in factor_names:
        cfg = get_factor_config(fname)
        if cfg is None or not cfg.get('enabled', True):
            continue

        # 财务因子需要更早的起始日期
        dt_start = datetime.strptime(start_dt, '%Y%m%d')
        start_dt_20d = (dt_start - timedelta(days=30)).strftime('%Y%m%d')
        start_dt_60d = (dt_start - timedelta(days=90)).strftime('%Y%m%d')
        start_dt_2y  = (dt_start - timedelta(days=740)).strftime('%Y%m%d')

        sql = cfg['sql_template'].format(
            start_dt=start_dt,
            end_dt=end_dt,
            start_dt_20d=start_dt_20d,
            start_dt_60d=start_dt_60d,
            start_dt_2y=start_dt_2y,
        )

        t0 = datetime.now()
        try:
            df = con.execute(sql).fetchdf()
            elapsed = (datetime.now() - t0).total_seconds()
            out_path = P(output_dir) / f'{fname}.parquet'
            if len(df) > 0:
                df.to_parquet(out_path, index=False)
                computed.append((fname, len(df), elapsed))
            else:
                failed.append((fname, 'empty'))
        except Exception as e:
            failed.append((fname, str(e)[:100]))

    con.close()

    # ── Worker 端本地 merge ──────────────────────────
    # 每个 worker 把自己的因子文件合并成一个 batch parquet
    local_factor_files = []
    for fname, nrows, elapsed in computed:
        fpath = os.path.join(output_dir, f'{fname}.parquet')
        if os.path.exists(fpath):
            local_factor_files.append((fname, fpath))

    return wid, computed, failed, None


# ── 主进程 DuckDB 分批顺序 LEFT JOIN ───────────────────────────────────

def _merge_factors(factor_files, output_path):
    """
    长表格式转换：宽表因子文件 → 长表 parquet（内存安全版）。

    策略：
      - 分批读取宽表 parquet，melt 为长表（factor_name, factor_value）
      - 追加到 all_chunks，最后 concat
      - 排序后写出，ZSTD 压缩

    内存安全：
      - 每批 BATCH=10 个因子读完即 melt，不堆积宽表
      - concat 前 gc.collect() 控制峰值
      - 内存增长 ~100MB/因子，210 因子峰值约 36GB（110GB 系统安全）
    """
    import polars as pl
    import gc
    from datetime import datetime as _dt

    if not factor_files:
        return

    t0 = _dt.now()
    n = len(factor_files)
    BATCH = 10
    n_batches = (n + BATCH - 1) // BATCH
    logger.info(f"  长表转换合并 {n} 个因子（每批 {BATCH}，共 {n_batches} 批）...")

    all_chunks = []

    for batch_idx in range(n_batches):
        start_i = batch_idx * BATCH
        end_i = min(start_i + BATCH, n)
        batch = factor_files[start_i:end_i]

        for factor_name, fpath in batch:
            df = pl.read_parquet(fpath)
            df_long = df.unpivot(
                index=["ts_code", "trade_date"],
                on=factor_name,
                variable_name="factor_name",
                value_name="factor_value",
            ).with_columns(
                pl.col("factor_value").cast(pl.Float64)
            )
            del df
            all_chunks.append(df_long)

        gc.collect()
        logger.info(f"    批次 {batch_idx+1}/{n_batches} 完成")

    # concat + 排序 + 写出
    logger.info(f"  concat {len(all_chunks)} 个分块...")
    result = pl.concat(all_chunks, rechunk=True)
    del all_chunks
    gc.collect()

    logger.info(f"  排序（factor_name, trade_date, ts_code）...")
    result = result.sort(["factor_name", "trade_date", "ts_code"])

    logger.info(f"  写出到 {output_path}...")
    result.write_parquet(output_path, compression="zstd", statistics=True)

    elapsed = (_dt.now() - t0).total_seconds()
    logger.info(f"    \u2705 完成: {n} 个因子，{result.height:,} 行，耗时: {elapsed:.1f}s")



# ── 主流程 ────────────────────────────────────────────────
def main():
    t_start = datetime.now()

    logger.info("=" * 60)
    logger.info("  duckdb_factor_engine - 因子生成模板 v0.2.21")
    logger.info("=" * 60)
    logger.info(f"  数据目录 : {DATA_DIR}")
    logger.info(f"  输出目录 : {OUTPUT_DIR}")
    logger.info(f"  日期范围 : {START_DATE} ~ {END_DATE}")
    logger.info(f"  Workers  : {N_WORKERS}")
    logger.info(f"  因子范围 : {FACTOR_SCOPE}")
    logger.info("=" * 60)

    # ── 检查数据目录 ────────────────────────────────────
    if not os.path.isdir(DATA_DIR):
        logger.error(f"数据目录不存在: {DATA_DIR}")
        sys.exit(1)

    # ── 解析因子列表 ────────────────────────────────────
    factor_list = resolve_factor_list(FACTOR_SCOPE)
    total = len(factor_list)
    logger.info(f"\n将生成 {total} 个因子")

    # ── 分析需要的 prep 表 ──────────────────────────────
    needed_prep = set()
    for fname in factor_list:
        cfg = get_factor_config(fname)
        if cfg:
            sql_l = cfg['sql_template'].lower()
            for prep in [
                'fina_indicator_prep', 'income_prep', 'fina_cashflow_vip_prep',
                'fina_balancesheet_vip_prep', 'income_ttm_prep', 'income_sorted',
                'fina_indicator_sorted', 'moneyflow_rolling_prep',
                'turnover_rolling_prep', 'prices_return_prep',
                'stk_holdernumber_prep', 'dividend_prep',
                'income_exp_sorted', 'fina_ind_full_sorted',
                'finabal_full_sorted', 'finacf_full_sorted',
            ]:
                if prep in sql_l:
                    needed_prep.add(prep)
    logger.info(f"  需要的Prep表: {sorted(needed_prep) or '无（纯日频因子）'}")

    # ── 清理输出目录 ────────────────────────────────────
    out_path = Path(OUTPUT_DIR)
    if out_path.exists():
        logger.warning(f"输出目录已存在，将被覆盖: {OUTPUT_DIR}")
        shutil.rmtree(out_path, ignore_errors=True)
    out_path.mkdir(parents=True, exist_ok=True)

    # ═══════════════════════════════════════════════════════
    # Step 1: 主进程 DuckDB 初始化 + 财务数据预计算
    # ═══════════════════════════════════════════════════════
    t_prep = datetime.now()
    logger.info("\n[Step 1/4] 主进程 DuckDB 初始化 + 财务预计算...")

    import duckdb
    main_con = duckdb.connect()
    main_con.execute("SET threads=4")
    main_con.execute("SET memory_limit='2GB'")

    _register_views(main_con, DATA_DIR)
    logger.info("  视图注册完成")

    logger.info("  预计算财务共享数据...")
    import duckdb_factor_engine.core as _core_mod
    engine = object.__new__(FactorEngineV72 := _core_mod.FactorEngineV72)
    engine.con = main_con
    engine.data_dir = Path(DATA_DIR)
    engine._register_views = lambda: None
    engine._prepare_financial_tables_fixed()
    prep_elapsed = (datetime.now() - t_prep).total_seconds()
    logger.info(f"  ✅ 预计算完成，耗时 {prep_elapsed:.1f}s")

    # ═══════════════════════════════════════════════════════
    # Step 2: 导出 prep 表为 parquet（所有 worker 共享）
    # ═══════════════════════════════════════════════════════
    logger.info("\n[Step 2/4] 导出预计算表为共享 parquet...")
    prep_cache_dir = out_path / '_prep_cache'
    prep_cache_dir.mkdir(parents=True, exist_ok=True)

    all_prep_tables = [
        'fina_indicator_prep', 'fina_indicator_ly',
        'income_prep', 'income_ly',
        'income_sorted', 'fina_indicator_sorted',
        'stk_holdernumber_prep', 'dividend_prep',
        'fina_cashflow_vip_prep', 'fina_balancesheet_vip_prep',
        'income_exp_sorted', 'fina_ind_full_sorted',
        'finabal_full_sorted', 'finacf_full_sorted',
        'income_ttm_prep',
    ]
    prep_table_names = [t for t in all_prep_tables if t in needed_prep]

    prep_parquet_paths = {}  # view_name -> parquet_path
    for tbl in prep_table_names:
        out_file = prep_cache_dir / f'{tbl}.parquet'
        try:
            df = main_con.execute(f"SELECT * FROM {tbl}").fetchdf()
            df.to_parquet(str(out_file), index=False)
            prep_parquet_paths[tbl] = str(out_file)
            logger.info(
                f"    {tbl}: {len(df):,} 行 "
                f"→ {out_file.stat().st_size / 1024 / 1024:.1f} MB"
            )
        except Exception as e:
            logger.warning(f"    {tbl} 导出失败: {e}")

    main_con.close()  # 释放主进程 DuckDB 内存
    export_elapsed = (datetime.now() - t_prep).total_seconds() - prep_elapsed
    logger.info(f"  ✅ 导出完成，耗时 {export_elapsed:.1f}s")

    # ═══════════════════════════════════════════════════════
    # Step 3: 分批 multiprocessing forkserver 并行计算因子
    # ═══════════════════════════════════════════════════════
    BATCH_SIZE = 50
    BATCH_WORKERS = 16  # 每批最多 16 个并发进程
    n_batches = math.ceil(total / BATCH_SIZE)
    logger.info(f"\n[Step 3/4] 分批计算 {total} 个因子（每批{BATCH_SIZE}，每批最多{BATCH_WORKERS}并发进程）...")

    t_worker = datetime.now()
    results = []

    # 使用 forkserver 模式：避免 spawn 的 futex 死锁问题
    ctx = mp.get_context('forkserver')

    for batch_idx in range(n_batches):
        batch_start = batch_idx * BATCH_SIZE
        batch_end = min(batch_start + BATCH_SIZE, total)
        batch = factor_list[batch_start:batch_end]
        n_in_batch = len(batch)
        n_workers_this_batch = min(BATCH_WORKERS, n_in_batch)
        logger.info(f"  批次 {batch_idx+1}/{n_batches}：{n_in_batch} 个因子，{n_workers_this_batch} 个并发进程...")

        # 每个因子分配一个 worker slot（sub_dir）
        batch_args = []
        for j, fname in enumerate(batch):
            wid = batch_start + j  # 全局唯一 worker id
            sub_dir = out_path / f'_worker_{wid}'
            sub_dir.mkdir(parents=True, exist_ok=True)
            batch_args.append((
                wid,
                [fname],  # 每个 worker 只算一个因子
                START_DATE.replace('-', ''),
                END_DATE.replace('-', ''),
                str(sub_dir),
                DATA_DIR,
                prep_parquet_paths,
            ))

        # forkserver 模式：每个 worker 独立 DuckDB 连接，真正并行
        with ctx.Pool(processes=n_workers_this_batch) as pool:
            batch_results = pool.map(_worker_compute, batch_args)
        results.extend(batch_results)
        logger.info(f"    批次 {batch_idx+1} 完成，{len([r for r in batch_results if r and r[1]])} 个因子成功")

    worker_elapsed = (datetime.now() - t_worker).total_seconds()

    # ── 收集结果 ────────────────────────────────────────
    # ── 收集所有因子文件路径 ─────────────────────────
    total_computed = 0
    total_failed = 0
    all_factor_files = []
    for wid, computed, failed, _batch_path in results:
        total_computed += len(computed)
        total_failed += len(failed)
        sub_dir = out_path / f'_worker_{wid}'
        for fname, nrows, elapsed in computed:
            fpath = sub_dir / f'{fname}.parquet'
            if fpath.exists():
                all_factor_files.append((fname, str(fpath)))

    logger.info(f"\n因子计算完成：成功 {total_computed}/{total} 个，{len(all_factor_files)} 个因子文件")

    # ═══════════════════════════════════════════════════════
    # Step 4: DuckDB 分批 LEFT JOIN 合并所有因子
    # ═══════════════════════════════════════════════════════
    logger.info(f"\n[Step 4/4] 长表格式转换合并 {len(all_factor_files)} 个因子文件...")
    _merge_factors(all_factor_files, str(out_path / 'factors_all.parquet'))

    total_elapsed = (datetime.now() - t_start).total_seconds()

    # ── 打印摘要 ────────────────────────────────────────
    logger.info("")
    logger.info("=" * 60)
    logger.info(f"  ✅ 完成！成功 {total_computed}/{total} 个因子")
    logger.info(f"  预计算 : {prep_elapsed:.1f}s")
    logger.info(f"  导出   : {export_elapsed:.1f}s")
    logger.info(f"  Workers: {worker_elapsed:.1f}s ({worker_elapsed/60:.1f}分钟)")
    logger.info(f"  总耗时 : {total_elapsed:.1f}s ({total_elapsed/60:.1f}分钟)")
    logger.info(f"  输出   : {out_path / 'factors_all.parquet'}")
    logger.info("=" * 60)

    if total_failed > 0:
        logger.warning(f"  失败因子 ({total_failed}):")
        for wid, computed, failed in results:
            for f, err in failed:
                logger.warning(f"    {f}: {err}")

    # ── 清理 + 验证 ────────────────────────────────────
    shutil.rmtree(prep_cache_dir, ignore_errors=True)

    result_parquet = out_path / 'factors_all.parquet'
    if result_parquet.exists():
        size_mb = result_parquet.stat().st_size / 1024 / 1024
        logger.info(f"\n📦 输出: {result_parquet} ({size_mb:.1f} MB)")
        import pandas as pd
        df = pd.read_parquet(result_parquet)
        logger.info(f"   格式: 长表（factor_name, factor_value）")
        logger.info(f"   行数: {len(df):,}, 列数: {len(df.columns)} → {df.columns.tolist()}")
        logger.info(f"   因子数: {df['factor_name'].nunique()}")
        logger.info(f"   股票数: {df['ts_code'].nunique():,}")
        logger.info(f"   日期: {df['trade_date'].min()} ~ {df['trade_date'].max()}")


# ── 直接运行入口 ─────────────────────────────────────────
if __name__ == '__main__':
    import functools, sys
    print = functools.partial(print, flush=True)
    sys.stdout.reconfigure(line_buffering=True)
    main()
