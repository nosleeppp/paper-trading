# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 波动性 因子定义
包含 3 个波动性类因子。
由 config.py 聚合后统一暴露。
"""

CATEGORY = "volatility"

FACTORS = [
    {   'name': 'ATR_1M',
        'category': 'volatility',
        'description': '1个月ATR',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                atr_21 AS ATR_1M\n'
                        '            FROM (\n'
                        '                SELECT \n'
                        '                    ts_code,\n'
                        '                    trade_date,\n'
                        '                    AVG(high - low) OVER (\n'
                        '                        PARTITION BY ts_code \n'
                        '                        ORDER BY trade_date \n'
                        '                        ROWS BETWEEN 20 PRECEDING AND CURRENT ROW\n'
                        '                    ) AS atr_21\n'
                        '                FROM prices\n'
                        "                WHERE trade_date >= (CAST('{start_dt}' AS INTEGER) - 800)::VARCHAR AND trade_date "
                        "<= '{end_dt}'\n"
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'ATR_3M',
        'category': 'volatility',
        'description': '3个月ATR',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                atr_63 AS ATR_3M\n'
                        '            FROM (\n'
                        '                SELECT \n'
                        '                    ts_code,\n'
                        '                    trade_date,\n'
                        '                    AVG(high - low) OVER (\n'
                        '                        PARTITION BY ts_code \n'
                        '                        ORDER BY trade_date \n'
                        '                        ROWS BETWEEN 62 PRECEDING AND CURRENT ROW\n'
                        '                    ) AS atr_63\n'
                        '                FROM prices\n'
                        "                WHERE trade_date >= '{start_dt_90d}' AND trade_date <= '{end_dt}'\n"
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MDR_60D',
        'category': 'volatility',
        'description': '最大回撤率（60日）',
        'sql_template': '\n'
                        '            SELECT ts_code, trade_date,\n'
                        '                MAX(max_dd) OVER (PARTITION BY ts_code ORDER BY trade_date\n'
                        '                                   ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS MDR_60D\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, close, high,\n'
                        '                    (MAX(high) OVER (PARTITION BY ts_code ORDER BY trade_date\n'
                        '                                     ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) - close)\n'
                        '                    / NULLIF(MAX(high) OVER (PARTITION BY ts_code ORDER BY trade_date\n'
                        '                                             ROWS BETWEEN 59 PRECEDING AND CURRENT ROW), 0)\n'
                        '                    AS max_dd\n'
                        '                FROM prices\n'
                        "                WHERE trade_date >= '{start_dt_60d}' AND trade_date <= '{end_dt}'\n"
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True}
]