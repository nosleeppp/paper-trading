# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 动量 因子定义
包含 9 个动量类因子。
由 config.py 聚合后统一暴露。
"""

CATEGORY = "momentum"

FACTORS = [
    {   'name': 'RETURN_12M',
        'category': 'momentum',
        'description': '12个月收益率',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                (close - close_12m_ago) * 100.0 / close_12m_ago AS RETURN_12M\n'
                        '            FROM (\n'
                        '                SELECT \n'
                        '                    ts_code,\n'
                        '                    trade_date,\n'
                        '                    close,\n'
                        '                    LAG(close, 252) OVER (PARTITION BY ts_code ORDER BY trade_date) AS '
                        'close_12m_ago\n'
                        '                FROM prices\n'
                        "                WHERE trade_date >= (CAST('{start_dt}' AS INTEGER) - 20000)::VARCHAR\n"
                        "                  AND trade_date <= '{end_dt}'\n"
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '              AND close_12m_ago IS NOT NULL AND close_12m_ago > 0\n'
                        '        ',
        'enabled': True},
    {   'name': 'REVERSE_1M',
        'category': 'momentum',
        'description': '1个月反转',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                (close - close_1m_ago) * 100.0 / close_1m_ago AS REVERSE_1M\n'
                        '            FROM (\n'
                        '                SELECT \n'
                        '                    ts_code,\n'
                        '                    trade_date,\n'
                        '                    close,\n'
                        '                    LAG(close, 21) OVER (PARTITION BY ts_code ORDER BY trade_date) AS '
                        'close_1m_ago\n'
                        '                FROM prices\n'
                        "                WHERE trade_date >= '{start_dt_20d}' AND trade_date <= '{end_dt}'\n"
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '              AND close_1m_ago IS NOT NULL AND close_1m_ago > 0\n'
                        '        ',
        'enabled': True},
    {   'name': 'REVERSE_3M',
        'category': 'momentum',
        'description': '3个月反转',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                (close - close_3m_ago) * 100.0 / close_3m_ago AS REVERSE_3M\n'
                        '            FROM (\n'
                        '                SELECT \n'
                        '                    ts_code,\n'
                        '                    trade_date,\n'
                        '                    close,\n'
                        '                    LAG(close, 63) OVER (PARTITION BY ts_code ORDER BY trade_date) AS '
                        'close_3m_ago\n'
                        '                FROM prices\n'
                        "                WHERE trade_date >= '{start_dt_90d}'\n"
                        "                  AND trade_date <= '{end_dt}'\n"
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '              AND close_3m_ago IS NOT NULL AND close_3m_ago > 0\n'
                        '        ',
        'enabled': True},
    {   'name': 'PRICE_AMOUNT_CORR_20D',
        'category': 'momentum',
        'description': '收盘价与成交额相关性（20日Pearson）',
        'sql_template': '\n'
                        '            SELECT ts_code, trade_date,\n'
                        '                CORR(close, amount) OVER (PARTITION BY ts_code ORDER BY trade_date\n'
                        '                                          ROWS BETWEEN 19 PRECEDING AND CURRENT ROW)\n'
                        '                AS PRICE_AMOUNT_CORR_20D\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, close, amount\n'
                        '                FROM prices\n'
                        "                WHERE trade_date >= '{start_dt_20d}' AND trade_date <= '{end_dt}'\n"
                        '            ) sub\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'GAP_OPEN',
        'category': 'momentum',
        'description': '跳空高开因子（20日均值）',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, AVG(CAST(open AS DOUBLE) / NULLIF(CAST(pre_close AS DOUBLE), '
                        '0) - 1) OVER (PARTITION BY ts_code ORDER BY trade_date ROWS BETWEEN 19 PRECEDING AND CURRENT ROW) '
                        "AS GAP_OPEN FROM prices WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'INTRADAY_REVERSAL',
        'category': 'momentum',
        'description': '日内反转因子（20日均值）',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, AVG((CAST(close AS DOUBLE) - CAST(open AS DOUBLE)) / '
                        'NULLIF(CAST(high AS DOUBLE) - CAST(low AS DOUBLE), 0)) OVER (PARTITION BY ts_code ORDER BY '
                        'trade_date ROWS BETWEEN 19 PRECEDING AND CURRENT ROW) AS INTRADAY_REVERSAL FROM prices WHERE '
                        "trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'HIGH_TO_CLOSE',
        'category': 'momentum',
        'description': '上影线比例（20日均值）',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, AVG(CAST(high AS DOUBLE) / NULLIF(CAST(close AS DOUBLE), 0) - '
                        '1) OVER (PARTITION BY ts_code ORDER BY trade_date ROWS BETWEEN 19 PRECEDING AND CURRENT ROW) AS '
                        "HIGH_TO_CLOSE FROM prices WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'CLOSE_TO_LOW',
        'category': 'momentum',
        'description': '下影线比例（20日均值）',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, AVG(CAST(close AS DOUBLE) / NULLIF(CAST(low AS DOUBLE), 0) - '
                        '1) OVER (PARTITION BY ts_code ORDER BY trade_date ROWS BETWEEN 19 PRECEDING AND CURRENT ROW) AS '
                        "CLOSE_TO_LOW FROM prices WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'LIMIT_UP_PROXIMITY',
        'category': 'momentum',
        'description': '涨停接近度',
        'sql_template': '\n'
                        '        WITH db AS (SELECT d.ts_code, d.trade_date, CAST(d.trade_date AS INTEGER) AS td_int, '
                        'p.close, p.pre_close FROM daily_basic d LEFT JOIN prices p ON d.ts_code = p.ts_code AND '
                        "d.trade_date = p.trade_date WHERE d.trade_date >= '{start_dt}' AND d.trade_date <= '{end_dt}'), "
                        'lim AS (SELECT ts_code, trade_date, CAST(up_limit AS DOUBLE) AS ul, CAST(trade_date AS INTEGER) '
                        'AS ltd_int, ROW_NUMBER() OVER (PARTITION BY ts_code, trade_date ORDER BY trade_date DESC) AS rn '
                        "FROM stk_limit WHERE trade_date <= '{end_dt}'), lim_r AS (SELECT ts_code, ul, ltd_int FROM lim "
                        'WHERE rn = 1) SELECT d.ts_code, d.trade_date, CASE WHEN l.ul > 0 AND d.pre_close > 0 AND '
                        'd.pre_close IS NOT NULL THEN (d.close - l.ul) / (l.ul - d.pre_close) END AS LIMIT_UP_PROXIMITY '
                        'FROM db d LEFT JOIN LATERAL (SELECT ul, ltd_int FROM lim_r WHERE lim_r.ts_code = d.ts_code AND '
                        'lim_r.ltd_int <= d.td_int AND lim_r.ltd_int >= d.td_int - 30 ORDER BY lim_r.ltd_int DESC LIMIT 1) '
                        'l ON TRUE\n'
                        '        ',
        'enabled': True}
]