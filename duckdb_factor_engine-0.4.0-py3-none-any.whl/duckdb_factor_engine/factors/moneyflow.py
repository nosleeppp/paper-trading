# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 资金流 因子定义
包含 10 个资金流类因子。
由 config.py 聚合后统一暴露。
"""

CATEGORY = "moneyflow"

FACTORS = [
    {   'name': 'MAIN_FORCE_5D',
        'category': 'moneyflow',
        'description': '5日主力净流入',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                buy_lg_amount - sell_lg_amount AS MAIN_FORCE_5D\n'
                        '            FROM moneyflow\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MAIN_FORCE_20D',
        'category': 'moneyflow',
        'description': '20日主力净流入',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                MAIN_FORCE_20D\n'
                        '            FROM (\n'
                        '                SELECT \n'
                        '                    ts_code,\n'
                        '                    trade_date,\n'
                        '                    SUM(buy_lg_amount - sell_lg_amount) OVER (\n'
                        '                        PARTITION BY ts_code \n'
                        '                        ORDER BY trade_date \n'
                        '                        ROWS BETWEEN 19 PRECEDING AND CURRENT ROW\n'
                        '                    ) AS MAIN_FORCE_20D\n'
                        '                FROM moneyflow\n'
                        "                WHERE trade_date >= '{start_dt_90d}' AND trade_date <= '{end_dt}'\n"
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'BLOCK_TRADE_PREMIUM',
        'category': 'moneyflow',
        'description': '大宗交易溢价率（近20天）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT d.ts_code, d.trade_date, CAST(d.trade_date AS INTEGER) AS td_int, '
                        'p.close, p.pre_close FROM daily_basic d LEFT JOIN prices p ON d.ts_code = p.ts_code AND '
                        "d.trade_date = p.trade_date WHERE d.trade_date >= '{start_dt}' AND d.trade_date <= '{end_dt}'), "
                        'bt AS (SELECT ts_code, trade_date, CAST(price AS DOUBLE) AS blk_price, CAST(vol AS DOUBLE) AS '
                        'blk_vol, CAST(trade_date AS INTEGER) AS btd_int FROM block_trade), recent AS (SELECT d.ts_code, '
                        'd.trade_date, d.close, d.pre_close, AVG(b.blk_price) AS avg_blk_price FROM db d LEFT JOIN bt b ON '
                        'd.ts_code = b.ts_code AND b.btd_int > d.td_int - 2000 AND b.btd_int <= d.td_int GROUP BY '
                        'd.ts_code, d.trade_date, d.close, d.pre_close) SELECT ts_code, trade_date, CASE WHEN pre_close > '
                        '0 AND pre_close IS NOT NULL THEN (avg_blk_price - close) / pre_close END AS BLOCK_TRADE_PREMIUM '
                        'FROM recent WHERE avg_blk_price IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'SMART_MONEY_NET_20D',
        'category': 'moneyflow',
        'description': '主力资金净流入占比（20日）',
        'sql_template': '\n'
                        '        WITH mf AS (SELECT ts_code, trade_date, buy_lg_amount, buy_elg_amount, sell_lg_amount, '
                        'sell_elg_amount, buy_md_amount, buy_sm_amount, sell_md_amount, sell_sm_amount FROM moneyflow '
                        "WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), mf2 AS (SELECT ts_code, "
                        'trade_date, buy_lg_amount + buy_elg_amount - sell_lg_amount - sell_elg_amount AS smart_net, '
                        'buy_lg_amount + buy_elg_amount + sell_lg_amount + sell_elg_amount + buy_md_amount + buy_sm_amount '
                        '+ sell_md_amount + sell_sm_amount AS total_amount FROM mf) SELECT ts_code, trade_date, smart_net '
                        '/ NULLIF(total_amount, 0) AS SMART_MONEY_NET_20D FROM mf2 WHERE smart_net IS NOT NULL AND '
                        'total_amount IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'LARGE_ORDER_BUY_RATIO',
        'category': 'moneyflow',
        'description': '大单买入占比（20日均值）',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, AVG((buy_lg_amount + buy_elg_amount) / NULLIF(buy_lg_amount + '
                        'buy_elg_amount + sell_lg_amount + sell_elg_amount + buy_md_amount + buy_sm_amount + '
                        'sell_md_amount + sell_sm_amount, 0)) OVER (PARTITION BY ts_code ORDER BY trade_date ROWS BETWEEN '
                        '19 PRECEDING AND CURRENT ROW) AS LARGE_ORDER_BUY_RATIO FROM moneyflow WHERE trade_date >= '
                        "'{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'SMALL_ORDER_NET_20D',
        'category': 'moneyflow',
        'description': '小单净流入占比（20日）',
        'sql_template': '\n'
                        '        WITH mf AS (SELECT ts_code, trade_date, buy_sm_amount, sell_sm_amount, buy_lg_amount, '
                        'buy_elg_amount, sell_lg_amount, sell_elg_amount, buy_md_amount, sell_md_amount FROM moneyflow '
                        "WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), mf2 AS (SELECT ts_code, "
                        'trade_date, buy_sm_amount - sell_sm_amount AS small_net, buy_lg_amount + buy_elg_amount + '
                        'sell_lg_amount + sell_elg_amount + buy_md_amount + buy_sm_amount + sell_md_amount + '
                        'sell_sm_amount AS total_amount FROM mf) SELECT ts_code, trade_date, small_net / '
                        'NULLIF(total_amount, 0) AS SMALL_ORDER_NET_20D FROM mf2 WHERE small_net IS NOT NULL AND '
                        'total_amount IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'NET_MF_AMOUNT_5D',
        'category': 'moneyflow',
        'description': '净流入占比（5日均值）',
        'sql_template': '\n'
                        '        WITH mf AS (SELECT ts_code, trade_date, net_mf_amount, buy_lg_amount, buy_elg_amount, '
                        'sell_lg_amount, sell_elg_amount, buy_md_amount, buy_sm_amount, sell_md_amount, sell_sm_amount '
                        "FROM moneyflow WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), mf2 AS (SELECT "
                        'ts_code, trade_date, net_mf_amount / NULLIF(buy_lg_amount + buy_elg_amount + sell_lg_amount + '
                        'sell_elg_amount + buy_md_amount + buy_sm_amount + sell_md_amount + sell_sm_amount, 0) AS ratio '
                        'FROM mf) SELECT ts_code, trade_date, AVG(ratio) OVER (PARTITION BY ts_code ORDER BY trade_date '
                        'ROWS BETWEEN 4 PRECEDING AND CURRENT ROW) AS NET_MF_AMOUNT_5D FROM mf2 WHERE ratio IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'NORTHBOUND_HOLD_RATIO',
        'category': 'moneyflow',
        'description': '北向持股比例',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, CAST(ratio AS DOUBLE) AS NORTHBOUND_HOLD_RATIO FROM hk_hold '
                        "WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'NORTHBOUND_FLOW_20D',
        'category': 'moneyflow',
        'description': '北向持股变化（20日）',
        'sql_template': '\n'
                        '        WITH hk AS (SELECT ts_code, trade_date, CAST(ratio AS DOUBLE) AS ratio FROM hk_hold WHERE '
                        "trade_date >= '{start_dt}' AND trade_date <= '{end_dt}') SELECT ts_code, trade_date, ratio - "
                        'LAG(ratio, 20) OVER (PARTITION BY ts_code ORDER BY trade_date) AS NORTHBOUND_FLOW_20D FROM hk\n'
                        '        ',
        'enabled': True},
    {   'name': 'NORTHBOUND_FLOW_5D',
        'category': 'moneyflow',
        'description': '北向持股变化（5日）',
        'sql_template': '\n'
                        '        WITH hk AS (SELECT ts_code, trade_date, CAST(ratio AS DOUBLE) AS ratio FROM hk_hold WHERE '
                        "trade_date >= '{start_dt}' AND trade_date <= '{end_dt}') SELECT ts_code, trade_date, ratio - "
                        'LAG(ratio, 5) OVER (PARTITION BY ts_code ORDER BY trade_date) AS NORTHBOUND_FLOW_5D FROM hk\n'
                        '        ',
        'enabled': True}
]