# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 估值 因子定义
包含 13 个估值类因子。
由 config.py 聚合后统一暴露。
"""

CATEGORY = "valuation"

FACTORS = [
    {   'name': 'TTM_EP',
        'category': 'valuation',
        'description': '滚动市盈率倒数',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                CASE WHEN p.pe_ttm > 0 THEN 1.0 / p.pe_ttm ELSE NULL END AS TTM_EP\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, pe_ttm\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '        ',
        'enabled': True},
    {   'name': 'TTM_EP_PCT_1Y',
        'category': 'valuation',
        'description': 'TTM_EP 在过去1年的百分位',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                a.ts_code,\n'
                        '                a.trade_date,\n'
                        '                CASE \n'
                        '                    WHEN b.count_all > 0 THEN a.rank_ttm_ep * 1.0 / b.count_all\n'
                        '                    ELSE NULL\n'
                        '                END AS TTM_EP_PCT_1Y\n'
                        '            FROM (\n'
                        '                SELECT \n'
                        '                    ts_code, \n'
                        '                    trade_date,\n'
                        '                    RANK() OVER (\n'
                        '                        PARTITION BY ts_code \n'
                        '                        ORDER BY CASE WHEN pe_ttm > 0 THEN 1.0/pe_ttm ELSE NULL END\n'
                        '                    ) AS rank_ttm_ep\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) a\n'
                        '            CROSS JOIN (\n'
                        '                SELECT COUNT(*) AS count_all FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) b\n'
                        '        ',
        'enabled': True},
    {   'name': 'TTM_SP',
        'category': 'valuation',
        'description': '滚动市销率倒数',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                CASE WHEN p.ps_ttm > 0 THEN 1.0 / p.ps_ttm ELSE NULL END AS TTM_SP\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, ps_ttm\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '        ',
        'enabled': True},
    {   'name': 'BP',
        'category': 'valuation',
        'description': '市净率倒数',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                CASE WHEN p.pb > 0 THEN 1.0 / p.pb ELSE NULL END AS BP\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, pb\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '        ',
        'enabled': True},
    {   'name': 'DIVIDEND_RATE',
        'category': 'valuation',
        'description': '股息率',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                dv_ratio AS DIVIDEND_RATE\n'
                        '            FROM daily_basic\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'PEG',
        'category': 'valuation',
        'description': 'PEG指标',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                CASE \n'
                        '                    WHEN p.pe_ttm > 0 AND f.net_profit_growth IS NOT NULL \n'
                        '                    THEN p.pe_ttm / f.net_profit_growth\n'
                        '                    ELSE NULL\n'
                        '                END AS PEG\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, pe_ttm, CAST(trade_date AS INTEGER) AS '
                        'trade_date_int\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '            LEFT JOIN LATERAL (\n'
                        '                SELECT roe_yoy AS net_profit_growth\n'
                        '                FROM fina_indicator_sorted f\n'
                        '                WHERE f.ts_code = p.ts_code\n'
                        '                  AND f.end_date_int <= p.trade_date_int\n'
                        '                  AND f.ann_date_int <= p.trade_date_int\n'
                        '                ORDER BY f.sort_key_str DESC\n'
                        '                LIMIT 1\n'
                        '            ) f ON true\n'
                        '        ',
        'enabled': True},
    {   'name': 'DV_TTM',
        'category': 'valuation',
        'description': '股息率TTM',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, CAST(dv_ttm AS DOUBLE) AS DV_TTM FROM daily_basic WHERE '
                        "trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'SIZE',
        'category': 'valuation',
        'description': 'ln(总市值)',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, LN(CAST(total_mv AS DOUBLE)) AS SIZE FROM daily_basic WHERE '
                        "trade_date >= '{start_dt}' AND trade_date <= '{end_dt}' AND total_mv IS NOT NULL AND total_mv > "
                        '0\n'
                        '        ',
        'enabled': True},
    {   'name': 'PE_TTM_INVERSE',
        'category': 'valuation',
        'description': 'PE倒数',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, CASE WHEN pe_ttm > 0 AND pe_ttm IS NOT NULL THEN 1.0 / '
                        'CAST(pe_ttm AS DOUBLE) ELSE NULL END AS PE_TTM_INVERSE FROM daily_basic WHERE trade_date >= '
                        "'{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'PB_INVERSE',
        'category': 'valuation',
        'description': 'PB倒数',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, CASE WHEN pb > 0 AND pb IS NOT NULL THEN 1.0 / CAST(pb AS '
                        "DOUBLE) ELSE NULL END AS PB_INVERSE FROM daily_basic WHERE trade_date >= '{start_dt}' AND "
                        "trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'DIVIDEND_YIELD',
        'category': 'valuation',
        'description': '股息率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int, close FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), dv AS (SELECT "
                        'ts_code, imp_ann_date, cash_div_tax, CAST(imp_ann_date AS INTEGER) AS imp_int, ROW_NUMBER() OVER '
                        '(PARTITION BY ts_code, imp_ann_date ORDER BY imp_ann_date DESC) AS rn FROM dividend WHERE '
                        "imp_ann_date IS NOT NULL AND imp_ann_date != ''), recent AS (SELECT d.ts_code, d.trade_date, "
                        'd.close, dv.cash_div_tax FROM db d LEFT JOIN dv ON d.ts_code = dv.ts_code AND dv.imp_int <= '
                        'd.td_int AND dv.imp_int > d.td_int - 120000) SELECT ts_code, trade_date, CASE WHEN close > 0 AND '
                        'close IS NOT NULL THEN SUM(cash_div_tax) OVER (PARTITION BY ts_code, trade_date) / close END AS '
                        'DIVIDEND_YIELD FROM recent WHERE cash_div_tax IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'FCF_YIELD',
        'category': 'valuation',
        'description': '自由现金流收益率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int, '
                        "CAST(total_mv AS DOUBLE) AS total_mv FROM daily_basic WHERE trade_date >= '{start_dt}' AND "
                        "trade_date <= '{end_dt}'), cf AS (SELECT ts_code, end_date, ann_date, CAST(end_date AS INTEGER) "
                        'AS ed_int, CAST(ann_date AS INTEGER) AS ad_int, CAST(free_cashflow AS DOUBLE) AS fcf, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_cashflow_vip), cfl AS (SELECT * FROM cf WHERE rn = 1), joined AS (SELECT d.ts_code, '
                        'd.trade_date, d.total_mv, cfl.fcf, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER '
                        'BY cfl.ed_int DESC) AS q_rank FROM db d LEFT JOIN cfl ON d.ts_code = cfl.ts_code AND cfl.ed_int '
                        '<= d.td_int AND cfl.ad_int <= d.td_int) SELECT ts_code, trade_date, CASE WHEN total_mv > 0 AND '
                        'total_mv IS NOT NULL THEN fcf / total_mv END AS FCF_YIELD FROM joined WHERE q_rank = 1 AND '
                        'total_mv IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'DIVIDEND_PAYOUT_RATIO',
        'category': 'valuation',
        'description': '分红派息比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}') SELECT d.ts_code, "
                        'd.trade_date, CASE WHEN fi.eps != 0 AND fi.eps IS NOT NULL THEN dv.cash_div / fi.eps END AS '
                        'DIVIDEND_PAYOUT_RATIO FROM db d LEFT JOIN LATERAL (SELECT cash_div FROM dividend_prep WHERE '
                        'ts_code = d.ts_code AND end_date_int <= d.td_int AND ann_date_int <= d.td_int ORDER BY '
                        'end_date_int DESC, ann_date_int DESC LIMIT 1) dv ON TRUE LEFT JOIN LATERAL (SELECT eps FROM '
                        'fina_indicator_prep WHERE ts_code = d.ts_code AND end_date IS NOT NULL AND ann_date IS NOT NULL '
                        'AND CAST(end_date AS INTEGER) <= d.td_int AND CAST(ann_date AS INTEGER) <= d.td_int ORDER BY '
                        'CAST(end_date AS INTEGER) DESC, CAST(ann_date AS INTEGER) DESC LIMIT 1) fi ON TRUE WHERE '
                        'dv.cash_div IS NOT NULL\n'
                        '        ',
        'enabled': True}
]