# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 技术指标 因子定义
包含 39 个技术指标类因子。
由 config.py 聚合后统一暴露。
"""

CATEGORY = "technical"

FACTORS = [
    {   'name': 'MA_BFQ_5',
        'category': 'technical',
        'description': 'MA_BFQ_5 (5日均线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ma_bfq_5 AS MA_BFQ_5\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MA_BFQ_10',
        'category': 'technical',
        'description': 'MA_BFQ_10 (10日均线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ma_bfq_10 AS MA_BFQ_10\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MA_BFQ_20',
        'category': 'technical',
        'description': 'MA_BFQ_20 (20日均线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ma_bfq_20 AS MA_BFQ_20\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MA_BFQ_30',
        'category': 'technical',
        'description': 'MA_BFQ_30 (30日均线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ma_bfq_30 AS MA_BFQ_30\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MA_BFQ_60',
        'category': 'technical',
        'description': 'MA_BFQ_60 (60日均线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ma_bfq_60 AS MA_BFQ_60\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MA_BFQ_90',
        'category': 'technical',
        'description': 'MA_BFQ_90 (90日均线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ma_bfq_90 AS MA_BFQ_90\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MA_BFQ_250',
        'category': 'technical',
        'description': 'MA_BFQ_250 (250日均线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ma_bfq_250 AS MA_BFQ_250\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'EMA_BFQ_5',
        'category': 'technical',
        'description': 'EMA_BFQ_5 (5日指数移动平均，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ema_bfq_5 AS EMA_BFQ_5\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'EMA_BFQ_10',
        'category': 'technical',
        'description': 'EMA_BFQ_10 (10日指数移动平均，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ema_bfq_10 AS EMA_BFQ_10\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'EMA_BFQ_20',
        'category': 'technical',
        'description': 'EMA_BFQ_20 (20日指数移动平均，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ema_bfq_20 AS EMA_BFQ_20\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'EMA_BFQ_30',
        'category': 'technical',
        'description': 'EMA_BFQ_30 (30日指数移动平均，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ema_bfq_30 AS EMA_BFQ_30\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'EMA_BFQ_60',
        'category': 'technical',
        'description': 'EMA_BFQ_60 (60日指数移动平均，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ema_bfq_60 AS EMA_BFQ_60\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'EMA_BFQ_90',
        'category': 'technical',
        'description': 'EMA_BFQ_90 (90日指数移动平均，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ema_bfq_90 AS EMA_BFQ_90\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'EMA_BFQ_250',
        'category': 'technical',
        'description': 'EMA_BFQ_250 (250日指数移动平均，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, ema_bfq_250 AS '
                        'EMA_BFQ_250\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'RSI_BFQ_6',
        'category': 'technical',
        'description': 'RSI_BFQ_6 (6日相对强弱指标，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, rsi_bfq_6 AS RSI_BFQ_6\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'RSI_BFQ_12',
        'category': 'technical',
        'description': 'RSI_BFQ_12 (12日相对强弱指标，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, rsi_bfq_12 AS RSI_BFQ_12\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'RSI_BFQ_24',
        'category': 'technical',
        'description': 'RSI_BFQ_24 (24日相对强弱指标，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, rsi_bfq_24 AS RSI_BFQ_24\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'KDJ_BFQ',
        'category': 'technical',
        'description': 'KDJ_BFQ (KDJ综合指标，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, kdj_bfq AS KDJ_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'KDJ_K_BFQ',
        'category': 'technical',
        'description': 'KDJ_K_BFQ (KDJ K值，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, kdj_k_bfq AS KDJ_K_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'KDJ_D_BFQ',
        'category': 'technical',
        'description': 'KDJ_D_BFQ (KDJ D值，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, kdj_d_bfq AS KDJ_D_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MACD_BFQ',
        'category': 'technical',
        'description': 'MACD_BFQ (MACD柱状线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, macd_bfq AS MACD_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MACD_DIF_BFQ',
        'category': 'technical',
        'description': 'MACD_DIF_BFQ (MACD DIF线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, macd_dif_bfq AS '
                        'MACD_DIF_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MACD_DEA_BFQ',
        'category': 'technical',
        'description': 'MACD_DEA_BFQ (MACD DEA线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, macd_dea_bfq AS '
                        'MACD_DEA_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'BOLL_UPPER_BFQ',
        'category': 'technical',
        'description': 'BOLL_UPPER_BFQ (布林线上轨，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, boll_upper_bfq AS '
                        'BOLL_UPPER_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'BOLL_MID_BFQ',
        'category': 'technical',
        'description': 'BOLL_MID_BFQ (布林线中轨，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, boll_mid_bfq AS '
                        'BOLL_MID_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'BOLL_LOWER_BFQ',
        'category': 'technical',
        'description': 'BOLL_LOWER_BFQ (布林线下轨，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, boll_lower_bfq AS '
                        'BOLL_LOWER_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'CCI_BFQ',
        'category': 'technical',
        'description': 'CCI_BFQ (顺势指标，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, cci_bfq AS CCI_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'ATR_BFQ',
        'category': 'technical',
        'description': 'ATR_BFQ (Average True Range，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, atr_bfq AS ATR_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MTM_BFQ',
        'category': 'technical',
        'description': 'MTM_BFQ (动量指标，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, mtm_bfq AS MTM_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'MTMMA_BFQ',
        'category': 'technical',
        'description': 'MTMMA_BFQ (动量均线，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, mtmma_bfq AS MTMMA_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'ROC_BFQ',
        'category': 'technical',
        'description': 'ROC_BFQ (变动率指标，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, roc_bfq AS ROC_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'VR_BFQ',
        'category': 'technical',
        'description': 'VR_BFQ (成交量变异率，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, vr_bfq AS VR_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'OBV_BFQ',
        'category': 'technical',
        'description': 'OBV_BFQ (能量潮指标，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, obv_bfq AS OBV_BFQ\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'VOLUME_RATIO',
        'category': 'technical',
        'description': 'VOLUME_RATIO (量比，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, volume_ratio AS '
                        'VOLUME_RATIO\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'TURNOVER_RATE',
        'category': 'technical',
        'description': 'TURNOVER_RATE (换手率，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, turnover_rate AS '
                        'TURNOVER_RATE\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'TURNOVER_RATE_F',
        'category': 'technical',
        'description': 'TURNOVER_RATE_F (自由流通股本换手率，数据来源: stk_factor_pro)',
        'sql_template': '\n'
                        '            SELECT ts_code, CAST(trade_date AS VARCHAR) AS trade_date, turnover_rate_f AS '
                        'TURNOVER_RATE_F\n'
                        '            FROM stk_factor_pro\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'SUSPENDED_RECENTLY',
        'category': 'technical',
        'description': '近20天是否停牌',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), sus AS (SELECT "
                        'ts_code, trade_date AS sus_date, suspend_type, CAST(trade_date AS INTEGER) AS sd_int FROM '
                        'suspend_d), recent AS (SELECT d.ts_code, d.trade_date, MAX(CASE WHEN s.sd_int > CAST(d.td_int AS '
                        'INTEGER) - 2000 AND s.sd_int <= d.td_int THEN 1 ELSE 0 END) AS was_suspended FROM db d LEFT JOIN '
                        'sus s ON d.ts_code = s.ts_code GROUP BY d.ts_code, d.trade_date) SELECT ts_code, trade_date, '
                        'COALESCE(was_suspended, 0) AS SUSPENDED_RECENTLY FROM recent\n'
                        '        ',
        'enabled': True},
    {   'name': 'INDEX_WEIGHT_VALUE',
        'category': 'technical',
        'description': '指数权重值（ASOF最近）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), iw AS (SELECT "
                        'con_code AS ts_code, trade_date, CAST(weight AS DOUBLE) AS wt FROM index_weight WHERE con_code IS '
                        'NOT NULL), ranked AS (SELECT d.ts_code, d.trade_date, iw.wt, ROW_NUMBER() OVER (PARTITION BY '
                        'd.ts_code, d.trade_date ORDER BY iw.trade_date DESC) AS rn FROM db d LEFT JOIN iw ON d.ts_code = '
                        'iw.ts_code AND iw.trade_date <= d.trade_date) SELECT ts_code, trade_date, COALESCE(wt, 0) AS '
                        'INDEX_WEIGHT_VALUE FROM ranked WHERE rn = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'INDEX_WEIGHT_CHANGE',
        'category': 'technical',
        'description': '指数权重变化（季度填充 + 日频差分）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), iw AS (SELECT "
                        'con_code AS ts_code, trade_date, CAST(weight AS DOUBLE) AS wt FROM index_weight WHERE con_code IS '
                        'NOT NULL), ranked AS (SELECT d.ts_code, d.trade_date, iw.wt, ROW_NUMBER() OVER (PARTITION BY '
                        'd.ts_code, d.trade_date ORDER BY iw.trade_date DESC) AS rn FROM db d LEFT JOIN iw ON d.ts_code = '
                        'iw.ts_code AND iw.trade_date <= d.trade_date), filled AS (SELECT ts_code, trade_date, wt, '
                        'FIRST_VALUE(wt) OVER (PARTITION BY ts_code, grp ORDER BY trade_date) AS filled_wt FROM (SELECT '
                        'ts_code, trade_date, wt, COUNT(wt) OVER (PARTITION BY ts_code ORDER BY trade_date) - ROW_NUMBER() '
                        'OVER (PARTITION BY ts_code ORDER BY trade_date) AS grp FROM ranked WHERE rn = 1) t) SELECT '
                        'ts_code, trade_date, COALESCE(filled_wt, 0) - COALESCE(LAG(filled_wt, 1) OVER (PARTITION BY '
                        'ts_code ORDER BY trade_date), 0) AS INDEX_WEIGHT_CHANGE FROM filled\n'
                        '        ',
        'enabled': True}
]