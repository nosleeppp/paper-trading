# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 财务 因子定义
包含 134 个财务类因子。
由 config.py 聚合后统一暴露。
"""

CATEGORY = "financial"

FACTORS = [
    {   'name': 'ROE_QUARTER',
        'category': 'financial',
        'description': '季度ROE（LPAD 字符串排序键）',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                f.q_roe AS ROE_QUARTER\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS trade_date_int\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '            LEFT JOIN LATERAL (\n'
                        '                SELECT q_roe\n'
                        '                FROM fina_indicator_sorted f\n'
                        '                WHERE f.ts_code = p.ts_code\n'
                        '                  AND f.end_date_int <= p.trade_date_int\n'
                        '                  AND f.ann_date_int <= p.trade_date_int\n'
                        '                ORDER BY f.sort_key_str DESC\n'
                        '                LIMIT 1\n'
                        '            ) f ON true\n'
                        '        ',
        'enabled': True},
    {   'name': 'ROA_QUARTER',
        'category': 'financial',
        'description': '季度ROA（预计算排名方案）',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                f.roa AS ROA_QUARTER\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS trade_date_int\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '            LEFT JOIN LATERAL (\n'
                        '                SELECT roa\n'
                        '                FROM fina_indicator_sorted f\n'
                        '                WHERE f.ts_code = p.ts_code\n'
                        '                  AND f.end_date_int <= p.trade_date_int\n'
                        '                  AND f.ann_date_int <= p.trade_date_int\n'
                        '                ORDER BY f.sort_key_str DESC\n'
                        '                LIMIT 1\n'
                        '            ) f ON true\n'
                        '        ',
        'enabled': True},
    {   'name': 'DELTA_ROE',
        'category': 'financial',
        'description': 'ROE同比变化（预计算排名方案）',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                f.roe_yoy AS DELTA_ROE\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS trade_date_int\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '            LEFT JOIN LATERAL (\n'
                        '                SELECT roe_yoy\n'
                        '                FROM fina_indicator_sorted f\n'
                        '                WHERE f.ts_code = p.ts_code\n'
                        '                  AND f.end_date_int <= p.trade_date_int\n'
                        '                  AND f.ann_date_int <= p.trade_date_int\n'
                        '                ORDER BY f.sort_key_str DESC\n'
                        '                LIMIT 1\n'
                        '            ) f ON true\n'
                        '        ',
        'enabled': True},
    {   'name': 'DELTA_ROA',
        'category': 'financial',
        'description': 'ROA同比变化（预计算排名方案）',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                f.roa AS DELTA_ROA\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS trade_date_int\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '            LEFT JOIN LATERAL (\n'
                        '                SELECT roa\n'
                        '                FROM fina_indicator_sorted f\n'
                        '                WHERE f.ts_code = p.ts_code\n'
                        '                  AND f.end_date_int <= p.trade_date_int\n'
                        '                  AND f.ann_date_int <= p.trade_date_int\n'
                        '                ORDER BY f.sort_key_str DESC\n'
                        '                LIMIT 1\n'
                        '            ) f ON true\n'
                        '        ',
        'enabled': True},
    {   'name': 'EP_QUARTER',
        'category': 'financial',
        'description': '季度盈利市值比（LPAD 字符串排序键）',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                CASE \n'
                        '                    WHEN f.net_profit > 0 AND p.total_mv > 0 \n'
                        '                        THEN f.net_profit / p.total_mv\n'
                        '                    ELSE NULL\n'
                        '                END AS EP_QUARTER\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, total_mv, CAST(trade_date AS INTEGER) AS '
                        'trade_date_int\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '            LEFT JOIN LATERAL (\n'
                        '                SELECT net_profit\n'
                        '                FROM income_sorted f\n'
                        '                WHERE f.ts_code = p.ts_code\n'
                        '                  AND f.end_date_int <= p.trade_date_int\n'
                        '                  AND f.ann_date_int <= p.trade_date_int\n'
                        '                  AND f.f_ann_date_int <= p.trade_date_int\n'
                        '                ORDER BY f.sort_key_str DESC\n'
                        '                LIMIT 1\n'
                        '            ) f ON true\n'
                        '        ',
        'enabled': True},
    {   'name': 'SP_QUARTER',
        'category': 'financial',
        'description': '季度销售市值比（预计算排名方案）',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                p.ts_code,\n'
                        '                p.trade_date,\n'
                        '                CASE \n'
                        '                    WHEN f.revenue > 0 AND p.total_mv > 0 \n'
                        '                        THEN f.revenue / p.total_mv\n'
                        '                    ELSE NULL\n'
                        '                END AS SP_QUARTER\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, total_mv, CAST(trade_date AS INTEGER) AS '
                        'trade_date_int\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '            ) p\n'
                        '            LEFT JOIN LATERAL (\n'
                        '                SELECT revenue\n'
                        '                FROM income_sorted f\n'
                        '                WHERE f.ts_code = p.ts_code\n'
                        '                  AND f.end_date_int <= p.trade_date_int\n'
                        '                  AND f.ann_date_int <= p.trade_date_int\n'
                        '                  AND f.f_ann_date_int <= p.trade_date_int\n'
                        '                ORDER BY f.sort_key_str DESC\n'
                        '                LIMIT 1\n'
                        '            ) f ON true\n'
                        '        ',
        'enabled': True},
    {   'name': 'YOY_QUARTER_NP',
        'category': 'financial',
        'description': '季度净利润同比增长率（LPAD 字符串排序键）',
        'sql_template': '\n'
                        '            WITH curr AS (\n'
                        '                SELECT \n'
                        '                    p.ts_code,\n'
                        '                    p.trade_date,\n'
                        '                    p.trade_date_int,\n'
                        '                    f.end_date_int,\n'
                        '                    f.ann_date_int,\n'
                        '                    f.f_ann_date_int,\n'
                        '                    f.net_profit\n'
                        '                FROM (\n'
                        '                    SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS trade_date_int\n'
                        '                    FROM daily_basic\n'
                        "                    WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '                ) p\n'
                        '                LEFT JOIN LATERAL (\n'
                        '                    SELECT end_date_int, ann_date_int, f_ann_date_int, net_profit\n'
                        '                    FROM income_sorted f\n'
                        '                    WHERE f.ts_code = p.ts_code\n'
                        '                      AND f.end_date_int <= p.trade_date_int\n'
                        '                      AND f.ann_date_int <= p.trade_date_int\n'
                        '                      AND f.f_ann_date_int <= p.trade_date_int\n'
                        '                    ORDER BY f.sort_key_str DESC\n'
                        '                    LIMIT 1\n'
                        '                ) f ON true\n'
                        '            ),\n'
                        '            ly AS (\n'
                        '                SELECT \n'
                        '                    c.ts_code,\n'
                        '                    c.trade_date,\n'
                        '                    f.net_profit AS net_profit_ly\n'
                        '                FROM curr c\n'
                        '                LEFT JOIN LATERAL (\n'
                        '                    SELECT net_profit\n'
                        '                    FROM income_sorted f\n'
                        '                    WHERE f.ts_code = c.ts_code\n'
                        '                      AND f.end_date_int = c.end_date_int - 10000\n'
                        '                      AND f.ann_date_int <= c.trade_date_int\n'
                        '                      AND f.f_ann_date_int <= c.trade_date_int\n'
                        '                    ORDER BY f.sort_key_str DESC\n'
                        '                    LIMIT 1\n'
                        '                ) f ON true\n'
                        '            )\n'
                        '            SELECT \n'
                        '                c.ts_code,\n'
                        '                c.trade_date,\n'
                        '                CASE \n'
                        '                    WHEN l.net_profit_ly IS NOT NULL AND l.net_profit_ly != 0 THEN\n'
                        '                        CASE \n'
                        '                            WHEN l.net_profit_ly < 0 THEN -(c.net_profit / l.net_profit_ly - 1) * '
                        '100\n'
                        '                            ELSE (c.net_profit / l.net_profit_ly - 1) * 100\n'
                        '                        END\n'
                        '                    ELSE NULL\n'
                        '                END AS YOY_QUARTER_NP\n'
                        '            FROM curr c\n'
                        '            LEFT JOIN ly l ON c.ts_code = l.ts_code AND c.trade_date = l.trade_date\n'
                        '        ',
        'enabled': True},
    {   'name': 'YOY_QUARTER_OR',
        'category': 'financial',
        'description': '季度营业收入同比增长率（LPAD 字符串排序键）',
        'sql_template': '\n'
                        '            WITH curr AS (\n'
                        '                SELECT \n'
                        '                    p.ts_code,\n'
                        '                    p.trade_date,\n'
                        '                    p.trade_date_int,\n'
                        '                    f.end_date_int,\n'
                        '                    f.ann_date_int,\n'
                        '                    f.f_ann_date_int,\n'
                        '                    f.revenue\n'
                        '                FROM (\n'
                        '                    SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS trade_date_int\n'
                        '                    FROM daily_basic\n'
                        "                    WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '                ) p\n'
                        '                LEFT JOIN LATERAL (\n'
                        '                    SELECT end_date_int, ann_date_int, f_ann_date_int, revenue\n'
                        '                    FROM income_sorted f\n'
                        '                    WHERE f.ts_code = p.ts_code\n'
                        '                      AND f.end_date_int <= p.trade_date_int\n'
                        '                      AND f.ann_date_int <= p.trade_date_int\n'
                        '                      AND f.f_ann_date_int <= p.trade_date_int\n'
                        '                    ORDER BY f.sort_key_str DESC\n'
                        '                    LIMIT 1\n'
                        '                ) f ON true\n'
                        '            ),\n'
                        '            ly AS (\n'
                        '                SELECT \n'
                        '                    c.ts_code,\n'
                        '                    c.trade_date,\n'
                        '                    f.revenue AS revenue_ly\n'
                        '                FROM curr c\n'
                        '                LEFT JOIN LATERAL (\n'
                        '                    SELECT revenue\n'
                        '                    FROM income_sorted f\n'
                        '                    WHERE f.ts_code = c.ts_code\n'
                        '                      AND f.end_date_int = c.end_date_int - 10000\n'
                        '                      AND f.ann_date_int <= c.trade_date_int\n'
                        '                      AND f.f_ann_date_int <= c.trade_date_int\n'
                        '                    ORDER BY f.sort_key_str DESC\n'
                        '                    LIMIT 1\n'
                        '                ) f ON true\n'
                        '            )\n'
                        '            SELECT \n'
                        '                c.ts_code,\n'
                        '                c.trade_date,\n'
                        '                CASE \n'
                        '                    WHEN l.revenue_ly IS NOT NULL AND l.revenue_ly != 0 THEN\n'
                        '                        CASE \n'
                        '                            WHEN l.revenue_ly < 0 THEN -(c.revenue / l.revenue_ly - 1) * 100\n'
                        '                            ELSE (c.revenue / l.revenue_ly - 1) * 100\n'
                        '                        END\n'
                        '                    ELSE NULL\n'
                        '                END AS YOY_QUARTER_OR\n'
                        '            FROM curr c\n'
                        '            LEFT JOIN ly l ON c.ts_code = l.ts_code AND c.trade_date = l.trade_date\n'
                        '        ',
        'enabled': True},
    {   'name': 'YOY_QUARTER_OP',
        'category': 'financial',
        'description': '季度营业利润同比增长率（LPAD 字符串排序键）',
        'sql_template': '\n'
                        '            WITH curr AS (\n'
                        '                SELECT \n'
                        '                    p.ts_code,\n'
                        '                    p.trade_date,\n'
                        '                    p.trade_date_int,\n'
                        '                    f.end_date_int,\n'
                        '                    f.ann_date_int,\n'
                        '                    f.f_ann_date_int,\n'
                        '                    f.operate_profit\n'
                        '                FROM (\n'
                        '                    SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS trade_date_int\n'
                        '                    FROM daily_basic\n'
                        "                    WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '                ) p\n'
                        '                LEFT JOIN LATERAL (\n'
                        '                    SELECT end_date_int, ann_date_int, f_ann_date_int, operate_profit\n'
                        '                    FROM income_sorted f\n'
                        '                    WHERE f.ts_code = p.ts_code\n'
                        '                      AND f.end_date_int <= p.trade_date_int\n'
                        '                      AND f.ann_date_int <= p.trade_date_int\n'
                        '                      AND f.f_ann_date_int <= p.trade_date_int\n'
                        '                    ORDER BY f.sort_key_str DESC\n'
                        '                    LIMIT 1\n'
                        '                ) f ON true\n'
                        '            ),\n'
                        '            ly AS (\n'
                        '                SELECT \n'
                        '                    c.ts_code,\n'
                        '                    c.trade_date,\n'
                        '                    f.operate_profit AS operate_profit_ly\n'
                        '                FROM curr c\n'
                        '                LEFT JOIN LATERAL (\n'
                        '                    SELECT operate_profit\n'
                        '                    FROM income_sorted f\n'
                        '                    WHERE f.ts_code = c.ts_code\n'
                        '                      AND f.end_date_int = c.end_date_int - 10000\n'
                        '                      AND f.ann_date_int <= c.trade_date_int\n'
                        '                      AND f.f_ann_date_int <= c.trade_date_int\n'
                        '                    ORDER BY f.sort_key_str DESC\n'
                        '                    LIMIT 1\n'
                        '                ) f ON true\n'
                        '            )\n'
                        '            SELECT \n'
                        '                c.ts_code,\n'
                        '                c.trade_date,\n'
                        '                CASE \n'
                        '                    WHEN l.operate_profit_ly IS NOT NULL AND l.operate_profit_ly != 0 THEN\n'
                        '                        CASE \n'
                        '                            WHEN l.operate_profit_ly < 0 THEN -(c.operate_profit / '
                        'l.operate_profit_ly - 1) * 100\n'
                        '                            ELSE (c.operate_profit / l.operate_profit_ly - 1) * 100\n'
                        '                        END\n'
                        '                    ELSE NULL\n'
                        '                END AS YOY_QUARTER_OP\n'
                        '            FROM curr c\n'
                        '            LEFT JOIN ly l ON c.ts_code = l.ts_code AND c.trade_date = l.trade_date\n'
                        '        ',
        'enabled': True},
    {   'name': 'HOLDER_NUM_CHANGE',
        'category': 'financial',
        'description': '股东户数变化率（相邻两期）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), hn AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, holder_num, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM stk_holdernumber), hnl AS (SELECT ts_code, end_date, ann_date, ed_int, ad_int, holder_num '
                        'FROM hn WHERE rn = 1), with_latest AS (SELECT d.ts_code, d.trade_date, l.holder_num FROM db d '
                        'LEFT JOIN LATERAL (SELECT hnl.holder_num FROM hnl WHERE hnl.ts_code = d.ts_code AND hnl.ed_int <= '
                        'd.td_int AND hnl.ad_int <= d.td_int ORDER BY hnl.ann_date DESC LIMIT 1) l ON TRUE), with_lag AS '
                        '(SELECT ts_code, trade_date, holder_num, LAG(holder_num, 4) OVER (PARTITION BY ts_code ORDER BY '
                        'trade_date) AS prev_hn FROM with_latest WHERE holder_num IS NOT NULL) SELECT ts_code, trade_date, '
                        'CASE WHEN prev_hn > 0 AND prev_hn IS NOT NULL THEN (holder_num - prev_hn) / prev_hn END AS '
                        'HOLDER_NUM_CHANGE FROM with_lag WHERE holder_num IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'OCF_TO_NETPROFIT',
        'category': 'financial',
        'description': '经营现金流/归属母公司净利润（修复版：分母改用income表）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.n_cashflow_act FROM db d LEFT JOIN LATERAL (SELECT n_cashflow_act FROM '
                        'fina_cashflow_vip_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND ann_date_int <= '
                        "d.td_int AND f_ann_date_int <= d.td_int ORDER BY LPAD(end_date_int::VARCHAR, 8, '0') || '|' || "
                        "LPAD(ann_date_int::VARCHAR, 8, '0') || '|' || LPAD(f_ann_date_int::VARCHAR, 8, '0') DESC LIMIT 1) "
                        't ON true), inc_j AS (SELECT d.ts_code, d.trade_date, t.net_profit FROM db d LEFT JOIN LATERAL '
                        '(SELECT net_profit FROM income_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND '
                        'ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY LPAD(end_date_int::VARCHAR, 8, '
                        "'0') || '|' || LPAD(ann_date_int::VARCHAR, 8, '0') || '|' || LPAD(f_ann_date_int::VARCHAR, 8, "
                        "'0') DESC LIMIT 1) t ON true) SELECT c.ts_code, c.trade_date, CASE WHEN i.net_profit > 0 AND "
                        'i.net_profit IS NOT NULL THEN c.n_cashflow_act / i.net_profit END AS OCF_TO_NETPROFIT FROM cf_j c '
                        'LEFT JOIN inc_j i ON c.ts_code = i.ts_code AND c.trade_date = i.trade_date WHERE c.n_cashflow_act '
                        'IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'OCF_TO_REVENUE',
        'category': 'financial',
        'description': '经营现金流/营业收入',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.n_cashflow_act FROM db d LEFT JOIN LATERAL (SELECT n_cashflow_act FROM '
                        'fina_cashflow_vip_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND ann_date_int <= '
                        "d.td_int AND f_ann_date_int <= d.td_int ORDER BY LPAD(end_date_int::VARCHAR, 8, '0') || '|' || "
                        "LPAD(ann_date_int::VARCHAR, 8, '0') || '|' || LPAD(f_ann_date_int::VARCHAR, 8, '0') DESC LIMIT 1) "
                        't ON true), inc_j AS (SELECT d.ts_code, d.trade_date, t.revenue FROM db d LEFT JOIN LATERAL '
                        '(SELECT revenue FROM income_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND '
                        'ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY LPAD(end_date_int::VARCHAR, 8, '
                        "'0') || '|' || LPAD(ann_date_int::VARCHAR, 8, '0') || '|' || LPAD(f_ann_date_int::VARCHAR, 8, "
                        "'0') DESC LIMIT 1) t ON true) SELECT c.ts_code, c.trade_date, CASE WHEN i.revenue > 0 AND "
                        'i.revenue IS NOT NULL THEN c.n_cashflow_act / i.revenue END AS OCF_TO_REVENUE FROM cf_j c LEFT '
                        'JOIN inc_j i ON c.ts_code = i.ts_code AND c.trade_date = i.trade_date WHERE c.n_cashflow_act IS '
                        'NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'AR_TURNOVER_CHANGE',
        'category': 'financial',
        'description': '应收周转率变化（相邻两期）',
        'sql_template': '\n'
                        '            WITH curr AS (\n'
                        '                SELECT\n'
                        '                    p.ts_code, p.trade_date, p.trade_date_int,\n'
                        '                    CASE WHEN i.revenue > 0\n'
                        '                         THEN b.accounts_receiv / i.revenue\n'
                        '                         ELSE NULL END AS ar_ratio\n'
                        '                FROM (\n'
                        '                    SELECT ts_code, trade_date,\n'
                        '                           CAST(trade_date AS INTEGER) AS trade_date_int\n'
                        '                    FROM daily_basic\n'
                        "                    WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '                ) p\n'
                        '                LEFT JOIN LATERAL (\n'
                        '                    SELECT accounts_receiv\n'
                        '                    FROM fina_balancesheet_vip_prep b\n'
                        '                    WHERE b.ts_code = p.ts_code\n'
                        '                      AND b.end_date_int <= p.trade_date_int\n'
                        '                      AND b.ann_date_int <= p.trade_date_int\n'
                        '                      AND b.f_ann_date_int <= p.trade_date_int\n'
                        '                    ORDER BY b.sort_key_str DESC LIMIT 1\n'
                        '                ) b ON true\n'
                        '                LEFT JOIN LATERAL (\n'
                        '                    SELECT revenue\n'
                        '                    FROM income_sorted i\n'
                        '                    WHERE i.ts_code = p.ts_code\n'
                        '                      AND i.end_date_int <= p.trade_date_int\n'
                        '                      AND i.ann_date_int <= p.trade_date_int\n'
                        '                      AND i.f_ann_date_int <= p.trade_date_int\n'
                        '                    ORDER BY i.sort_key_str DESC LIMIT 1\n'
                        '                ) i ON true\n'
                        '            )\n'
                        '            SELECT ts_code, trade_date,\n'
                        '                ar_ratio - prev_ar_ratio AS AR_TURNOVER_CHANGE\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, ar_ratio,\n'
                        '                       LAG(ar_ratio) OVER (PARTITION BY ts_code ORDER BY trade_date) AS '
                        'prev_ar_ratio\n'
                        '                FROM curr\n'
                        '                WHERE ar_ratio IS NOT NULL\n'
                        '            ) t\n'
                        '            WHERE prev_ar_ratio IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'GOODWILL_RATIO',
        'category': 'financial',
        'description': '商誉占比（商誉/总资产）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, goodwill, total_assets, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int '
                        'DESC) AS rn FROM fina_balancesheet_vip), ball AS (SELECT * FROM bal WHERE rn = 1), q1 AS (SELECT '
                        'd.ts_code, d.trade_date, ball.goodwill, ball.total_assets, ROW_NUMBER() OVER (PARTITION BY '
                        'd.ts_code, d.trade_date ORDER BY ball.ed_int DESC) AS q_rank FROM db d LEFT JOIN ball ON '
                        'd.ts_code = ball.ts_code AND ball.ed_int <= d.td_int AND ball.ad_int <= d.td_int) SELECT ts_code, '
                        'trade_date, CASE WHEN total_assets > 0 AND total_assets IS NOT NULL THEN goodwill / total_assets '
                        'END AS GOODWILL_RATIO FROM q1 WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'DEBT_ASSET_RATIO_CHANGE',
        'category': 'financial',
        'description': '资产负债率变化（相邻两期，过滤总资产<1亿的异常记录）',
        'sql_template': '\n'
                        '            WITH curr AS (\n'
                        '                SELECT\n'
                        '                    p.ts_code, p.trade_date, p.trade_date_int,\n'
                        '                    CASE WHEN f.total_assets >= 100000000\n'
                        '                         THEN f.total_liab / f.total_assets\n'
                        '                         ELSE NULL END AS debt_ratio\n'
                        '                FROM (\n'
                        '                    SELECT ts_code, trade_date,\n'
                        '                           CAST(trade_date AS INTEGER) AS trade_date_int\n'
                        '                    FROM daily_basic\n'
                        "                    WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '                ) p\n'
                        '                LEFT JOIN LATERAL (\n'
                        '                    SELECT total_liab, total_assets\n'
                        '                    FROM fina_balancesheet_vip_prep b\n'
                        '                    WHERE b.ts_code = p.ts_code\n'
                        '                      AND b.end_date_int <= p.trade_date_int\n'
                        '                      AND b.ann_date_int <= p.trade_date_int\n'
                        '                      AND b.f_ann_date_int <= p.trade_date_int\n'
                        '                    ORDER BY b.sort_key_str DESC LIMIT 1\n'
                        '                ) f ON true\n'
                        '            )\n'
                        '            SELECT ts_code, trade_date,\n'
                        '                debt_ratio - prev_ratio AS DEBT_ASSET_RATIO_CHANGE\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, debt_ratio,\n'
                        '                       LAG(debt_ratio) OVER (PARTITION BY ts_code ORDER BY trade_date) AS '
                        'prev_ratio\n'
                        '                FROM curr\n'
                        '                WHERE debt_ratio IS NOT NULL\n'
                        '            ) t\n'
                        '            WHERE prev_ratio IS NOT NULL\n'
                        '              AND debt_ratio IS NOT NULL\n'
                        '              AND debt_ratio BETWEEN 0 AND 10\n'
                        '              AND prev_ratio BETWEEN 0 AND 10\n'
                        '        ',
        'enabled': True},
    {   'name': 'REVENUE_TTM',
        'category': 'financial',
        'description': '营业收入TTM（滚动4季）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ttm AS (SELECT "
                        'd.ts_code, d.trade_date, SUM(t.revenue) AS sum_val FROM db d LEFT JOIN income_ttm_prep t ON '
                        'd.ts_code = t.ts_code AND t.end_date_int <= d.td_int AND t.ann_date_int <= d.td_int AND '
                        't.f_ann_date_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, trade_date, '
                        'sum_val AS REVENUE_TTM FROM ttm WHERE sum_val IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'GROSS_PROFIT_TTM',
        'category': 'financial',
        'description': '毛利润TTM（滚动4季）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ttm AS (SELECT "
                        'd.ts_code, d.trade_date, SUM(t.gross_profit) AS sum_val FROM db d LEFT JOIN income_ttm_prep t ON '
                        'd.ts_code = t.ts_code AND t.end_date_int <= d.td_int AND t.ann_date_int <= d.td_int AND '
                        't.f_ann_date_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, trade_date, '
                        'sum_val AS GROSS_PROFIT_TTM FROM ttm WHERE sum_val IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'OPERATE_PROFIT_TTM',
        'category': 'financial',
        'description': '营业利润TTM（滚动4季）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ttm AS (SELECT "
                        'd.ts_code, d.trade_date, SUM(t.operate_profit) AS sum_val FROM db d LEFT JOIN income_ttm_prep t '
                        'ON d.ts_code = t.ts_code AND t.end_date_int <= d.td_int AND t.ann_date_int <= d.td_int AND '
                        't.f_ann_date_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, trade_date, '
                        'sum_val AS OPERATE_PROFIT_TTM FROM ttm WHERE sum_val IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'EBIT_TTM',
        'category': 'financial',
        'description': 'EBIT TTM（用利润总额+所得税近似）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ttm AS (SELECT "
                        'd.ts_code, d.trade_date, SUM(t.total_profit + t.income_tax) AS sum_val FROM db d LEFT JOIN '
                        'income_ttm_prep t ON d.ts_code = t.ts_code AND t.end_date_int <= d.td_int AND t.ann_date_int <= '
                        'd.td_int AND t.f_ann_date_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, '
                        'trade_date, sum_val AS EBIT_TTM FROM ttm WHERE sum_val IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'GROSS_MARGIN_TTM',
        'category': 'financial',
        'description': '毛利率TTM',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ttm AS (SELECT "
                        'd.ts_code, d.trade_date, SUM(t.gross_profit) AS gp, SUM(t.revenue) AS rev FROM db d LEFT JOIN '
                        'income_ttm_prep t ON d.ts_code = t.ts_code AND t.end_date_int <= d.td_int AND t.ann_date_int <= '
                        'd.td_int AND t.f_ann_date_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, '
                        'trade_date, CASE WHEN rev > 0 AND rev IS NOT NULL THEN gp / rev END AS GROSS_MARGIN_TTM FROM ttm '
                        'WHERE gp IS NOT NULL AND rev > 0\n'
                        '        ',
        'enabled': True},
    {   'name': 'OPERATE_MARGIN_TTM',
        'category': 'financial',
        'description': '营业利润率TTM',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ttm AS (SELECT "
                        'd.ts_code, d.trade_date, SUM(t.operate_profit) AS op, SUM(t.revenue) AS rev FROM db d LEFT JOIN '
                        'income_ttm_prep t ON d.ts_code = t.ts_code AND t.end_date_int <= d.td_int AND t.ann_date_int <= '
                        'd.td_int AND t.f_ann_date_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, '
                        'trade_date, CASE WHEN rev > 0 AND rev IS NOT NULL THEN op / rev END AS OPERATE_MARGIN_TTM FROM '
                        'ttm WHERE op IS NOT NULL AND rev > 0\n'
                        '        ',
        'enabled': True},
    {   'name': 'NET_MARGIN_TTM',
        'category': 'financial',
        'description': '净利润率TTM',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ttm AS (SELECT "
                        'd.ts_code, d.trade_date, SUM(t.net_profit) AS ni, SUM(t.revenue) AS rev FROM db d LEFT JOIN '
                        'income_ttm_prep t ON d.ts_code = t.ts_code AND t.end_date_int <= d.td_int AND t.ann_date_int <= '
                        'd.td_int AND t.f_ann_date_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, '
                        'trade_date, CASE WHEN rev > 0 AND rev IS NOT NULL THEN ni / rev END AS NET_MARGIN_TTM FROM ttm '
                        'WHERE ni IS NOT NULL AND rev > 0\n'
                        '        ',
        'enabled': True},
    {   'name': 'EBITDA_MARGIN_TTM',
        'category': 'financial',
        'description': 'EBITDA利润率TTM',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ttm AS (SELECT "
                        'd.ts_code, d.trade_date, SUM(t.ebitda) AS ebitda_val, SUM(t.revenue) AS rev FROM db d LEFT JOIN '
                        'income_ttm_prep t ON d.ts_code = t.ts_code AND t.end_date_int <= d.td_int AND t.ann_date_int <= '
                        'd.td_int AND t.f_ann_date_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, '
                        'trade_date, CASE WHEN rev > 0 AND rev IS NOT NULL THEN ebitda_val / rev END AS EBITDA_MARGIN_TTM '
                        'FROM ttm WHERE ebitda_val IS NOT NULL AND rev > 0\n'
                        '        ',
        'enabled': True},
    {   'name': 'REVENUE_YOY',
        'category': 'financial',
        'description': '营业收入同比增速（TTM）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q4 AS (SELECT d.ts_code, d.trade_date, '
                        'i.revenue, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY i.ed_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= d.td_int AND i.ad_int <= '
                        'd.td_int), ttm AS (SELECT ts_code, trade_date, SUM(revenue) FILTER (WHERE q_rank BETWEEN 1 AND 4) '
                        'AS rev_ttm FROM q4 GROUP BY ts_code, trade_date), yoy AS (SELECT ts_code, trade_date, rev_ttm, '
                        'LAG(rev_ttm, 4) OVER (PARTITION BY ts_code ORDER BY trade_date) AS rev_lag FROM ttm) SELECT '
                        'ts_code, trade_date, CASE WHEN rev_lag != 0 AND rev_lag IS NOT NULL THEN (rev_ttm - rev_lag) / '
                        'ABS(rev_lag) END AS REVENUE_YOY FROM yoy\n'
                        '        ',
        'enabled': True},
    {   'name': 'OPERATE_PROFIT_YOY',
        'category': 'financial',
        'description': '营业利润同比增速（TTM）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, operate_profit, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q4 AS (SELECT d.ts_code, '
                        'd.trade_date, i.operate_profit, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY '
                        'i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= '
                        'd.td_int AND i.ad_int <= d.td_int), ttm AS (SELECT ts_code, trade_date, SUM(operate_profit) '
                        'FILTER (WHERE q_rank BETWEEN 1 AND 4) AS op_ttm FROM q4 GROUP BY ts_code, trade_date), yoy AS '
                        '(SELECT ts_code, trade_date, op_ttm, LAG(op_ttm, 4) OVER (PARTITION BY ts_code ORDER BY '
                        'trade_date) AS op_lag FROM ttm) SELECT ts_code, trade_date, CASE WHEN op_lag != 0 AND op_lag IS '
                        'NOT NULL THEN (op_ttm - op_lag) / ABS(op_lag) END AS OPERATE_PROFIT_YOY FROM yoy\n'
                        '        ',
        'enabled': True},
    {   'name': 'N_INCOME_YOY',
        'category': 'financial',
        'description': '归母净利润同比增速（TTM）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, n_income_attr_p, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q4 AS (SELECT d.ts_code, '
                        'd.trade_date, i.n_income_attr_p, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY '
                        'i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= '
                        'd.td_int AND i.ad_int <= d.td_int), ttm AS (SELECT ts_code, trade_date, SUM(n_income_attr_p) '
                        'FILTER (WHERE q_rank BETWEEN 1 AND 4) AS ni_ttm FROM q4 GROUP BY ts_code, trade_date), yoy AS '
                        '(SELECT ts_code, trade_date, ni_ttm, LAG(ni_ttm, 4) OVER (PARTITION BY ts_code ORDER BY '
                        'trade_date) AS ni_lag FROM ttm) SELECT ts_code, trade_date, CASE WHEN ni_lag != 0 AND ni_lag IS '
                        'NOT NULL THEN (ni_ttm - ni_lag) / ABS(ni_lag) END AS N_INCOME_YOY FROM yoy\n'
                        '        ',
        'enabled': True},
    {   'name': 'EPS_GROWTH',
        'category': 'financial',
        'description': 'EPS同比增速（TTM）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi_dedup AS (SELECT "
                        'DISTINCT ON (ts_code, end_date) ts_code, end_date AS report_date, CAST(eps AS DOUBLE) AS eps, '
                        "CAST(end_date AS INTEGER) AS ed_int FROM fina_indicator WHERE end_date >= '20170101' ORDER BY "
                        'ts_code, end_date, ann_date DESC), all_fi AS (SELECT d.ts_code, d.trade_date, d.td_int, '
                        'b.report_date, b.eps, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY b.ed_int '
                        'DESC) AS q_rank FROM db d ASOF LEFT JOIN fi_dedup b ON d.ts_code = b.ts_code AND d.trade_date >= '
                        'b.report_date), ttm AS (SELECT ts_code, trade_date, SUM(eps) FILTER (WHERE q_rank BETWEEN 1 AND '
                        '4) AS eps_ttm FROM all_fi GROUP BY ts_code, trade_date), yoy AS (SELECT ts_code, trade_date, '
                        'eps_ttm, LAG(eps_ttm, 4) OVER (PARTITION BY ts_code ORDER BY trade_date) AS eps_lag FROM ttm) '
                        'SELECT ts_code, trade_date, CASE WHEN eps_lag != 0 AND eps_lag IS NOT NULL THEN (eps_ttm - '
                        'eps_lag) / ABS(eps_lag) END AS EPS_GROWTH FROM yoy\n'
                        '        ',
        'enabled': True},
    {   'name': 'REVENUE_STD_8Q',
        'category': 'financial',
        'description': '营业收入波动系数（8季）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q8 AS (SELECT d.ts_code, d.trade_date, '
                        'i.revenue, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY i.ed_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= d.td_int AND i.ad_int <= '
                        'd.td_int), stats AS (SELECT ts_code, trade_date, AVG(revenue) FILTER (WHERE q_rank BETWEEN 1 AND '
                        '8) AS rev_mean, STDDEV_SAMP(revenue) FILTER (WHERE q_rank BETWEEN 1 AND 8) AS rev_std FROM q8 '
                        'GROUP BY ts_code, trade_date) SELECT ts_code, trade_date, CASE WHEN rev_mean != 0 AND rev_mean IS '
                        'NOT NULL THEN rev_std / ABS(rev_mean) END AS REVENUE_STD_8Q FROM stats\n'
                        '        ',
        'enabled': True},
    {   'name': 'EARNINGS_STD_8Q',
        'category': 'financial',
        'description': '净利润波动系数（8季）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, n_income_attr_p, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q8 AS (SELECT d.ts_code, '
                        'd.trade_date, i.n_income_attr_p, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY '
                        'i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= '
                        'd.td_int AND i.ad_int <= d.td_int), stats AS (SELECT ts_code, trade_date, AVG(n_income_attr_p) '
                        'FILTER (WHERE q_rank BETWEEN 1 AND 8) AS ni_mean, STDDEV_SAMP(n_income_attr_p) FILTER (WHERE '
                        'q_rank BETWEEN 1 AND 8) AS ni_std FROM q8 GROUP BY ts_code, trade_date) SELECT ts_code, '
                        'trade_date, CASE WHEN ni_mean != 0 AND ni_mean IS NOT NULL THEN ni_std / ABS(ni_mean) END AS '
                        'EARNINGS_STD_8Q FROM stats\n'
                        '        ',
        'enabled': True},
    {   'name': 'EARNINGS_STABILITY',
        'category': 'financial',
        'description': '盈利稳定性（近8季盈利比例）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, n_income_attr_p, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q8 AS (SELECT d.ts_code, '
                        'd.trade_date, i.n_income_attr_p, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY '
                        'i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= '
                        'd.td_int AND i.ad_int <= d.td_int), pos AS (SELECT ts_code, trade_date, SUM(CASE WHEN '
                        'n_income_attr_p > 0 THEN 1 ELSE 0 END) FILTER (WHERE q_rank BETWEEN 1 AND 8) AS pos_cnt FROM q8 '
                        'GROUP BY ts_code, trade_date) SELECT ts_code, trade_date, CAST(pos_cnt AS DOUBLE) / 8.0 AS '
                        'EARNINGS_STABILITY FROM pos\n'
                        '        ',
        'enabled': True},
    {   'name': 'SELL_EXP_RATIO',
        'category': 'financial',
        'description': '销售费用占收入比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, sell_exp, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int '
                        "DESC) AS rn FROM income_vip WHERE end_date <= '{end_dt}' AND ann_date <= '{end_dt}'), il AS "
                        '(SELECT * FROM inc WHERE rn = 1), q1 AS (SELECT d.ts_code, d.trade_date, i.revenue, i.sell_exp, '
                        'ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY i.ed_int DESC) AS q_rank FROM db '
                        'd LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= d.td_int AND i.ad_int <= d.td_int) '
                        'SELECT ts_code, trade_date, CASE WHEN SUM(revenue) FILTER (WHERE q_rank = 1) > 0 THEN '
                        'SUM(sell_exp) FILTER (WHERE q_rank = 1) / SUM(revenue) FILTER (WHERE q_rank = 1) END AS '
                        'SELL_EXP_RATIO FROM q1 GROUP BY ts_code, trade_date\n'
                        '        ',
        'enabled': True},
    {   'name': 'ADMIN_EXP_RATIO',
        'category': 'financial',
        'description': '管理费用占收入比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, admin_exp, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int '
                        'DESC) AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q1 AS (SELECT d.ts_code, '
                        'd.trade_date, i.revenue, i.admin_exp, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date '
                        'ORDER BY i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int '
                        '<= d.td_int AND i.ad_int <= d.td_int) SELECT ts_code, trade_date, CASE WHEN SUM(revenue) FILTER '
                        '(WHERE q_rank = 1) > 0 THEN SUM(admin_exp) FILTER (WHERE q_rank = 1) / SUM(revenue) FILTER (WHERE '
                        'q_rank = 1) END AS ADMIN_EXP_RATIO FROM q1 GROUP BY ts_code, trade_date\n'
                        '        ',
        'enabled': True},
    {   'name': 'FIN_EXP_RATIO',
        'category': 'financial',
        'description': '财务费用占收入比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, fin_exp, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q1 AS (SELECT d.ts_code, '
                        'd.trade_date, i.revenue, i.fin_exp, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER '
                        'BY i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= '
                        'd.td_int AND i.ad_int <= d.td_int) SELECT ts_code, trade_date, CASE WHEN SUM(revenue) FILTER '
                        '(WHERE q_rank = 1) > 0 THEN SUM(fin_exp) FILTER (WHERE q_rank = 1) / SUM(revenue) FILTER (WHERE '
                        'q_rank = 1) END AS FIN_EXP_RATIO FROM q1 GROUP BY ts_code, trade_date\n'
                        '        ',
        'enabled': True},
    {   'name': 'TOTAL_EXP_RATIO',
        'category': 'financial',
        'description': '三项费用占收入比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, sell_exp, admin_exp, fin_exp, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q1 AS '
                        '(SELECT d.ts_code, d.trade_date, i.revenue, i.sell_exp, i.admin_exp, i.fin_exp, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i '
                        'ON d.ts_code = i.ts_code AND i.ed_int <= d.td_int AND i.ad_int <= d.td_int) SELECT ts_code, '
                        'trade_date, CASE WHEN revenue != 0 AND revenue IS NOT NULL THEN (COALESCE(CAST(sell_exp AS '
                        'DOUBLE),0) + COALESCE(CAST(admin_exp AS DOUBLE),0) + COALESCE(CAST(fin_exp AS DOUBLE),0)) / '
                        'revenue END AS TOTAL_EXP_RATIO FROM q1 WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'NON_RECURRING_RATIO',
        'category': 'financial',
        'description': '非经常性损益占比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, extra_item, netprofit_margin, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY '
                        'ad_int DESC) AS rn FROM fina_indicator), fil AS (SELECT * FROM fi WHERE rn = 1), q1 AS (SELECT '
                        'd.ts_code, d.trade_date, fi.extra_item, fi.netprofit_margin, ROW_NUMBER() OVER (PARTITION BY '
                        'd.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fil fi ON '
                        'd.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int) SELECT ts_code, '
                        'trade_date, CASE WHEN netprofit_margin != 0 AND netprofit_margin IS NOT NULL THEN ABS(extra_item) '
                        '/ ABS(netprofit_margin / 100.0) END AS NON_RECURRING_RATIO FROM q1 WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'DEBT_TO_EQUITY',
        'category': 'financial',
        'description': '资产负债率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(total_liab AS DOUBLE) AS num, CAST(total_hldr_eqy_exc_min_int AS DOUBLE) AS den, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, bal.num, bal.den, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM db d LEFT JOIN bal '
                        'ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= d.td_int WHERE bal.rn = '
                        '1) SELECT ts_code, trade_date, CASE WHEN den != 0 AND den IS NOT NULL THEN num / den END AS '
                        'DEBT_TO_EQUITY FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'LONG_DEBT_TO_EQUITY',
        'category': 'financial',
        'description': '长期负债权益比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, COALESCE(CAST(lt_borr AS DOUBLE), 0) + COALESCE(CAST(bond_payable AS DOUBLE), 0) AS num, '
                        'CAST(total_hldr_eqy_exc_min_int AS DOUBLE) AS den, ROW_NUMBER() OVER (PARTITION BY ts_code, '
                        'end_date ORDER BY ad_int DESC) AS rn FROM fina_balancesheet_vip), b AS (SELECT d.ts_code, '
                        'd.trade_date, bal.num, bal.den, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY '
                        'bal.ed_int DESC) AS q_rank FROM db d LEFT JOIN bal ON d.ts_code = bal.ts_code AND bal.ed_int <= '
                        'd.td_int AND bal.ad_int <= d.td_int WHERE bal.rn = 1) SELECT ts_code, trade_date, CASE WHEN den '
                        '!= 0 AND den IS NOT NULL THEN num / den END AS LONG_DEBT_TO_EQUITY FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'SHORT_DEBT_RATIO',
        'category': 'financial',
        'description': '短期债务占比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, COALESCE(CAST(st_borr AS DOUBLE), 0) + COALESCE(CAST(notes_payable AS DOUBLE), 0) AS num, '
                        'CAST(total_liab AS DOUBLE) AS den, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY '
                        'ad_int DESC) AS rn FROM fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, bal.num, '
                        'bal.den, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN bal ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND '
                        'bal.ad_int <= d.td_int WHERE bal.rn = 1) SELECT ts_code, trade_date, CASE WHEN den != 0 AND den '
                        'IS NOT NULL THEN num / den END AS SHORT_DEBT_RATIO FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'CURRENT_RATIO',
        'category': 'financial',
        'description': '流动比率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(total_cur_assets AS DOUBLE) AS num, CAST(total_cur_liab AS DOUBLE) AS den, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, bal.num, bal.den, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM db d LEFT JOIN bal '
                        'ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= d.td_int WHERE bal.rn = '
                        '1) SELECT ts_code, trade_date, CASE WHEN den != 0 AND den IS NOT NULL THEN num / den END AS '
                        'CURRENT_RATIO FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'QUICK_RATIO',
        'category': 'financial',
        'description': '速动比率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, COALESCE(CAST(total_cur_assets AS DOUBLE), 0) - COALESCE(CAST(inventories AS DOUBLE), 0) '
                        'AS num, CAST(total_cur_liab AS DOUBLE) AS den, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, '
                        'bal.num, bal.den, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int '
                        'DESC) AS q_rank FROM db d LEFT JOIN bal ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND '
                        'bal.ad_int <= d.td_int WHERE bal.rn = 1) SELECT ts_code, trade_date, CASE WHEN den != 0 AND den '
                        'IS NOT NULL THEN num / den END AS QUICK_RATIO FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'CASH_RATIO',
        'category': 'financial',
        'description': '现金比率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, COALESCE(CAST(money_cap AS DOUBLE), 0) AS num, CAST(total_cur_liab AS DOUBLE) AS den, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, bal.num, bal.den, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM db d LEFT JOIN bal '
                        'ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= d.td_int WHERE bal.rn = '
                        '1) SELECT ts_code, trade_date, CASE WHEN den != 0 AND den IS NOT NULL THEN num / den END AS '
                        'CASH_RATIO FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'LEVERAGE_CHANGE',
        'category': 'financial',
        'description': '杠杆率变化',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(total_liab AS DOUBLE) AS num, CAST(total_hldr_eqy_exc_min_int AS DOUBLE) AS den, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_balancesheet_vip), rat AS (SELECT d.ts_code, d.trade_date, CASE WHEN bal.den != 0 AND '
                        'bal.den IS NOT NULL THEN bal.num / bal.den END AS dte, ROW_NUMBER() OVER (PARTITION BY d.ts_code, '
                        'd.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM db d LEFT JOIN bal ON d.ts_code = '
                        'bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= d.td_int WHERE bal.rn = 1 AND dte IS NOT '
                        'NULL) SELECT ts_code, trade_date, dte - LAG(dte, 1) OVER (PARTITION BY ts_code ORDER BY '
                        'trade_date) AS LEVERAGE_CHANGE FROM rat WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'TANGIBLE_ASSET_RATIO',
        'category': 'financial',
        'description': '有形资产比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, COALESCE(CAST(total_assets AS DOUBLE), 0) - COALESCE(CAST(goodwill AS DOUBLE), 0) - '
                        'COALESCE(CAST(intan_assets AS DOUBLE), 0) AS tangible, CAST(total_assets AS DOUBLE) AS ta, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, bal.tangible, bal.ta, ROW_NUMBER() '
                        'OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM db d LEFT '
                        'JOIN bal ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= d.td_int WHERE '
                        'bal.rn = 1) SELECT ts_code, trade_date, CASE WHEN ta != 0 AND ta IS NOT NULL THEN tangible / ta '
                        'END AS TANGIBLE_ASSET_RATIO FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'INTANGIBLE_RATIO',
        'category': 'financial',
        'description': '无形资产比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(total_assets AS DOUBLE) AS total_assets, CAST(intan_assets AS DOUBLE) AS '
                        'intan_assets, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_balancesheet_vip), joined AS (SELECT d.ts_code, d.trade_date, bal.total_assets, '
                        'bal.intan_assets, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int '
                        'DESC) AS q_rank FROM db d LEFT JOIN bal ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND '
                        'bal.ad_int <= d.td_int WHERE bal.rn = 1) SELECT ts_code, trade_date, CASE WHEN total_assets != 0 '
                        'AND total_assets IS NOT NULL THEN COALESCE(intan_assets, 0) / total_assets END AS '
                        'INTANGIBLE_RATIO FROM joined WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'FIXED_ASSET_RATIO',
        'category': 'financial',
        'description': '固定资产比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, COALESCE(CAST(fix_assets AS DOUBLE), 0) AS fa, CAST(total_assets AS DOUBLE) AS ta, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, bal.fa, bal.ta, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM db d LEFT JOIN bal '
                        'ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= d.td_int WHERE bal.rn = '
                        '1) SELECT ts_code, trade_date, CASE WHEN ta != 0 AND ta IS NOT NULL THEN fa / ta END AS '
                        'FIXED_ASSET_RATIO FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'INVENTORY_RATIO',
        'category': 'financial',
        'description': '存货比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, COALESCE(CAST(inventories AS DOUBLE), 0) AS inv, CAST(total_assets AS DOUBLE) AS ta, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, bal.inv, bal.ta, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM db d LEFT JOIN bal '
                        'ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= d.td_int WHERE bal.rn = '
                        '1) SELECT ts_code, trade_date, CASE WHEN ta != 0 AND ta IS NOT NULL THEN inv / ta END AS '
                        'INVENTORY_RATIO FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'RECEIVABLE_RATIO',
        'category': 'financial',
        'description': '应收账款比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, COALESCE(CAST(accounts_receiv AS DOUBLE), 0) AS ar, CAST(total_assets AS DOUBLE) AS ta, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, bal.ar, bal.ta, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM db d LEFT JOIN bal '
                        'ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= d.td_int WHERE bal.rn = '
                        '1) SELECT ts_code, trade_date, CASE WHEN ta != 0 AND ta IS NOT NULL THEN ar / ta END AS '
                        'RECEIVABLE_RATIO FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'ROE_DT',
        'category': 'financial',
        'description': 'ROE_DT（扣非ROE）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, roe_dt, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.roe_dt, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, roe_dt AS ROE_DT FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'ROIC',
        'category': 'financial',
        'description': 'ROIC（投入资本回报率）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(roic AS DOUBLE) AS roic, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY '
                        'ad_int DESC) AS rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.roic, '
                        'ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM '
                        'db d LEFT JOIN fi ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int '
                        'WHERE fi.rn = 1) SELECT ts_code, trade_date, roic AS ROIC FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'ROE_YEARLY',
        'category': 'financial',
        'description': '年度ROE',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, roe_yearly, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.roe_yearly, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, roe_yearly AS ROE_YEARLY FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'GROSSPROFIT_MARGIN',
        'category': 'financial',
        'description': '毛利率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(grossprofit_margin AS DOUBLE) AS grossprofit_margin, ROW_NUMBER() OVER (PARTITION BY '
                        'ts_code, end_date ORDER BY ad_int DESC) AS rn FROM fina_indicator), b AS (SELECT d.ts_code, '
                        'd.trade_date, fi.grossprofit_margin, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date '
                        'ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi ON d.ts_code = fi.ts_code AND fi.ed_int '
                        '<= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) SELECT ts_code, trade_date, '
                        'grossprofit_margin AS GROSSPROFIT_MARGIN FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'NETPROFIT_MARGIN',
        'category': 'financial',
        'description': '净利率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, netprofit_margin, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.netprofit_margin, '
                        'ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM '
                        'db d LEFT JOIN fi ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int '
                        'WHERE fi.rn = 1) SELECT ts_code, trade_date, netprofit_margin AS NETPROFIT_MARGIN FROM b WHERE '
                        'q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'PROFIT_TO_GR',
        'category': 'financial',
        'description': '利润占营业收入比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, profit_to_gr, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS '
                        'rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.profit_to_gr, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, profit_to_gr AS PROFIT_TO_GR FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'BPS',
        'category': 'financial',
        'description': '每股净资产',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, bps, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.bps, ROW_NUMBER() OVER (PARTITION BY '
                        'd.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi ON d.ts_code = '
                        'fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) SELECT ts_code, '
                        'trade_date, bps AS BPS FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'OCFPS',
        'category': 'financial',
        'description': '每股经营现金流',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, ocfps, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.ocfps, ROW_NUMBER() OVER (PARTITION BY '
                        'd.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi ON d.ts_code = '
                        'fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) SELECT ts_code, '
                        'trade_date, ocfps AS OCFPS FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'CFPS',
        'category': 'financial',
        'description': '每股现金流',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, cfps, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.cfps, ROW_NUMBER() OVER (PARTITION BY '
                        'd.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi ON d.ts_code = '
                        'fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) SELECT ts_code, '
                        'trade_date, cfps AS CFPS FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'FCFF_PS',
        'category': 'financial',
        'description': '每股自由现金流',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(fcff_ps AS DOUBLE) AS fcff_ps, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, '
                        'fi.fcff_ps, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN fi ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int '
                        '<= d.td_int WHERE fi.rn = 1) SELECT ts_code, trade_date, fcff_ps AS FCFF_PS FROM b WHERE q_rank = '
                        '1\n'
                        '        ',
        'enabled': True},
    {   'name': 'DEBT_TO_ASSETS',
        'category': 'financial',
        'description': '资产负债率（财务指标）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, debt_to_assets, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.debt_to_assets, ROW_NUMBER() '
                        'OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN '
                        'fi ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, debt_to_assets AS DEBT_TO_ASSETS FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'ASSETS_TO_EQT',
        'category': 'financial',
        'description': '资产权益比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, assets_to_eqt, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS '
                        'rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.assets_to_eqt, ROW_NUMBER() '
                        'OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN '
                        'fi ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, assets_to_eqt AS ASSETS_TO_EQT FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'LONGDEB_TO_DEBT',
        'category': 'financial',
        'description': '长期债务占债务比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(longdeb_to_debt AS DOUBLE) AS longdeb_to_debt, ROW_NUMBER() OVER (PARTITION BY '
                        'ts_code, end_date ORDER BY ad_int DESC) AS rn FROM fina_indicator), b AS (SELECT d.ts_code, '
                        'd.trade_date, fi.longdeb_to_debt, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER '
                        'BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi ON d.ts_code = fi.ts_code AND fi.ed_int <= '
                        'd.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) SELECT ts_code, trade_date, longdeb_to_debt '
                        'AS LONGDEB_TO_DEBT FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'OCF_TO_DEBT',
        'category': 'financial',
        'description': '经营现金流/债务比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, ocf_to_debt, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS '
                        'rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.ocf_to_debt, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, ocf_to_debt AS OCF_TO_DEBT FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'ASSETS_TURN',
        'category': 'financial',
        'description': '资产周转率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, assets_turn, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS '
                        'rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.assets_turn, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, assets_turn AS ASSETS_TURN FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'AR_TURN',
        'category': 'financial',
        'description': '应收账款周转率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(ar_turn AS DOUBLE) AS ar_turn, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, '
                        'fi.ar_turn, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN fi ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int '
                        '<= d.td_int WHERE fi.rn = 1) SELECT ts_code, trade_date, ar_turn AS AR_TURN FROM b WHERE q_rank = '
                        '1\n'
                        '        ',
        'enabled': True},
    {   'name': 'TR_YOY',
        'category': 'financial',
        'description': '营收同比增速（财务表）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, tr_yoy, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.tr_yoy, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, tr_yoy AS TR_YOY FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'DT_NETPROFIT_YOY',
        'category': 'financial',
        'description': '扣非净利润增速',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, dt_netprofit_yoy, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.dt_netprofit_yoy, '
                        'ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM '
                        'db d LEFT JOIN fi ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int '
                        'WHERE fi.rn = 1) SELECT ts_code, trade_date, dt_netprofit_yoy AS DT_NETPROFIT_YOY FROM b WHERE '
                        'q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'BPS_YOY',
        'category': 'financial',
        'description': '每股净资产增速',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, bps_yoy, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.bps_yoy, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, bps_yoy AS BPS_YOY FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'ASSETS_YOY',
        'category': 'financial',
        'description': '总资产增速',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, assets_yoy, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.assets_yoy, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, assets_yoy AS ASSETS_YOY FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'EQT_YOY',
        'category': 'financial',
        'description': '所有者权益增速',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, eqt_yoy, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.eqt_yoy, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, eqt_yoy AS EQT_YOY FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'Q_GR_YOY',
        'category': 'financial',
        'description': '季度收入增速（fina_indicator）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, q_sales_yoy, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS '
                        'rn FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.q_sales_yoy, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, q_sales_yoy AS Q_GR_YOY FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'Q_NETPROFIT_YOY',
        'category': 'financial',
        'description': '季度扣非ROE增速',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, q_dt_roe, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.q_dt_roe, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, q_dt_roe AS Q_NETPROFIT_YOY FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'Q_PROFIT_QOQ',
        'category': 'financial',
        'description': '季度盈利环比变化',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, q_op_qoq, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM fina_indicator), b AS (SELECT d.ts_code, d.trade_date, fi.q_op_qoq, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fi.ed_int DESC) AS q_rank FROM db d LEFT JOIN fi '
                        'ON d.ts_code = fi.ts_code AND fi.ed_int <= d.td_int AND fi.ad_int <= d.td_int WHERE fi.rn = 1) '
                        'SELECT ts_code, trade_date, q_op_qoq AS Q_PROFIT_QOQ FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'AUDIT_OPINION_SCORE',
        'category': 'financial',
        'description': '审计意见评分',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fa AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, audit_result, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS '
                        'rn FROM fina_audit), b AS (SELECT d.ts_code, d.trade_date, fa.audit_result, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fa.ed_int DESC) AS q_rank FROM db d LEFT JOIN fa '
                        'ON d.ts_code = fa.ts_code AND fa.ed_int <= d.td_int AND fa.ad_int <= d.td_int) SELECT ts_code, '
                        "trade_date, CASE audit_result WHEN '标准无保留意见' THEN 1 WHEN '保留意见' THEN 0 WHEN '无法表示意见' THEN -1 WHEN "
                        "'否定意见' THEN -2 ELSE 0 END AS AUDIT_OPINION_SCORE FROM b WHERE q_rank = 1\n"
                        '        ',
        'enabled': True},
    {   'name': 'BIG4_AUDITOR',
        'category': 'financial',
        'description': '是否四大审计',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fa AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, audit_agency, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS '
                        'rn FROM fina_audit), b AS (SELECT d.ts_code, d.trade_date, fa.audit_agency, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY fa.ed_int DESC) AS q_rank FROM db d LEFT JOIN fa '
                        'ON d.ts_code = fa.ts_code AND fa.ed_int <= d.td_int AND fa.ad_int <= d.td_int) SELECT ts_code, '
                        "trade_date, CASE WHEN audit_agency LIKE '%普华%' OR audit_agency LIKE '%德勤%' OR audit_agency LIKE "
                        "'%安永%' OR audit_agency LIKE '%毕马威%' THEN 1 ELSE 0 END AS BIG4_AUDITOR FROM b WHERE q_rank = 1\n"
                        '        ',
        'enabled': True},
    {   'name': 'TOP10_HOLD_RATIO_SUM',
        'category': 'financial',
        'description': '前十大股东持股比例合计',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), th AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, hold_ratio, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM top10_holders), th_dedup AS (SELECT ts_code, end_date, ad_int, hold_ratio FROM th WHERE rn = '
                        '1), agg AS (SELECT th_dedup.ts_code, th_dedup.end_date, th_dedup.ad_int, SUM(th_dedup.hold_ratio) '
                        'AS sum_ratio, ROW_NUMBER() OVER (PARTITION BY th_dedup.ts_code, th_dedup.end_date ORDER BY '
                        'th_dedup.ad_int DESC) AS rn2 FROM th_dedup GROUP BY th_dedup.ts_code, th_dedup.end_date, '
                        'th_dedup.ad_int), agg_latest AS (SELECT ts_code, end_date, ad_int AS latest_ad_int, sum_ratio '
                        'FROM agg WHERE rn2 = 1) SELECT d.ts_code, d.trade_date, agg_latest.sum_ratio AS '
                        'TOP10_HOLD_RATIO_SUM FROM db d LEFT JOIN agg_latest ON d.ts_code = agg_latest.ts_code AND '
                        'agg_latest.end_date <= d.trade_date AND agg_latest.latest_ad_int <= d.td_int\n'
                        '        ',
        'enabled': True},
    {   'name': 'TOP10_FLOAT_RATIO_SUM',
        'category': 'financial',
        'description': '前十大流通股东持股比例合计',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), tf AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, hold_float_ratio, holder_type, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY '
                        'ad_int DESC) AS rn FROM top10_floatholders), tf_dedup AS (SELECT ts_code, end_date, ad_int, '
                        'hold_float_ratio, holder_type FROM tf WHERE rn = 1), agg_float AS (SELECT ts_code, end_date, '
                        'ad_int, SUM(hold_float_ratio) AS sum_float_ratio, ROW_NUMBER() OVER (PARTITION BY ts_code, '
                        'end_date ORDER BY ad_int DESC) AS rn2 FROM tf_dedup GROUP BY ts_code, end_date, ad_int), '
                        'agg_latest AS (SELECT ts_code, end_date, ad_int AS latest_ad_int, sum_float_ratio FROM agg_float '
                        'WHERE rn2 = 1), ranked AS (SELECT d.ts_code, d.trade_date, a.sum_float_ratio, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY a.end_date DESC) AS rn FROM db d LEFT JOIN '
                        'agg_latest a ON d.ts_code = a.ts_code AND a.end_date <= d.trade_date AND a.latest_ad_int <= '
                        'd.td_int) SELECT ts_code, trade_date, sum_float_ratio AS TOP10_FLOAT_RATIO_SUM FROM ranked WHERE '
                        'rn = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'LARGEST_HOLDER_RATIO',
        'category': 'financial',
        'description': '第一大股东持股比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), th AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, hold_ratio, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY hold_ratio DESC) '
                        'AS rank_hold, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'top10_holders), thl AS (SELECT * FROM th WHERE rn = 1 AND rank_hold = 1) SELECT d.ts_code, '
                        'd.trade_date, thl.hold_ratio AS LARGEST_HOLDER_RATIO FROM db d LEFT JOIN thl ON d.ts_code = '
                        'thl.ts_code AND thl.ed_int <= d.td_int AND thl.ad_int <= d.td_int\n'
                        '        ',
        'enabled': True},
    {   'name': 'HOLDER_NUM_MA',
        'category': 'financial',
        'description': '股东人数4期均线变化率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ranked AS (SELECT "
                        'd.ts_code, d.trade_date, t.holder_num FROM db d LEFT JOIN LATERAL (SELECT holder_num FROM '
                        'stk_holdernumber_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND ann_date_int <= '
                        'd.td_int ORDER BY end_date_int DESC, ann_date_int DESC LIMIT 1) t ON true), ma AS (SELECT '
                        'ts_code, trade_date, holder_num, AVG(holder_num) OVER (PARTITION BY ts_code ORDER BY trade_date '
                        'ROWS BETWEEN 3 PRECEDING AND CURRENT ROW) AS ma4 FROM ranked WHERE holder_num IS NOT NULL) SELECT '
                        'ts_code, trade_date, CASE WHEN ma4 != 0 AND ma4 IS NOT NULL THEN (holder_num - ma4) / ma4 END AS '
                        'HOLDER_NUM_MA FROM ma\n'
                        '        ',
        'enabled': True},
    {   'name': 'BUYBACK_ACTIVE',
        'category': 'financial',
        'description': '近90天是否有回购',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), rp AS (SELECT "
                        'ts_code, ann_date, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ann_date DESC) AS '
                        "rn FROM stk_repurchase WHERE ann_date >= '{start_dt_2y}'), recent AS (SELECT d.ts_code, "
                        'd.trade_date, MAX(CASE WHEN rp.ann_date >= CAST(CAST(d.trade_date AS INTEGER) - 9000 AS VARCHAR) '
                        'THEN 1 ELSE 0 END) AS buyback_active FROM db d LEFT JOIN rp ON d.ts_code = rp.ts_code AND rp.rn = '
                        '1 AND rp.ann_date <= d.trade_date AND rp.ann_date >= CAST(CAST(d.trade_date AS INTEGER) - 9000 AS '
                        'VARCHAR) GROUP BY d.ts_code, d.trade_date) SELECT ts_code, trade_date, COALESCE(buyback_active, '
                        '0) AS BUYBACK_ACTIVE FROM recent\n'
                        '        ',
        'enabled': True},
    {   'name': 'BROKER_CONSENSUS',
        'category': 'financial',
        'description': '当月券商推荐次数',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), br AS (SELECT "
                        "ts_code, month, broker, CAST(month || '01' AS INTEGER) AS m_int FROM broker_recommend), recent AS "
                        '(SELECT d.ts_code, d.trade_date, COUNT(*) AS rec_cnt FROM db d LEFT JOIN br ON d.ts_code = '
                        'br.ts_code AND br.m_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, trade_date, '
                        'rec_cnt AS BROKER_CONSENSUS FROM recent WHERE rec_cnt IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'BROKER_DIVERSITY',
        'category': 'financial',
        'description': '当月不同券商数',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), br AS (SELECT "
                        "ts_code, month, broker, CAST(month || '01' AS INTEGER) AS m_int FROM broker_recommend), recent AS "
                        '(SELECT d.ts_code, d.trade_date, COUNT(DISTINCT br.broker) AS broker_cnt FROM db d LEFT JOIN br '
                        'ON d.ts_code = br.ts_code AND br.m_int <= d.td_int AND br.m_int > CAST(d.td_int AS INTEGER) - '
                        '10000 GROUP BY d.ts_code, d.trade_date) SELECT ts_code, trade_date, broker_cnt AS '
                        'BROKER_DIVERSITY FROM recent WHERE broker_cnt IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'OCF_TO_NI',
        'category': 'financial',
        'description': '经营现金流/净利润（修复版：分母改用income表）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.n_cashflow_act FROM db d LEFT JOIN LATERAL (SELECT n_cashflow_act FROM '
                        'fina_cashflow_vip_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND ann_date_int <= '
                        "d.td_int AND f_ann_date_int <= d.td_int ORDER BY LPAD(end_date_int::VARCHAR, 8, '0') || '|' || "
                        "LPAD(ann_date_int::VARCHAR, 8, '0') || '|' || LPAD(f_ann_date_int::VARCHAR, 8, '0') DESC LIMIT 1) "
                        't ON true), inc_j AS (SELECT d.ts_code, d.trade_date, t.net_profit FROM db d LEFT JOIN LATERAL '
                        '(SELECT net_profit FROM income_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND '
                        'ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY LPAD(end_date_int::VARCHAR, 8, '
                        "'0') || '|' || LPAD(ann_date_int::VARCHAR, 8, '0') || '|' || LPAD(f_ann_date_int::VARCHAR, 8, "
                        "'0') DESC LIMIT 1) t ON true) SELECT c.ts_code, c.trade_date, CASE WHEN i.net_profit != 0 AND "
                        'i.net_profit IS NOT NULL THEN c.n_cashflow_act / i.net_profit END AS OCF_TO_NI FROM cf_j c LEFT '
                        'JOIN inc_j i ON c.ts_code = i.ts_code AND c.trade_date = i.trade_date WHERE c.n_cashflow_act IS '
                        'NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'FCF_TO_NI',
        'category': 'financial',
        'description': '自由现金流/净利润（修复版：分母改用income表）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.free_cashflow FROM db d LEFT JOIN LATERAL (SELECT free_cashflow FROM '
                        'fina_cashflow_vip_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND ann_date_int <= '
                        "d.td_int AND f_ann_date_int <= d.td_int ORDER BY LPAD(end_date_int::VARCHAR, 8, '0') || '|' || "
                        "LPAD(ann_date_int::VARCHAR, 8, '0') || '|' || LPAD(f_ann_date_int::VARCHAR, 8, '0') DESC LIMIT 1) "
                        't ON true), inc_j AS (SELECT d.ts_code, d.trade_date, t.net_profit FROM db d LEFT JOIN LATERAL '
                        '(SELECT net_profit FROM income_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND '
                        'ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY LPAD(end_date_int::VARCHAR, 8, '
                        "'0') || '|' || LPAD(ann_date_int::VARCHAR, 8, '0') || '|' || LPAD(f_ann_date_int::VARCHAR, 8, "
                        "'0') DESC LIMIT 1) t ON true) SELECT c.ts_code, c.trade_date, CASE WHEN i.net_profit != 0 AND "
                        'i.net_profit IS NOT NULL THEN c.free_cashflow / i.net_profit END AS FCF_TO_NI FROM cf_j c LEFT '
                        'JOIN inc_j i ON c.ts_code = i.ts_code AND c.trade_date = i.trade_date WHERE c.free_cashflow IS '
                        'NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'FCF_TO_ASSETS',
        'category': 'financial',
        'description': '自由现金流/总资产',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.free_cashflow AS fcf FROM db d LEFT JOIN LATERAL (SELECT free_cashflow '
                        'FROM fina_cashflow_vip_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND '
                        'ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY sort_key_str DESC LIMIT 1) t ON '
                        'true), bal_j AS (SELECT d.ts_code, d.trade_date, t.total_assets FROM db d LEFT JOIN LATERAL '
                        '(SELECT total_assets FROM fina_balancesheet_vip_prep WHERE ts_code = d.ts_code AND end_date_int '
                        '<= d.td_int AND ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY sort_key_str '
                        'DESC LIMIT 1) t ON true) SELECT c.ts_code, c.trade_date, CASE WHEN b.total_assets > 0 AND '
                        'b.total_assets IS NOT NULL THEN c.fcf / b.total_assets END AS FCF_TO_ASSETS FROM cf_j c LEFT JOIN '
                        'bal_j b ON c.ts_code = b.ts_code AND c.trade_date = b.trade_date WHERE c.fcf IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'ASSET_TURNOVER',
        'category': 'financial',
        'description': '资产周转率（TTM营收/平均资产）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q4 AS (SELECT d.ts_code, d.trade_date, '
                        'i.revenue, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY i.ed_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= d.td_int AND i.ad_int <= '
                        'd.td_int) SELECT ts_code, trade_date, SUM(revenue) FILTER (WHERE q_rank BETWEEN 1 AND 4) AS '
                        'ASSET_TURNOVER FROM q4 GROUP BY ts_code, trade_date\n'
                        '        ',
        'enabled': True},
    {   'name': 'INVENTORY_TURNOVER',
        'category': 'financial',
        'description': '存货周转率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(oper_cost AS DOUBLE) AS oper_cost, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM income_vip), q4 AS (SELECT d.ts_code, d.trade_date, '
                        'inc.oper_cost, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY inc.ed_int DESC) '
                        'AS q_rank FROM db d LEFT JOIN inc ON d.ts_code = inc.ts_code AND inc.ed_int <= d.td_int AND '
                        'inc.ad_int <= d.td_int WHERE inc.rn = 1) SELECT ts_code, trade_date, SUM(oper_cost) FILTER (WHERE '
                        'q_rank BETWEEN 1 AND 4) AS INVENTORY_TURNOVER FROM q4 GROUP BY ts_code, trade_date\n'
                        '        ',
        'enabled': True},
    {   'name': 'NET_BORROWING_RATIO',
        'category': 'financial',
        'description': '净借款比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.c_recp_borrow - t.c_prepay_amt_borr AS net_borrow FROM db d LEFT JOIN '
                        'LATERAL (SELECT c_recp_borrow, c_prepay_amt_borr FROM fina_cashflow_vip_prep WHERE ts_code = '
                        'd.ts_code AND end_date_int <= d.td_int AND ann_date_int <= d.td_int AND f_ann_date_int <= '
                        'd.td_int ORDER BY sort_key_str DESC LIMIT 1) t ON true), bal_j AS (SELECT d.ts_code, '
                        'd.trade_date, t.total_assets FROM db d LEFT JOIN LATERAL (SELECT total_assets FROM '
                        'fina_balancesheet_vip_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int AND '
                        'ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY sort_key_str DESC LIMIT 1) t ON '
                        'true) SELECT c.ts_code, c.trade_date, CASE WHEN b.total_assets > 0 AND b.total_assets IS NOT NULL '
                        'THEN c.net_borrow / b.total_assets END AS NET_BORROWING_RATIO FROM cf_j c LEFT JOIN bal_j b ON '
                        'c.ts_code = b.ts_code AND c.trade_date = b.trade_date WHERE c.net_borrow IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'EQUITY_FINANCING_RATIO',
        'category': 'financial',
        'description': '股权融资比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.c_recp_cap_contrib AS equity_in FROM db d LEFT JOIN LATERAL (SELECT '
                        'c_recp_cap_contrib FROM fina_cashflow_vip_prep WHERE ts_code = d.ts_code AND end_date_int <= '
                        'd.td_int AND ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY sort_key_str DESC '
                        'LIMIT 1) t ON true), bal_j AS (SELECT d.ts_code, d.trade_date, t.total_assets FROM db d LEFT JOIN '
                        'LATERAL (SELECT total_assets FROM fina_balancesheet_vip_prep WHERE ts_code = d.ts_code AND '
                        'end_date_int <= d.td_int AND ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY '
                        'sort_key_str DESC LIMIT 1) t ON true) SELECT c.ts_code, c.trade_date, CASE WHEN b.total_assets > '
                        '0 AND b.total_assets IS NOT NULL THEN c.equity_in / b.total_assets END AS EQUITY_FINANCING_RATIO '
                        'FROM cf_j c LEFT JOIN bal_j b ON c.ts_code = b.ts_code AND c.trade_date = b.trade_date WHERE '
                        'c.equity_in IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'ACCRUALS_CHANGE',
        'category': 'financial',
        'description': '应计项目变化',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.n_cashflow_act AS ocf, t.net_profit AS ni FROM db d LEFT JOIN LATERAL '
                        '(SELECT n_cashflow_act, net_profit FROM fina_cashflow_vip_prep WHERE ts_code = d.ts_code AND '
                        'end_date_int <= d.td_int AND ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY '
                        'sort_key_str DESC LIMIT 1) t ON true), bal_j AS (SELECT d.ts_code, d.trade_date, t.total_assets '
                        'FROM db d LEFT JOIN LATERAL (SELECT total_assets FROM fina_balancesheet_vip_prep WHERE ts_code = '
                        'd.ts_code AND end_date_int <= d.td_int AND ann_date_int <= d.td_int AND f_ann_date_int <= '
                        'd.td_int ORDER BY sort_key_str DESC LIMIT 1) t ON true), accruals AS (SELECT c.ts_code, '
                        'c.trade_date, CASE WHEN b.total_assets > 0 AND b.total_assets IS NOT NULL AND c.ni IS NOT NULL '
                        'THEN (c.ni - c.ocf) / b.total_assets END AS accruals FROM cf_j c LEFT JOIN bal_j b ON c.ts_code = '
                        'b.ts_code AND c.trade_date = b.trade_date) SELECT ts_code, trade_date, accruals - LAG(accruals, '
                        '1) OVER (PARTITION BY ts_code ORDER BY trade_date) AS ACCRUALS_CHANGE FROM accruals WHERE '
                        'accruals IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'INV_TURN',
        'category': 'financial',
        'description': '存货周转率（财务表）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(ar_turn AS DOUBLE) AS ar_turn, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM fina_indicator), fil AS (SELECT * FROM fi WHERE rn = 1), q1 AS '
                        '(SELECT d.ts_code, d.trade_date, fil.ar_turn, ROW_NUMBER() OVER (PARTITION BY d.ts_code, '
                        'd.trade_date ORDER BY fil.ed_int DESC) AS q_rank FROM db d LEFT JOIN fil ON d.ts_code = '
                        'fil.ts_code AND fil.ed_int <= d.td_int AND fil.ad_int <= d.td_int) SELECT ts_code, trade_date, '
                        'ar_turn AS INV_TURN FROM q1 WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'INSIDER_BUY_COUNT',
        'category': 'financial',
        'description': '近60天增持次数',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), trade_dedup AS "
                        '(SELECT ts_code, ann_date, in_de, CAST(ann_date AS INTEGER) AS ad_int, ROW_NUMBER() OVER '
                        '(PARTITION BY ts_code, ann_date ORDER BY ann_date DESC) AS rn FROM stk_holdertrade), recent AS '
                        "(SELECT d.ts_code, d.trade_date, COUNT(*) FILTER (WHERE p.in_de = 'IN' AND p.ad_int > d.td_int - "
                        '2500 AND p.ad_int <= d.td_int) AS buy_cnt FROM db d LEFT JOIN trade_dedup p ON d.ts_code = '
                        'p.ts_code AND p.ad_int > d.td_int - 2500 AND p.ad_int <= d.td_int GROUP BY d.ts_code, '
                        'd.trade_date) SELECT ts_code, trade_date, COALESCE(buy_cnt, 0) AS INSIDER_BUY_COUNT FROM recent\n'
                        '        ',
        'enabled': True},
    {   'name': 'INSIDER_TRADE_CONCENTRATION',
        'category': 'financial',
        'description': '近60天增持股东集中度（不同股东数）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), trade_dedup AS "
                        '(SELECT ts_code, ann_date, holder_name, in_de, CAST(ann_date AS INTEGER) AS ad_int, ROW_NUMBER() '
                        'OVER (PARTITION BY ts_code, ann_date ORDER BY ann_date DESC) AS rn FROM stk_holdertrade), recent '
                        'AS (SELECT d.ts_code, d.trade_date, COUNT(DISTINCT p.holder_name) AS holder_dist FROM db d LEFT '
                        'JOIN trade_dedup p ON d.ts_code = p.ts_code AND p.ad_int > d.td_int - 2500 AND p.ad_int <= '
                        'd.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, trade_date, COALESCE(holder_dist, 0) '
                        'AS INSIDER_TRADE_CONCENTRATION FROM recent\n'
                        '        ',
        'enabled': True},
    {   'name': 'RECEIVABLE_TURNOVER',
        'category': 'financial',
        'description': '应收账款周转率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(accounts_receiv AS DOUBLE) AS ar, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, '
                        'bal.ar, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN bal ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND '
                        'bal.ad_int <= d.td_int WHERE bal.rn = 1) SELECT ts_code, trade_date, ar AS RECEIVABLE_TURNOVER '
                        'FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'FIXED_ASSET_TURNOVER',
        'category': 'financial',
        'description': '固定资产周转率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(fix_assets AS DOUBLE) AS fa, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER '
                        'BY ad_int DESC) AS rn FROM fina_balancesheet_vip), b AS (SELECT d.ts_code, d.trade_date, bal.fa, '
                        'ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM '
                        'db d LEFT JOIN bal ON d.ts_code = bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= '
                        'd.td_int WHERE bal.rn = 1) SELECT ts_code, trade_date, fa AS FIXED_ASSET_TURNOVER FROM b WHERE '
                        'q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'FLOAT_CONCENTRATION_CHANGE',
        'category': 'financial',
        'description': '流通股东集中度变化',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), tf AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, hold_float_ratio, holder_type, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY '
                        'ad_int DESC) AS rn FROM top10_floatholders), tf_dedup AS (SELECT ts_code, end_date, ad_int, '
                        'hold_float_ratio, holder_type FROM tf WHERE rn = 1), agg_float AS (SELECT ts_code, end_date, '
                        'ad_int, SUM(hold_float_ratio) AS sum_float_ratio, ROW_NUMBER() OVER (PARTITION BY ts_code, '
                        'end_date ORDER BY ad_int DESC) AS rn2 FROM tf_dedup GROUP BY ts_code, end_date, ad_int), '
                        'agg_latest AS (SELECT ts_code, end_date, ad_int AS latest_ad_int, sum_float_ratio FROM agg_float '
                        'WHERE rn2 = 1), ranked AS (SELECT d.ts_code, d.trade_date, a.sum_float_ratio, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY a.end_date DESC) AS rn FROM db d LEFT JOIN '
                        'agg_latest a ON d.ts_code = a.ts_code AND a.end_date <= d.trade_date AND a.latest_ad_int <= '
                        'd.td_int), with_float AS (SELECT ts_code, trade_date, sum_float_ratio, LAG(sum_float_ratio, 1) '
                        'OVER (PARTITION BY ts_code ORDER BY trade_date) AS prev_float FROM ranked WHERE rn = 1) SELECT '
                        'ts_code, trade_date, sum_float_ratio - prev_float AS FLOAT_CONCENTRATION_CHANGE FROM with_float '
                        'WHERE sum_float_ratio IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'EXPRESS_IS_AUDIT',
        'category': 'financial',
        'description': '快报是否审计',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ex AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, perf_summary, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ann_date DESC) '
                        'AS rn FROM express), b AS (SELECT d.ts_code, d.trade_date, ex.perf_summary, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY ex.ed_int DESC) AS q_rank FROM db d LEFT JOIN ex '
                        'ON d.ts_code = ex.ts_code AND ex.ed_int <= d.td_int AND ex.ann_date <= d.trade_date) SELECT '
                        'ts_code, trade_date, CASE WHEN perf_summary IS NOT NULL THEN 1 ELSE 0 END AS EXPRESS_IS_AUDIT '
                        'FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'HOLDER_NUM_YOY',
        'category': 'financial',
        'description': '股东人数同比变化',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), hn AS (SELECT "
                        'ts_code, end_date_int, ann_date_int, holder_num FROM stk_holdernumber_prep), with_latest AS '
                        '(SELECT d.ts_code, d.trade_date, l.holder_num FROM db d LEFT JOIN LATERAL (SELECT hn.holder_num '
                        'FROM hn WHERE hn.ts_code = d.ts_code AND hn.end_date_int <= d.td_int AND hn.ann_date_int <= '
                        'd.td_int ORDER BY hn.ann_date_int DESC LIMIT 1) l ON TRUE), with_lag AS (SELECT ts_code, '
                        'trade_date, holder_num, LAG(holder_num, 60) OVER (PARTITION BY ts_code ORDER BY trade_date) AS '
                        'prev_hn FROM with_latest WHERE holder_num IS NOT NULL) SELECT ts_code, trade_date, CASE WHEN '
                        'prev_hn > 0 AND prev_hn IS NOT NULL THEN (holder_num - prev_hn) / prev_hn END AS HOLDER_NUM_YOY '
                        'FROM with_lag WHERE holder_num IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'EBITDA_TTM',
        'category': 'financial',
        'description': 'EBITDA TTM（滚动4季）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ttm AS (SELECT "
                        'd.ts_code, d.trade_date, SUM(t.ebitda) AS sum_val FROM db d LEFT JOIN income_ttm_prep t ON '
                        'd.ts_code = t.ts_code AND t.end_date_int <= d.td_int AND t.ann_date_int <= d.td_int AND '
                        't.f_ann_date_int <= d.td_int GROUP BY d.ts_code, d.trade_date) SELECT ts_code, trade_date, '
                        'sum_val AS EBITDA_TTM FROM ttm WHERE sum_val IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'REVENUE_YOY_ACCEL',
        'category': 'financial',
        'description': '营收增长加速度（YoY差分）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn '
                        'FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q4 AS (SELECT d.ts_code, d.trade_date, '
                        'i.revenue, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY i.ed_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= d.td_int AND i.ad_int <= '
                        'd.td_int), ttm AS (SELECT ts_code, trade_date, SUM(revenue) FILTER (WHERE q_rank BETWEEN 1 AND 4) '
                        'AS rev_ttm FROM q4 GROUP BY ts_code, trade_date), yoy AS (SELECT ts_code, trade_date, rev_ttm, '
                        'LAG(rev_ttm, 1) OVER (PARTITION BY ts_code ORDER BY trade_date) AS rev_prev_q, LAG(rev_ttm, 4) '
                        'OVER (PARTITION BY ts_code ORDER BY trade_date) AS rev_lag_y FROM ttm), calc AS (SELECT ts_code, '
                        'trade_date, CASE WHEN rev_lag_y != 0 AND rev_lag_y IS NOT NULL THEN (rev_ttm - rev_lag_y) / '
                        'ABS(rev_lag_y) END AS yoy, CASE WHEN rev_prev_q != 0 AND rev_prev_q IS NOT NULL THEN '
                        '(LAG(rev_ttm, 1) OVER (PARTITION BY ts_code ORDER BY trade_date) - LAG(rev_ttm, 5) OVER '
                        '(PARTITION BY ts_code ORDER BY trade_date)) / ABS(LAG(rev_ttm, 5) OVER (PARTITION BY ts_code '
                        'ORDER BY trade_date)) END AS yoy_prev FROM yoy) SELECT ts_code, trade_date, yoy - yoy_prev AS '
                        'REVENUE_YOY_ACCEL FROM calc WHERE yoy IS NOT NULL AND yoy_prev IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'EARNINGS_YOY_ACCEL',
        'category': 'financial',
        'description': '盈利增长加速度（YoY差分）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, n_income_attr_p, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q4 AS (SELECT d.ts_code, '
                        'd.trade_date, i.n_income_attr_p, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY '
                        'i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i ON d.ts_code = i.ts_code AND i.ed_int <= '
                        'd.td_int AND i.ad_int <= d.td_int), ttm AS (SELECT ts_code, trade_date, SUM(n_income_attr_p) '
                        'FILTER (WHERE q_rank BETWEEN 1 AND 4) AS ni_ttm FROM q4 GROUP BY ts_code, trade_date), yoy AS '
                        '(SELECT ts_code, trade_date, ni_ttm, LAG(ni_ttm, 4) OVER (PARTITION BY ts_code ORDER BY '
                        'trade_date) AS ni_lag_y FROM ttm), calc AS (SELECT ts_code, trade_date, ni_ttm, yoy, LAG(yoy, 1) '
                        'OVER (PARTITION BY ts_code ORDER BY trade_date) AS yoy_prev FROM (SELECT ts_code, trade_date, '
                        'ni_ttm, CASE WHEN ni_lag_y != 0 AND ni_lag_y IS NOT NULL THEN (ni_ttm - ni_lag_y) / ABS(ni_lag_y) '
                        'END AS yoy FROM yoy) sub) SELECT ts_code, trade_date, yoy - yoy_prev AS EARNINGS_YOY_ACCEL FROM '
                        'calc WHERE yoy IS NOT NULL AND yoy_prev IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'RD_EXP_RATIO',
        'category': 'financial',
        'description': '研发费用率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, CAST(rd_exp AS DOUBLE) AS rd_exp_d, ROW_NUMBER() OVER (PARTITION BY ts_code, '
                        'end_date ORDER BY ad_int DESC) AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q1 '
                        'AS (SELECT d.ts_code, d.trade_date, i.revenue, i.rd_exp_d, ROW_NUMBER() OVER (PARTITION BY '
                        'd.ts_code, d.trade_date ORDER BY i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i ON d.ts_code = '
                        'i.ts_code AND i.ed_int <= d.td_int AND i.ad_int <= d.td_int) SELECT ts_code, trade_date, CASE '
                        'WHEN revenue != 0 AND revenue IS NOT NULL THEN rd_exp_d / revenue END AS RD_EXP_RATIO FROM q1 '
                        'WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'EXP_RATIO_CHANGE',
        'category': 'financial',
        'description': '费用率变化（季度）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), inc AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, revenue, sell_exp, admin_exp, fin_exp, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM income_vip), il AS (SELECT * FROM inc WHERE rn = 1), q1 AS '
                        '(SELECT d.ts_code, d.trade_date, i.revenue, i.sell_exp, i.admin_exp, i.fin_exp, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY i.ed_int DESC) AS q_rank FROM db d LEFT JOIN il i '
                        'ON d.ts_code = i.ts_code AND i.ed_int <= d.td_int AND i.ad_int <= d.td_int), ratio AS (SELECT '
                        'ts_code, trade_date, CASE WHEN revenue != 0 AND revenue IS NOT NULL THEN (COALESCE(sell_exp,0) + '
                        'COALESCE(admin_exp,0) + COALESCE(fin_exp,0)) / revenue END AS total_exp_ratio FROM q1 WHERE '
                        'q_rank = 1) SELECT ts_code, trade_date, total_exp_ratio - LAG(total_exp_ratio, 4) OVER (PARTITION '
                        'BY ts_code ORDER BY trade_date) AS EXP_RATIO_CHANGE FROM ratio WHERE total_exp_ratio IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'ACCRUALS_BS',
        'category': 'financial',
        'description': '应计项目（资产负债法）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal_dedup AS "
                        'MATERIALIZED (SELECT DISTINCT ON (ts_code, end_date) ts_code, end_date AS report_date, '
                        'CAST(end_date AS INTEGER) AS ed_int, CAST(total_cur_assets AS DOUBLE) AS total_cur_assets, '
                        'CAST(money_cap AS DOUBLE) AS money_cap, CAST(total_cur_liab AS DOUBLE) AS total_cur_liab, '
                        'CAST(st_borr AS DOUBLE) AS st_borr, CAST(total_assets AS DOUBLE) AS total_assets, ROW_NUMBER() '
                        'OVER (PARTITION BY ts_code ORDER BY end_date) AS report_seq FROM fina_balancesheet_vip ORDER BY '
                        'ts_code, end_date, ann_date DESC, f_ann_date DESC), curr_with_seq AS (SELECT d.ts_code, '
                        'd.trade_date, d.td_int, b.total_cur_assets, b.money_cap, b.total_cur_liab, b.st_borr, '
                        'b.total_assets, b.ed_int AS curr_ed, b.report_seq AS curr_seq FROM db d ASOF LEFT JOIN bal_dedup '
                        'b ON d.ts_code = b.ts_code AND d.trade_date >= b.report_date), curr_with_prev AS (SELECT ts_code, '
                        'trade_date, td_int, total_cur_assets, money_cap, total_cur_liab, st_borr, total_assets, '
                        'LAG(total_cur_assets, 1) OVER (PARTITION BY ts_code ORDER BY curr_seq) AS prev_ca, LAG(money_cap, '
                        '1) OVER (PARTITION BY ts_code ORDER BY curr_seq) AS prev_mc, LAG(total_cur_liab, 1) OVER '
                        '(PARTITION BY ts_code ORDER BY curr_seq) AS prev_cl, LAG(st_borr, 1) OVER (PARTITION BY ts_code '
                        'ORDER BY curr_seq) AS prev_sb, LAG(total_assets, 1) OVER (PARTITION BY ts_code ORDER BY curr_seq) '
                        'AS prev_ta FROM curr_with_seq) SELECT ts_code, trade_date, CASE WHEN total_assets > 0 AND '
                        'total_assets IS NOT NULL THEN ((COALESCE(total_cur_assets, 0.0) - COALESCE(money_cap, 0.0) - '
                        'COALESCE(prev_ca, 0.0) + COALESCE(prev_mc, 0.0) - COALESCE(total_cur_liab, 0.0) + '
                        'COALESCE(prev_cl, 0.0) + COALESCE(st_borr, 0.0) - COALESCE(prev_sb, 0.0)) / (2.0 * total_assets)) '
                        'END AS ACCRUALS_BS FROM curr_with_prev WHERE prev_ta IS NOT NULL AND trade_date BETWEEN '
                        "'{start_dt}' AND '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'ASSET_GROWTH',
        'category': 'financial',
        'description': '资产增长率（同比）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, total_assets, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS '
                        'rn FROM fina_balancesheet_vip), ball AS (SELECT * FROM bal WHERE rn = 1), q1 AS (SELECT '
                        'd.ts_code, d.trade_date, bal.total_assets, ROW_NUMBER() OVER (PARTITION BY d.ts_code, '
                        'd.trade_date ORDER BY bal.ed_int DESC) AS q_rank FROM db d LEFT JOIN ball bal ON d.ts_code = '
                        'bal.ts_code AND bal.ed_int <= d.td_int AND bal.ad_int <= d.td_int), with_lag AS (SELECT ts_code, '
                        'trade_date, total_assets, LAG(total_assets, 4) OVER (PARTITION BY ts_code ORDER BY trade_date) AS '
                        'lag_ta FROM q1 WHERE q_rank = 1) SELECT ts_code, trade_date, CASE WHEN lag_ta != 0 AND lag_ta IS '
                        'NOT NULL THEN (CAST(total_assets AS DOUBLE) - lag_ta) / lag_ta END AS ASSET_GROWTH FROM with_lag '
                        'WHERE total_assets IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'CAPEX_GROWTH',
        'category': 'financial',
        'description': '资本支出增长率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, fix_assets, cip, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM fina_balancesheet_vip), ball AS (SELECT * FROM bal WHERE rn = 1), q1 AS (SELECT '
                        'd.ts_code, d.trade_date, (COALESCE(CAST(bal.cip AS DOUBLE),0) + COALESCE(CAST(bal.fix_assets AS '
                        'DOUBLE),0)) AS capex, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY bal.ed_int '
                        'DESC) AS q_rank FROM db d LEFT JOIN ball bal ON d.ts_code = bal.ts_code AND bal.ed_int <= '
                        'd.td_int AND bal.ad_int <= d.td_int), with_lag AS (SELECT ts_code, trade_date, capex, LAG(capex, '
                        '4) OVER (PARTITION BY ts_code ORDER BY trade_date) AS lag_capex FROM q1 WHERE q_rank = 1) SELECT '
                        'ts_code, trade_date, CASE WHEN lag_capex != 0 AND lag_capex IS NOT NULL THEN (capex - lag_capex) '
                        '/ lag_capex END AS CAPEX_GROWTH FROM with_lag WHERE capex IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'INVENTORY_GROWTH',
        'category': 'financial',
        'description': '存货增长率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), bal AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(inventories AS DOUBLE) AS inv_d, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM fina_balancesheet_vip), ball AS (SELECT * FROM bal WHERE rn = '
                        '1), q1 AS (SELECT d.ts_code, d.trade_date, ball.inv_d, ROW_NUMBER() OVER (PARTITION BY d.ts_code, '
                        'd.trade_date ORDER BY ball.ed_int DESC) AS q_rank FROM db d LEFT JOIN ball ON d.ts_code = '
                        'ball.ts_code AND ball.ed_int <= d.td_int AND ball.ad_int <= d.td_int), with_lag AS (SELECT '
                        'ts_code, trade_date, inv_d, LAG(inv_d, 4) OVER (PARTITION BY ts_code ORDER BY trade_date) AS '
                        'lag_inv FROM q1 WHERE q_rank = 1) SELECT ts_code, trade_date, CASE WHEN lag_inv != 0 AND lag_inv '
                        'IS NOT NULL THEN (inv_d - lag_inv) / lag_inv END AS INVENTORY_GROWTH FROM with_lag WHERE inv_d IS '
                        'NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'OCF_TO_ASSETS',
        'category': 'financial',
        'description': '经营现金流/总资产',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.n_cashflow_act AS ocf FROM db d LEFT JOIN LATERAL (SELECT '
                        'n_cashflow_act FROM fina_cashflow_vip_prep WHERE ts_code = d.ts_code AND end_date_int <= d.td_int '
                        'AND ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY sort_key_str DESC LIMIT 1) t '
                        'ON true), bal_j AS (SELECT d.ts_code, d.trade_date, t.total_assets FROM db d LEFT JOIN LATERAL '
                        '(SELECT total_assets FROM fina_balancesheet_vip_prep WHERE ts_code = d.ts_code AND end_date_int '
                        '<= d.td_int AND ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY sort_key_str '
                        'DESC LIMIT 1) t ON true) SELECT c.ts_code, c.trade_date, CASE WHEN b.total_assets > 0 AND '
                        'b.total_assets IS NOT NULL THEN c.ocf / b.total_assets END AS OCF_TO_ASSETS FROM cf_j c LEFT JOIN '
                        'bal_j b ON c.ts_code = b.ts_code AND c.trade_date = b.trade_date WHERE c.ocf IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'CAPEX_TO_OCF',
        'category': 'financial',
        'description': '资本支出/经营现金流',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, n_cashflow_act, c_pay_acq_const_fiolta, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM fina_cashflow_vip), cfl AS (SELECT * FROM cf WHERE rn = 1), q1 '
                        'AS (SELECT d.ts_code, d.trade_date, cfl.n_cashflow_act, cfl.c_pay_acq_const_fiolta, ROW_NUMBER() '
                        'OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY cfl.ed_int DESC) AS q_rank FROM db d LEFT '
                        'JOIN cfl ON d.ts_code = cfl.ts_code AND cfl.ed_int <= d.td_int AND cfl.ad_int <= d.td_int) SELECT '
                        'ts_code, trade_date, CASE WHEN n_cashflow_act > 0 AND n_cashflow_act IS NOT NULL THEN '
                        'c_pay_acq_const_fiolta / n_cashflow_act END AS CAPEX_TO_OCF FROM q1 WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'OCF_STABILITY',
        'category': 'financial',
        'description': '经营现金流稳定性（8季CV）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf AS (SELECT "
                        'ts_code, end_date_int, ann_date_int, COALESCE(CAST(n_cashflow_act AS DOUBLE), 0.0) AS ocf FROM '
                        'fina_cashflow_vip_prep), ranked AS (SELECT d.ts_code, d.trade_date, cf.ocf, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY cf.end_date_int DESC, cf.ann_date_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN cf ON d.ts_code = cf.ts_code AND cf.end_date_int <= d.td_int AND '
                        'cf.ann_date_int <= d.td_int), stats AS (SELECT ts_code, trade_date, AVG(ocf) FILTER (WHERE q_rank '
                        'BETWEEN 1 AND 8) AS ocf_mean, STDDEV_SAMP(ocf) FILTER (WHERE q_rank BETWEEN 1 AND 8) AS ocf_std '
                        'FROM ranked GROUP BY ts_code, trade_date) SELECT ts_code, trade_date, CASE WHEN ocf_mean != 0 AND '
                        'ocf_mean IS NOT NULL THEN ocf_std / ABS(ocf_mean) END AS OCF_STABILITY FROM stats\n'
                        '        ',
        'enabled': True},
    {   'name': 'OCF_YOY',
        'category': 'financial',
        'description': '经营现金流同比增速',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, n_cashflow_act, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) '
                        'AS rn FROM fina_cashflow_vip), cfl AS (SELECT * FROM cf WHERE rn = 1), q4 AS (SELECT d.ts_code, '
                        'd.trade_date, cfl.n_cashflow_act, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER '
                        'BY cfl.ed_int DESC) AS q_rank FROM db d LEFT JOIN cfl ON d.ts_code = cfl.ts_code AND cfl.ed_int '
                        '<= d.td_int AND cfl.ad_int <= d.td_int), ttm AS (SELECT ts_code, trade_date, SUM(n_cashflow_act) '
                        'FILTER (WHERE q_rank BETWEEN 1 AND 4) AS ocf_ttm FROM q4 GROUP BY ts_code, trade_date), yoy AS '
                        '(SELECT ts_code, trade_date, ocf_ttm, LAG(ocf_ttm, 4) OVER (PARTITION BY ts_code ORDER BY '
                        'trade_date) AS ocf_lag FROM ttm) SELECT ts_code, trade_date, CASE WHEN ocf_lag != 0 AND ocf_lag '
                        'IS NOT NULL THEN (ocf_ttm - ocf_lag) / ABS(ocf_lag) END AS OCF_YOY FROM yoy\n'
                        '        ',
        'enabled': True},
    {   'name': 'FCF_YOY',
        'category': 'financial',
        'description': '自由现金流同比增速',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf AS (SELECT "
                        'ts_code, end_date_int, ann_date_int, COALESCE(CAST(free_cashflow AS DOUBLE), 0.0) AS fcf FROM '
                        'fina_cashflow_vip_prep), q4 AS (SELECT d.ts_code, d.trade_date, cf.fcf, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY cf.end_date_int DESC, cf.ann_date_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN cf ON d.ts_code = cf.ts_code AND cf.end_date_int <= d.td_int AND '
                        'cf.ann_date_int <= d.td_int), ttm AS (SELECT ts_code, trade_date, SUM(fcf) FILTER (WHERE q_rank '
                        'BETWEEN 1 AND 4) AS fcf_ttm FROM q4 GROUP BY ts_code, trade_date), yoy AS (SELECT ts_code, '
                        'trade_date, fcf_ttm, LAG(fcf_ttm, 4) OVER (PARTITION BY ts_code ORDER BY trade_date) AS fcf_lag '
                        'FROM ttm) SELECT ts_code, trade_date, CASE WHEN fcf_lag != 0 AND fcf_lag IS NOT NULL THEN '
                        '(fcf_ttm - fcf_lag) / ABS(fcf_lag) END AS FCF_YOY FROM yoy\n'
                        '        ',
        'enabled': True},
    {   'name': 'ACCRUALS_CF',
        'category': 'financial',
        'description': '现金流应计项',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), cf_j AS (SELECT "
                        'd.ts_code, d.trade_date, t.n_cashflow_act AS ocf, t.net_profit AS ni FROM db d LEFT JOIN LATERAL '
                        '(SELECT n_cashflow_act, net_profit FROM fina_cashflow_vip_prep WHERE ts_code = d.ts_code AND '
                        'end_date_int <= d.td_int AND ann_date_int <= d.td_int AND f_ann_date_int <= d.td_int ORDER BY '
                        'sort_key_str DESC LIMIT 1) t ON true), bal_j AS (SELECT d.ts_code, d.trade_date, t.total_assets '
                        'FROM db d LEFT JOIN LATERAL (SELECT total_assets FROM fina_balancesheet_vip_prep WHERE ts_code = '
                        'd.ts_code AND end_date_int <= d.td_int AND ann_date_int <= d.td_int AND f_ann_date_int <= '
                        'd.td_int ORDER BY sort_key_str DESC LIMIT 1) t ON true) SELECT c.ts_code, c.trade_date, CASE WHEN '
                        'b.total_assets > 0 AND b.total_assets IS NOT NULL AND c.ni IS NOT NULL THEN (c.ni - c.ocf) / '
                        'b.total_assets END AS ACCRUALS_CF FROM cf_j c LEFT JOIN bal_j b ON c.ts_code = b.ts_code AND '
                        'c.trade_date = b.trade_date WHERE c.ocf IS NOT NULL OR c.ni IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'EPS',
        'category': 'financial',
        'description': '基本每股收益',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, eps, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM '
                        'fina_indicator), fil AS (SELECT * FROM fi WHERE rn = 1), q1 AS (SELECT d.ts_code, d.trade_date, '
                        'fil.eps, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY fil.ed_int DESC) AS '
                        'q_rank FROM db d LEFT JOIN fil ON d.ts_code = fil.ts_code AND fil.ed_int <= d.td_int AND '
                        'fil.ad_int <= d.td_int) SELECT ts_code, trade_date, eps AS EPS FROM q1 WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'CA_TURN',
        'category': 'financial',
        'description': '流动资产周转率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), fi AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, CAST(ca_turn AS DOUBLE) AS ca_turn, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date '
                        'ORDER BY ad_int DESC) AS rn FROM fina_indicator), fil AS (SELECT * FROM fi WHERE rn = 1), q1 AS '
                        '(SELECT d.ts_code, d.trade_date, fil.ca_turn, ROW_NUMBER() OVER (PARTITION BY d.ts_code, '
                        'd.trade_date ORDER BY fil.ed_int DESC) AS q_rank FROM db d LEFT JOIN fil ON d.ts_code = '
                        'fil.ts_code AND fil.ed_int <= d.td_int AND fil.ad_int <= d.td_int) SELECT ts_code, trade_date, '
                        'ca_turn AS CA_TURN FROM q1 WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'AUDIT_FEES_RATIO',
        'category': 'financial',
        'description': '审计费用率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'),\n"
                        '        audit_asof AS (\n'
                        '            SELECT\n'
                        '                d.ts_code,\n'
                        '                d.trade_date,\n'
                        '                a.audit_fees\n'
                        '            FROM db d\n'
                        '            ASOF LEFT JOIN fina_audit a\n'
                        '                ON d.ts_code = a.ts_code\n'
                        '                AND d.trade_date >= a.end_date\n'
                        '        ),\n'
                        '        revenue_asof AS (\n'
                        '            SELECT\n'
                        '                d.ts_code,\n'
                        '                d.trade_date,\n'
                        '                i.revenue\n'
                        '            FROM db d\n'
                        '            ASOF LEFT JOIN income_vip i\n'
                        '                ON d.ts_code = i.ts_code\n'
                        '                AND d.trade_date >= i.end_date\n'
                        '        )\n'
                        '        SELECT\n'
                        '            a.ts_code,\n'
                        '            a.trade_date,\n'
                        '            a.audit_fees,\n'
                        '            r.revenue,\n'
                        '            a.audit_fees / NULLIF(r.revenue, 0) AS audit_fees_ratio\n'
                        '        FROM audit_asof a\n'
                        '        LEFT JOIN revenue_asof r\n'
                        '            ON a.ts_code = r.ts_code\n'
                        '            AND a.trade_date = r.trade_date\n'
                        '        ',
        'enabled': True},
    {   'name': 'DIVIDEND_CHANGE',
        'category': 'financial',
        'description': '分红变化率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), div AS (SELECT "
                        'ts_code, end_date, ann_date, ex_date, cash_div, CAST(end_date AS INTEGER) AS ed_int, '
                        'CAST(ann_date AS INTEGER) AS ad_int, CAST(ex_date AS INTEGER) AS ex_int, ROW_NUMBER() OVER '
                        '(PARTITION BY ts_code, end_date ORDER BY ad_int DESC) AS rn FROM dividend), divl AS (SELECT * '
                        'FROM div WHERE rn = 1), q1 AS (SELECT d.ts_code, d.trade_date, divl.cash_div, divl.ed_int, '
                        'ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY divl.ed_int DESC) AS q_rank FROM '
                        'db d LEFT JOIN divl ON d.ts_code = divl.ts_code AND divl.ed_int <= d.td_int AND divl.ad_int <= '
                        'd.td_int AND divl.ex_int <= d.td_int), with_lag AS (SELECT ts_code, trade_date, cash_div, '
                        'LAG(cash_div, 4) OVER (PARTITION BY ts_code ORDER BY trade_date) AS lag_div FROM q1 WHERE q_rank '
                        '= 1) SELECT ts_code, trade_date, CASE WHEN lag_div != 0 AND lag_div IS NOT NULL THEN (cash_div - '
                        'lag_div) / lag_div END AS DIVIDEND_CHANGE FROM with_lag WHERE cash_div IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'HAS_DIVIDEND',
        'category': 'financial',
        'description': '近12月有分红标志',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), div AS (SELECT "
                        'ts_code, ex_date, CAST(ex_date AS INTEGER) AS ex_int FROM dividend WHERE ex_date IS NOT NULL AND '
                        "ex_date != '' AND CAST(ex_date AS INTEGER) > 0), recent AS (SELECT DISTINCT d.ts_code, "
                        'd.trade_date FROM db d LEFT JOIN div ON d.ts_code = div.ts_code AND div.ex_int > '
                        'CAST(CAST(d.trade_date AS INTEGER) - 12000 AS INTEGER) AND div.ex_int <= d.td_int) SELECT '
                        'ts_code, trade_date, CASE WHEN EXISTS (SELECT 1 FROM div WHERE div.ts_code = recent.ts_code AND '
                        'div.ex_int > CAST(CAST(recent.trade_date AS INTEGER) - 12000 AS INTEGER) AND div.ex_int <= '
                        'CAST(recent.trade_date AS INTEGER)) THEN 1 ELSE 0 END AS HAS_DIVIDEND FROM recent\n'
                        '        ',
        'enabled': True},
    {   'name': 'DIV_EX_DATE_PROXIMITY',
        'category': 'financial',
        'description': '距离除权日天数',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), div AS (SELECT "
                        'ts_code, ex_date, CAST(ex_date AS INTEGER) AS ex_int FROM dividend WHERE ex_date IS NOT NULL AND '
                        "ex_date != '' AND CAST(ex_date AS INTEGER) > 0), next_div AS (SELECT d.ts_code, d.trade_date, "
                        'd.td_int, MIN(div.ex_int) AS next_ex_int FROM db d LEFT JOIN div ON d.ts_code = div.ts_code AND '
                        'div.ex_int >= d.td_int GROUP BY d.ts_code, d.trade_date, d.td_int) SELECT ts_code, trade_date, '
                        'CASE WHEN next_ex_int IS NOT NULL THEN next_ex_int - td_int END AS DIV_EX_DATE_PROXIMITY FROM '
                        'next_div\n'
                        '        ',
        'enabled': True},
    {   'name': 'EXPRESS_SURPRISE',
        'category': 'financial',
        'description': '快报净利润超预期程度',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ex AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, n_income, perf_summary, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY '
                        'ann_date DESC) AS rn FROM express), b AS (SELECT d.ts_code, d.trade_date, ex.n_income, '
                        'ex.perf_summary, ROW_NUMBER() OVER (PARTITION BY d.ts_code, d.trade_date ORDER BY ex.ed_int DESC) '
                        'AS q_rank FROM db d LEFT JOIN ex ON d.ts_code = ex.ts_code AND ex.ed_int <= d.td_int AND '
                        'ex.ann_date <= d.trade_date WHERE ex.rn = 1) SELECT ts_code, trade_date, n_income AS '
                        'EXPRESS_SURPRISE FROM b WHERE q_rank = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'EXPRESS_YOY_EPS',
        'category': 'financial',
        'description': '快报EPS同比增长（计算值）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ex AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, diluted_eps, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ann_date DESC) AS '
                        'rn FROM express), b AS (SELECT d.ts_code, d.trade_date, ex.diluted_eps, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY ex.ed_int DESC) AS q_rank FROM db d LEFT JOIN ex '
                        'ON d.ts_code = ex.ts_code AND ex.ed_int <= d.td_int AND ex.ann_date <= d.trade_date WHERE ex.rn = '
                        '1), with_lag AS (SELECT ts_code, trade_date, diluted_eps, LAG(diluted_eps, 4) OVER (PARTITION BY '
                        'ts_code ORDER BY trade_date) AS lag_eps FROM b WHERE q_rank = 1) SELECT ts_code, trade_date, CASE '
                        'WHEN lag_eps != 0 AND lag_eps IS NOT NULL THEN (diluted_eps - lag_eps) / ABS(lag_eps) END AS '
                        'EXPRESS_YOY_EPS FROM with_lag WHERE diluted_eps IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'EXPRESS_YOY_ROE',
        'category': 'financial',
        'description': '快报ROE同比增长（计算值）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ex AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, diluted_roe, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ann_date DESC) AS '
                        'rn FROM express), b AS (SELECT d.ts_code, d.trade_date, ex.diluted_roe, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY ex.ed_int DESC) AS q_rank FROM db d LEFT JOIN ex '
                        'ON d.ts_code = ex.ts_code AND ex.ed_int <= d.td_int AND ex.ann_date <= d.trade_date WHERE ex.rn = '
                        '1), with_lag AS (SELECT ts_code, trade_date, diluted_roe, LAG(diluted_roe, 4) OVER (PARTITION BY '
                        'ts_code ORDER BY trade_date) AS lag_roe FROM b WHERE q_rank = 1) SELECT ts_code, trade_date, CASE '
                        'WHEN lag_roe != 0 AND lag_roe IS NOT NULL THEN (diluted_roe - lag_roe) / ABS(lag_roe) END AS '
                        'EXPRESS_YOY_ROE FROM with_lag WHERE diluted_roe IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'EXPRESS_GROWTH_ASSETS',
        'category': 'financial',
        'description': '快报资产增长率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ex AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, total_assets, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ann_date DESC) '
                        'AS rn FROM express), b AS (SELECT d.ts_code, d.trade_date, ex.total_assets, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY ex.ed_int DESC) AS q_rank FROM db d LEFT JOIN ex '
                        'ON d.ts_code = ex.ts_code AND ex.ed_int <= d.td_int AND ex.ann_date <= d.trade_date WHERE ex.rn = '
                        '1), with_lag AS (SELECT ts_code, trade_date, total_assets, LAG(total_assets, 4) OVER (PARTITION '
                        'BY ts_code ORDER BY trade_date) AS lag_ta FROM b WHERE q_rank = 1) SELECT ts_code, trade_date, '
                        'CASE WHEN lag_ta != 0 AND lag_ta IS NOT NULL THEN (total_assets - lag_ta) / lag_ta END AS '
                        'EXPRESS_GROWTH_ASSETS FROM with_lag WHERE total_assets IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'TOP10_CONCENTRATION_CHANGE',
        'category': 'financial',
        'description': '前十大股东集中度变化',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), th AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, hold_ratio, holder_type, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY '
                        'ad_int DESC) AS rn FROM top10_holders), th_dedup AS (SELECT ts_code, end_date, ad_int, '
                        'hold_ratio, holder_type FROM th WHERE rn = 1), agg_top10 AS (SELECT ts_code, end_date, ad_int, '
                        'SUM(hold_ratio) AS sum_hold_ratio, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY '
                        'ad_int DESC) AS rn2 FROM th_dedup GROUP BY ts_code, end_date, ad_int), agg_latest AS (SELECT '
                        'ts_code, end_date, ad_int AS latest_ad_int, sum_hold_ratio FROM agg_top10 WHERE rn2 = 1), ranked '
                        'AS (SELECT d.ts_code, d.trade_date, a.sum_hold_ratio, ROW_NUMBER() OVER (PARTITION BY d.ts_code, '
                        'd.trade_date ORDER BY a.end_date DESC) AS rn FROM db d LEFT JOIN agg_latest a ON d.ts_code = '
                        'a.ts_code AND a.end_date <= d.trade_date AND a.latest_ad_int <= d.td_int), with_ratio AS (SELECT '
                        'ts_code, trade_date, sum_hold_ratio, LAG(sum_hold_ratio, 1) OVER (PARTITION BY ts_code ORDER BY '
                        'trade_date) AS prev_ratio FROM ranked WHERE rn = 1) SELECT ts_code, trade_date, sum_hold_ratio - '
                        'prev_ratio AS TOP10_CONCENTRATION_CHANGE FROM with_ratio WHERE sum_hold_ratio IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'FLOAT_TOP10_CONCENTRATION',
        'category': 'financial',
        'description': '前十大流通股东集中度',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), tf AS (SELECT "
                        'ts_code, end_date, ann_date, CAST(end_date AS INTEGER) AS ed_int, CAST(ann_date AS INTEGER) AS '
                        'ad_int, hold_float_ratio, holder_type, ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY '
                        'ad_int DESC) AS rn FROM top10_floatholders), tf_dedup AS (SELECT ts_code, end_date, ad_int, '
                        'hold_float_ratio, holder_type FROM tf WHERE rn = 1), agg_float AS (SELECT ts_code, end_date, '
                        'ad_int, SUM(hold_float_ratio) AS sum_float_ratio, ROW_NUMBER() OVER (PARTITION BY ts_code, '
                        'end_date ORDER BY ad_int DESC) AS rn2 FROM tf_dedup GROUP BY ts_code, end_date, ad_int), '
                        'agg_latest AS (SELECT ts_code, end_date, ad_int AS latest_ad_int, sum_float_ratio FROM agg_float '
                        'WHERE rn2 = 1), ranked AS (SELECT d.ts_code, d.trade_date, a.sum_float_ratio, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY a.end_date DESC) AS rn FROM db d LEFT JOIN '
                        'agg_latest a ON d.ts_code = a.ts_code AND a.end_date <= d.trade_date AND a.latest_ad_int <= '
                        'd.td_int) SELECT ts_code, trade_date, sum_float_ratio AS FLOAT_TOP10_CONCENTRATION FROM ranked '
                        'WHERE rn = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'INSIDER_NET_BUY_RATIO',
        'category': 'financial',
        'description': '高管净买入比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int, circ_mv '
                        "FROM daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), trade_dedup AS "
                        '(SELECT ts_code, ann_date, in_de, change_vol, CAST(ann_date AS INTEGER) AS ad_int, ROW_NUMBER() '
                        'OVER (PARTITION BY ts_code, ann_date ORDER BY ann_date DESC) AS rn FROM stk_holdertrade), recent '
                        "AS (SELECT d.ts_code, d.trade_date, d.circ_mv, SUM(CASE WHEN p.in_de = 'IN' THEN "
                        'CAST(p.change_vol AS DOUBLE) ELSE -CAST(p.change_vol AS DOUBLE) END) AS net_buy FROM db d LEFT '
                        'JOIN trade_dedup p ON d.ts_code = p.ts_code AND p.ad_int > d.td_int - 2500 AND p.ad_int <= '
                        'd.td_int GROUP BY d.ts_code, d.trade_date, d.circ_mv) SELECT ts_code, trade_date, CASE WHEN '
                        'circ_mv > 0 AND circ_mv IS NOT NULL THEN net_buy / circ_mv END AS INSIDER_NET_BUY_RATIO FROM '
                        'recent WHERE net_buy IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'INSIDER_BUY_AVG_PRICE_RATIO',
        'category': 'financial',
        'description': '增持均价/现价-1',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int, close FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), trade_dedup AS "
                        '(SELECT ts_code, ann_date, avg_price, holder_name, in_de, change_vol, CAST(ann_date AS INTEGER) '
                        'AS ad_int, ROW_NUMBER() OVER (PARTITION BY ts_code, ann_date ORDER BY ann_date DESC) AS rn FROM '
                        'stk_holdertrade), buy_recent AS (SELECT p.ts_code, p.ann_date, p.ad_int, p.avg_price FROM '
                        "trade_dedup p WHERE p.in_de = 'IN'), recent AS (SELECT d.ts_code, d.trade_date, d.close, "
                        'AVG(b.avg_price) AS avg_buy_price FROM db d LEFT JOIN buy_recent b ON d.ts_code = b.ts_code AND '
                        'b.ad_int > d.td_int - 2500 AND b.ad_int <= d.td_int GROUP BY d.ts_code, d.trade_date, d.close) '
                        'SELECT ts_code, trade_date, CASE WHEN close > 0 AND close IS NOT NULL AND avg_buy_price IS NOT '
                        'NULL THEN avg_buy_price / close - 1 END AS INSIDER_BUY_AVG_PRICE_RATIO FROM recent\n'
                        '        ',
        'enabled': True},
    {   'name': 'NET_CHANGE_RATIO',
        'category': 'financial',
        'description': '股东净变化比例',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int, '
                        "float_share FROM daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), "
                        'trade AS (SELECT ts_code, ann_date, in_de, change_ratio, CAST(ann_date AS INTEGER) AS ad_int FROM '
                        'stk_holdertrade), recent AS (SELECT d.ts_code, d.trade_date, d.float_share, '
                        "SUM(CAST(t.change_ratio AS DOUBLE) * CASE WHEN t.in_de = 'IN' THEN 1 ELSE -1 END) AS "
                        'net_change_ratio FROM db d LEFT JOIN trade t ON d.ts_code = t.ts_code AND t.ad_int > '
                        'CAST(d.td_int AS INTEGER) - 2500 AND t.ad_int <= d.td_int GROUP BY d.ts_code, d.trade_date, '
                        'd.float_share) SELECT ts_code, trade_date, net_change_ratio AS NET_CHANGE_RATIO FROM recent WHERE '
                        'net_change_ratio IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'BUYBACK_AMOUNT_RATIO',
        'category': 'financial',
        'description': '回购金额/流通市值',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int, circ_mv '
                        "FROM daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), rp AS (SELECT "
                        'ts_code, ann_date, amount, CAST(ann_date AS INTEGER) AS ad_int FROM stk_repurchase WHERE proc '
                        "LIKE '%实施%'), recent AS (SELECT d.ts_code, d.trade_date, d.circ_mv, SUM(CAST(rp.amount AS "
                        'DOUBLE)) AS buyback_amt FROM db d LEFT JOIN rp ON d.ts_code = rp.ts_code AND rp.ad_int > '
                        'CAST(d.td_int AS INTEGER) - 9000 AND rp.ad_int <= d.td_int GROUP BY d.ts_code, d.trade_date, '
                        'd.circ_mv) SELECT ts_code, trade_date, CASE WHEN circ_mv > 0 AND circ_mv IS NOT NULL THEN '
                        'buyback_amt / circ_mv END AS BUYBACK_AMOUNT_RATIO FROM recent WHERE buyback_amt IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'BUYBACK_PREMIUM',
        'category': 'financial',
        'description': '回购溢价率',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int, close FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), rp AS (SELECT "
                        'ts_code, ann_date, high_limit, low_limit, CAST(ann_date AS INTEGER) AS ad_int, ROW_NUMBER() OVER '
                        '(PARTITION BY ts_code, ann_date ORDER BY ann_date DESC) AS rn FROM stk_repurchase), recent AS '
                        '(SELECT d.ts_code, d.trade_date, d.close, rp.high_limit, rp.low_limit, ROW_NUMBER() OVER '
                        '(PARTITION BY d.ts_code, d.trade_date ORDER BY rp.ad_int DESC) AS rn2 FROM db d LEFT JOIN rp ON '
                        'd.ts_code = rp.ts_code AND rp.ad_int <= d.td_int AND rp.ad_int > CAST(d.td_int AS INTEGER) - 9000 '
                        'WHERE rp.rn = 1) SELECT ts_code, trade_date, CASE WHEN close > 0 AND close IS NOT NULL AND '
                        'high_limit IS NOT NULL THEN (high_limit - close) / close END AS BUYBACK_PREMIUM FROM recent WHERE '
                        'rn2 = 1\n'
                        '        ',
        'enabled': True},
    {   'name': 'BLOCK_TRADE_VOLUME_RATIO',
        'category': 'financial',
        'description': '大宗交易量占比',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), price AS (SELECT "
                        'ts_code, trade_date, CAST(vol AS DOUBLE) AS trade_vol, CAST(trade_date AS INTEGER) AS ptd_int '
                        "FROM prices WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), blk AS (SELECT "
                        'ts_code, trade_date AS blk_date, CAST(vol AS DOUBLE) AS blk_vol, CAST(trade_date AS INTEGER) AS '
                        'btd_int FROM block_trade), combined AS (SELECT d.ts_code, d.trade_date, p.trade_vol, '
                        'SUM(b.blk_vol) AS total_blk_vol FROM db d LEFT JOIN price p ON d.ts_code = p.ts_code AND '
                        'd.trade_date = p.trade_date LEFT JOIN blk b ON d.ts_code = b.ts_code AND b.btd_int > '
                        'CAST(d.td_int AS INTEGER) - 2000 AND b.btd_int <= d.td_int GROUP BY d.ts_code, d.trade_date, '
                        'p.trade_vol) SELECT ts_code, trade_date, CASE WHEN trade_vol > 0 AND trade_vol IS NOT NULL THEN '
                        'total_blk_vol / trade_vol END AS BLOCK_TRADE_VOLUME_RATIO FROM combined WHERE total_blk_vol IS '
                        'NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'BLOCK_DISCOUNT_DAYS',
        'category': 'financial',
        'description': '折价大宗交易天数',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int, close FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), blk AS (SELECT "
                        'ts_code, trade_date AS blk_date, price, CAST(trade_date AS INTEGER) AS btd_int FROM block_trade), '
                        'agg AS (SELECT d.ts_code, d.trade_date, d.close, COUNT(*) FILTER (WHERE CAST(blk.price AS DOUBLE) '
                        '< CAST(d.close AS DOUBLE) * 0.99) AS discount_days FROM db d LEFT JOIN blk ON d.ts_code = '
                        'blk.ts_code AND blk.btd_int > CAST(d.td_int AS INTEGER) - 2000 AND blk.btd_int <= d.td_int GROUP '
                        'BY d.ts_code, d.trade_date, d.close) SELECT ts_code, trade_date, discount_days AS '
                        'BLOCK_DISCOUNT_DAYS FROM agg WHERE discount_days IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'MF_DIVERGENCE',
        'category': 'financial',
        'description': '资金流向与价格背离',
        'sql_template': '\n'
                        '        WITH mf AS (\n'
                        '            SELECT\n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                net_mf_amount,\n'
                        '                SUM(net_mf_amount) OVER (\n'
                        '                    PARTITION BY ts_code ORDER BY trade_date\n'
                        '                    ROWS BETWEEN 19 PRECEDING AND CURRENT ROW\n'
                        '                ) AS mf_20d\n'
                        '            FROM moneyflow\n'
                        "            WHERE trade_date >= '{start_dt}'\n"
                        '        ), combined AS (\n'
                        '            SELECT\n'
                        '                d.ts_code,\n'
                        '                d.trade_date,\n'
                        '                CAST(d.close AS DOUBLE) AS close,\n'
                        '                LAG(CAST(d.close AS DOUBLE), 20) OVER (\n'
                        '                    PARTITION BY d.ts_code ORDER BY d.trade_date\n'
                        '                ) AS close_20d,\n'
                        '                m.mf_20d,\n'
                        '                LAG(m.mf_20d, 20) OVER (\n'
                        '                    PARTITION BY m.ts_code ORDER BY m.trade_date\n'
                        '                ) AS mf_20d_lag\n'
                        '            FROM daily_basic d\n'
                        '            LEFT JOIN mf m ON d.ts_code = m.ts_code AND d.trade_date = m.trade_date\n'
                        "            WHERE d.trade_date >= '{start_dt}' AND d.trade_date <= '{end_dt}'\n"
                        '        )\n'
                        '        SELECT\n'
                        '            ts_code,\n'
                        '            trade_date,\n'
                        '            CASE WHEN close_20d > 0 AND mf_20d_lag > 0\n'
                        '                 THEN (close / close_20d - 1) - (mf_20d / mf_20d_lag - 1)\n'
                        '            END AS MF_DIVERGENCE\n'
                        '        FROM combined\n'
                        '        WHERE close IS NOT NULL AND mf_20d IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'BROKER_CONSENSUS_CHANGE',
        'category': 'financial',
        'description': '券商金股共识变化',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), br AS (SELECT "
                        "ts_code, month, broker, CAST(month || '01' AS INTEGER) AS m_int FROM broker_recommend), curr AS "
                        '(SELECT d.ts_code, d.trade_date, COUNT(*) AS curr_cnt FROM db d LEFT JOIN br ON d.ts_code = '
                        'br.ts_code AND br.m_int <= d.td_int AND br.m_int > CAST(d.td_int AS INTEGER) - 1000 GROUP BY '
                        'd.ts_code, d.trade_date), prev AS (SELECT d.ts_code, d.trade_date, COUNT(*) AS prev_cnt FROM db d '
                        'LEFT JOIN br ON d.ts_code = br.ts_code AND br.m_int <= CAST(d.td_int AS INTEGER) - 1000 AND '
                        'br.m_int > CAST(d.td_int AS INTEGER) - 2000 GROUP BY d.ts_code, d.trade_date) SELECT c.ts_code, '
                        'c.trade_date, c.curr_cnt - p.prev_cnt AS BROKER_CONSENSUS_CHANGE FROM curr c LEFT JOIN prev p ON '
                        'c.ts_code = p.ts_code AND c.trade_date = p.trade_date WHERE c.curr_cnt IS NOT NULL\n'
                        '        ',
        'enabled': True},
    {   'name': 'LIMIT_UP_DAYS_20D',
        'category': 'financial',
        'description': '近20日涨停天数（INNER JOIN版：Hash Join替代ASOF，规避内存溢出）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), lim AS (SELECT "
                        'l.ts_code, l.trade_date, CAST(l.up_limit AS DOUBLE) AS up_limit_d, CAST(l.trade_date AS INTEGER) '
                        "AS ltd_int FROM stk_limit l WHERE l.up_limit IS NOT NULL AND l.trade_date >= '{start_dt}' AND "
                        "l.trade_date <= '{end_dt}'), lim_price AS (SELECT l.ts_code, l.trade_date AS lim_date, l.ltd_int, "
                        'l.up_limit_d, p.close FROM lim l INNER JOIN prices p ON l.ts_code = p.ts_code AND l.trade_date = '
                        'p.trade_date), lim_cnt AS (SELECT lp.ts_code, db.td_int, COUNT(*) AS cnt FROM db JOIN lim_price '
                        'lp ON db.ts_code = lp.ts_code AND lp.ltd_int > db.td_int - 2000 AND lp.ltd_int <= db.td_int WHERE '
                        'lp.close >= lp.up_limit_d * 0.999 GROUP BY lp.ts_code, db.td_int) SELECT db.ts_code, '
                        'db.trade_date, COALESCE(lc.cnt, 0) AS LIMIT_UP_DAYS_20D FROM db LEFT JOIN lim_cnt lc ON '
                        'db.ts_code = lc.ts_code AND db.td_int = lc.td_int\n'
                        '        ',
        'enabled': True},
    {   'name': 'SUSPENSION_DAYS',
        'category': 'financial',
        'description': '最近停牌持续天数（优化版：LATERAL子查询避免大中间表）',
        'sql_template': '\n'
                        '        WITH db AS (SELECT ts_code, trade_date, CAST(trade_date AS INTEGER) AS td_int FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'), ranked AS (SELECT "
                        'ts_code, trade_date AS susp_date, suspend_timing, CAST(trade_date AS INTEGER) AS sd_int, '
                        'ROW_NUMBER() OVER (PARTITION BY ts_code ORDER BY trade_date DESC) AS rn FROM suspend_d WHERE '
                        "trade_date >= STRFTIME(STRPTIME('{start_dt}', '%Y%m%d') - INTERVAL 2000 DAY, '%Y%m%d') AND "
                        "trade_date <= '{end_dt}') SELECT d.ts_code, d.trade_date, (SELECT d.td_int - MAX(r.sd_int) FROM "
                        'ranked r WHERE r.ts_code = d.ts_code AND r.sd_int <= d.td_int AND r.susp_date >= '
                        "STRFTIME(STRPTIME('{start_dt}', '%Y%m%d') - INTERVAL 2000 DAY, '%Y%m%d')) AS SUSPENSION_DAYS FROM "
                        'db d\n'
                        '        ',
        'enabled': True}
]