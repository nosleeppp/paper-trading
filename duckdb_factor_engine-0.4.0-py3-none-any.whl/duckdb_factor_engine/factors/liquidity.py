# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 流动性 因子定义
包含 10 个流动性类因子。
由 config.py 聚合后统一暴露。
"""

CATEGORY = "liquidity"

FACTORS = [
    {   'name': 'TURNOVER_1M',
        'category': 'liquidity',
        'description': '1个月换手率',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                turnover_rate AS TURNOVER_1M\n'
                        '            FROM daily_basic\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'TURNOVER_3M',
        'category': 'liquidity',
        'description': '3个月平均换手率',
        'sql_template': '\n'
                        '            SELECT \n'
                        '                ts_code,\n'
                        '                trade_date,\n'
                        '                avg_turnover AS TURNOVER_3M\n'
                        '            FROM (\n'
                        '                SELECT \n'
                        '                    ts_code,\n'
                        '                    trade_date,\n'
                        '                    AVG(turnover_rate) OVER (\n'
                        '                        PARTITION BY ts_code \n'
                        '                        ORDER BY trade_date \n'
                        '                        ROWS BETWEEN 62 PRECEDING AND CURRENT ROW\n'
                        '                    ) AS avg_turnover\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt_90d}' AND trade_date <= '{end_dt}'\n"
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'AMIHUD_20D',
        'category': 'liquidity',
        'description': 'Amihud 非流动性（20日均值）',
        'sql_template': '\n'
                        '            SELECT ts_code, trade_date,\n'
                        '                AVG(amihud) OVER (PARTITION BY ts_code ORDER BY trade_date\n'
                        '                                  ROWS BETWEEN 19 PRECEDING AND CURRENT ROW) AS AMIHUD_20D\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, close,\n'
                        '                    amount / 10000.0 AS amount_wan,\n'
                        '                    CASE WHEN prev_close > 0 AND amount / 10000.0 > 0\n'
                        '                         THEN ABS(close - prev_close) / prev_close / (amount / 10000.0) * '
                        '1000000.0\n'
                        '                         ELSE NULL END AS amihud\n'
                        '                FROM (\n'
                        '                    SELECT ts_code, trade_date, close, amount,\n'
                        '                           LAG(close) OVER (PARTITION BY ts_code ORDER BY trade_date) AS '
                        'prev_close\n'
                        '                    FROM prices\n'
                        "                    WHERE trade_date >= '{start_dt_20d}' AND trade_date <= '{end_dt}'\n"
                        '                )\n'
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}' AND amount_wan > 0\n"
                        '        ',
        'enabled': True},
    {   'name': 'TURNOVER_CV_20D',
        'category': 'liquidity',
        'description': '换手率变异系数（20日）',
        'sql_template': '\n'
                        '            SELECT ts_code, trade_date,\n'
                        '                CASE WHEN avg_tr > 0 THEN std_tr / avg_tr ELSE NULL END AS TURNOVER_CV_20D\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, turnover_rate,\n'
                        '                    AVG(turnover_rate) OVER (\n'
                        '                        PARTITION BY ts_code ORDER BY trade_date\n'
                        '                        ROWS BETWEEN 19 PRECEDING AND CURRENT ROW\n'
                        '                    ) AS avg_tr,\n'
                        '                    STDDEV_SAMP(turnover_rate) OVER (\n'
                        '                        PARTITION BY ts_code ORDER BY trade_date\n'
                        '                        ROWS BETWEEN 19 PRECEDING AND CURRENT ROW\n'
                        '                    ) AS std_tr\n'
                        '                FROM daily_basic\n'
                        "                WHERE trade_date >= '{start_dt_20d}' AND trade_date <= '{end_dt}'\n"
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'VOLRATIO_CV_20D',
        'category': 'liquidity',
        'description': '量比变异系数（20日）',
        'sql_template': '\n'
                        '            SELECT ts_code, trade_date,\n'
                        '                CASE WHEN avg_vol > 0 THEN std_vol / avg_vol ELSE NULL END AS VOLRATIO_CV_20D\n'
                        '            FROM (\n'
                        '                SELECT ts_code, trade_date, amount,\n'
                        '                    AVG(amount) OVER (\n'
                        '                        PARTITION BY ts_code ORDER BY trade_date\n'
                        '                        ROWS BETWEEN 19 PRECEDING AND CURRENT ROW\n'
                        '                    ) AS avg_vol,\n'
                        '                    STDDEV_SAMP(amount) OVER (\n'
                        '                        PARTITION BY ts_code ORDER BY trade_date\n'
                        '                        ROWS BETWEEN 19 PRECEDING AND CURRENT ROW\n'
                        '                    ) AS std_vol\n'
                        '                FROM prices\n'
                        "                WHERE trade_date >= '{start_dt_20d}' AND trade_date <= '{end_dt}'\n"
                        '                  AND amount > 0\n'
                        '            )\n'
                        "            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'DOLLAR_VOLUME',
        'category': 'liquidity',
        'description': '成交额因子（20日均值对数）',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, AVG(LN(CAST(close AS DOUBLE) * CAST(vol AS DOUBLE))) OVER '
                        '(PARTITION BY ts_code ORDER BY trade_date ROWS BETWEEN 19 PRECEDING AND CURRENT ROW) AS '
                        "DOLLAR_VOLUME FROM prices WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'TURNOVER_20D_STD',
        'category': 'liquidity',
        'description': '换手率20日标准差',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, STDDEV_SAMP(CAST(turnover_rate AS DOUBLE)) OVER (PARTITION BY '
                        'ts_code ORDER BY trade_date ROWS BETWEEN 19 PRECEDING AND CURRENT ROW) AS TURNOVER_20D_STD FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'TURNOVER_20D_CHANGE',
        'category': 'liquidity',
        'description': '换手率20日/60日变化',
        'sql_template': '\n'
                        '        WITH tb AS (SELECT ts_code, trade_date, AVG(CAST(turnover_rate AS DOUBLE)) OVER w_20d AS '
                        'ma20, AVG(CAST(turnover_rate AS DOUBLE)) OVER w_60d AS ma60 FROM daily_basic WHERE trade_date >= '
                        "'{start_dt}' AND trade_date <= '{end_dt}' WINDOW w_20d AS (PARTITION BY ts_code ORDER BY "
                        'trade_date ROWS BETWEEN 19 PRECEDING AND CURRENT ROW), w_60d AS (PARTITION BY ts_code ORDER BY '
                        'trade_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW)) SELECT ts_code, trade_date, CASE WHEN ma60 '
                        '!= 0 AND ma60 IS NOT NULL THEN ma20 / ma60 - 1 ELSE NULL END AS TURNOVER_20D_CHANGE FROM tb\n'
                        '        ',
        'enabled': True},
    {   'name': 'VOLUME_RATIO_MA',
        'category': 'liquidity',
        'description': '量比20日均值',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, AVG(CAST(volume_ratio AS DOUBLE)) OVER (PARTITION BY ts_code '
                        'ORDER BY trade_date ROWS BETWEEN 19 PRECEDING AND CURRENT ROW) AS VOLUME_RATIO_MA FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True},
    {   'name': 'FREE_FLOAT_RATIO',
        'category': 'liquidity',
        'description': '自由流通比例',
        'sql_template': '\n'
                        '        SELECT ts_code, trade_date, CASE WHEN total_share > 0 AND total_share IS NOT NULL THEN '
                        'CAST(free_share AS DOUBLE) / CAST(total_share AS DOUBLE) ELSE NULL END AS FREE_FLOAT_RATIO FROM '
                        "daily_basic WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'\n"
                        '        ',
        'enabled': True}
]