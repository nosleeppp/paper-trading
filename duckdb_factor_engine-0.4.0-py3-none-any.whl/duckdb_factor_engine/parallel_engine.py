#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
并行因子计算引擎 - Plan B（优化版）

核心改进：消除 Worker 重复 prep 工作

架构：
  主进程（单一 DuckDB，threads=32）
    ├── 预计算所有 prep tables（只执行一次）
    ├── 将 prep tables 导出为 parquet 文件（prep cache）
    └── 合并最终结果

  Worker 进程（spawn 方式）
    ├── 从 prep cache 加载 parquet 文件（只读扫描，不重复计算）
    └── 并行执行因子 SQL，写入 parquet

内存估算（8 workers + main，prep cache 约 8GB）：
  主进程 DuckDB：1×32GB
  8× Worker DuckDB（4GB/个）：8×4GB = 32GB
  prep cache 文件：~10GB（临时）
  OS + Python：~6GB
  合计：~80GB < 105GB ✅

关键：每个 Worker 不再重复执行 prep tables 的 SQL，
      而是直接加载已计算好的 parquet，大幅降低 CPU 浪费。
"""

import duckdb
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
import logging
import signal
import os
import math
import multiprocessing as mp
from multiprocessing import Pool
import shutil
import sys

# 兼容两种运行方式：
# 1. 作为包内模块（from .config import ...）
# 2. 用户复制模板后直接运行（from parallel_engine import ...）
try:
    from .config import FACTORS_CONFIG, get_factor_names, get_factor_config
except ImportError:
    from config import FACTORS_CONFIG, get_factor_names, get_factor_config

signal.signal(signal.SIGTERM, signal.SIG_IGN)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)


# ============================================================
# Plan B: Worker 从 prep cache 加载，不重复计算
# ============================================================

def _worker_run_planb(args):
    """
    Worker 函数（Plan B）：从 prep cache 加载 parquet，执行因子 SQL

    args = (worker_id, factor_names, start_dt, end_dt, output_dir_str,
            prep_cache_dir_str, data_dir_str)
    """
    worker_id, factor_names, start_dt, end_dt = args[0], args[1], args[2], args[3]
    output_dir_str = args[4]
    prep_cache_dir_str = args[5]
    data_dir_str = args[6]

    output_dir = Path(output_dir_str)
    output_dir.mkdir(parents=True, exist_ok=True)
    prep_cache = Path(prep_cache_dir_str)
    data_dir = Path(data_dir_str)

    # ---- Worker 独立 DuckDB ----
    con = duckdb.connect()
    con.execute("SET threads = 4")
    con.execute("SET memory_limit = '4GB'")

    # ---- 注册原始数据视图（只读扫描）----
    _register_original_views(con, data_dir)

    # ---- 从 prep cache 加载预计算表（不重复计算）----
    _load_prep_cache(con, prep_cache)

    # ---- 计算因子 ----
    computed = []
    failed = []

    for fname in factor_names:
        config = get_factor_config(fname)
        if config is None or not config.get('enabled', True):
            continue

        dt_start = datetime.strptime(start_dt, '%Y%m%d')
        start_dt_20d = (dt_start - timedelta(days=30)).strftime('%Y%m%d')
        start_dt_60d = (dt_start - timedelta(days=90)).strftime('%Y%m%d')
        start_dt_2y = (dt_start - timedelta(days=740)).strftime('%Y%m%d')

        sql = config['sql_template'].format(
            start_dt=start_dt,
            end_dt=end_dt,
            start_dt_20d=start_dt_20d,
            start_dt_60d=start_dt_60d,
            start_dt_2y=start_dt_2y,
        )

        t0 = datetime.now()
        try:
            df = con.execute(sql).fetchdf()
            elapsed = (datetime.now() - t0).total_seconds()
            if len(df) > 0:
                df.to_parquet(output_dir / f'{fname}.parquet', index=False)
                computed.append((fname, len(df), elapsed))
            else:
                failed.append((fname, 'empty'))
        except Exception as e:
            failed.append((fname, str(e)[:80]))

    con.close()
    return worker_id, computed, failed


def _register_original_views(con, data_dir):
    """注册原始数据视图（只读扫描）"""
    views = {
        'prices': data_dir / 'daily_hfq',
        'daily_basic': data_dir / 'daily_basic',
        'moneyflow': data_dir / 'moneyflow',
        'stk_holdernumber': data_dir / 'stk_holdernumber',
        'stk_factor_pro': data_dir / 'stk_factor_pro',
        'income_vip': data_dir / 'income',
        'income_raw': data_dir / 'income',
        'fina_indicator': data_dir / 'fina_indicator',
        'fina_cashflow_vip': data_dir / 'fina_cashflow_vip',
        'fina_balancesheet_vip': data_dir / 'fina_balancesheet',
        'fina_audit': data_dir / 'fina_audit',
        'dividend': data_dir / 'dividend',
        'top10_holders': data_dir / 'top10_holders',
        'top10_floatholders': data_dir / 'top10_floatholders',
        'stk_holdertrade': data_dir / 'stk_holdertrade',
        'stk_repurchase': data_dir / 'stk_repurchase',
        'express': data_dir / 'express',
        'report_rc': data_dir / 'report_rc',
        'broker_recommend': data_dir / 'broker_recommend',
        'hk_hold': data_dir / 'hk_hold',
        'top_list': data_dir / 'top_list',
        'stk_limit': data_dir / 'stk_limit',
        'suspend_d': data_dir / 'suspend_d.parquet',
        'index_weight': data_dir / 'index_weight',
        'block_trade': data_dir / 'block_trade',
    }

    for name, path in views.items():
        if path.exists():
            pattern = str(path / '*.parquet') if path.is_dir() else str(path)
            try:
                con.execute(f"CREATE OR REPLACE VIEW {name} AS SELECT * FROM read_parquet('{pattern}')")
            except Exception:
                pass


def _load_prep_cache(con, prep_cache: Path):
    """
    从 prep cache 加载预计算表（替代 Worker 内的重复计算）

    将 prep tables 作为.parquet 文件加载为 DuckDB 视图，
    视图名与原始 prep 表名一致，SQL 无需修改。
    """
    # prep_cache 目录结构：
    #   prep_cache/
    #     fina_indicator_prep.parquet
    #     fina_indicator_ly.parquet
    #     income_prep.parquet
    #     income_ly.parquet
    #     income_sorted.parquet
    #     fina_indicator_sorted.parquet
    #     stk_holdernumber_prep.parquet
    #     dividend_prep.parquet
    #     fina_cashflow_vip_prep.parquet
    #     fina_balancesheet_vip_prep.parquet
    #     income_exp_sorted.parquet
    #     fina_ind_full_sorted.parquet
    #     finabal_full_sorted.parquet
    #     finacf_full_sorted.parquet
    #     income_ttm_prep.parquet

    # 视图名到文件名（部分需要映射）
    view_files = {
        'fina_indicator_prep': 'fina_indicator_prep.parquet',
        'fina_indicator_ly': 'fina_indicator_ly.parquet',
        'income_prep': 'income_prep.parquet',
        'income_ly': 'income_ly.parquet',
        'income_sorted': 'income_sorted.parquet',
        'fina_indicator_sorted': 'fina_indicator_sorted.parquet',
        'stk_holdernumber_prep': 'stk_holdernumber_prep.parquet',
        'dividend_prep': 'dividend_prep.parquet',
        'fina_cashflow_vip_prep': 'fina_cashflow_vip_prep.parquet',
        'fina_balancesheet_vip_prep': 'fina_balancesheet_vip_prep.parquet',
        'income_exp_sorted': 'income_exp_sorted.parquet',
        'fina_ind_full_sorted': 'fina_ind_full_sorted.parquet',
        'finabal_full_sorted': 'finabal_full_sorted.parquet',
        'finacf_full_sorted': 'finacf_full_sorted.parquet',
        'income_ttm_prep': 'income_ttm_prep.parquet',
        'ar_turn_latest': 'ar_turn_latest.parquet',
    }

    for view_name, file_name in view_files.items():
        fpath = prep_cache / file_name
        if fpath.exists():
            try:
                con.execute(
                    f"CREATE OR REPLACE VIEW {view_name} AS "
                    f"SELECT * FROM read_parquet('{fpath}')"
                )
            except Exception:
                pass


# ============================================================
# 主引擎类 - Plan B
# ============================================================

class ParallelFactorEngine:
    """
    并行因子计算引擎 - Plan B

    改进点：
    1. 主进程统一执行 prep tables 计算（只一次）
    2. 将 prep tables 导出为 parquet cache
    3. Worker 从 cache 加载，不重复计算 prep
    4. 每个 Worker 有独立 DuckDB，执行因子 SQL

    使用示例：
        engine = ParallelFactorEngine(
            data_dir='./data',
            output_dir='./output/parallel_test',
            n_workers=8
        )
        results = engine.run('2024-01-01', '2024-12-31')
        engine.close()
    """

    def __init__(self, data_dir: str, output_dir: str, n_workers: int = None):
        self.data_dir = Path(data_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        if n_workers is None:
            n_workers = min(os.cpu_count() or 8, 16)
        self.n_workers = n_workers

        # 主进程 DuckDB：32线程（充分利用多核）
        self.con = duckdb.connect()
        self.con.execute("SET threads = 32")
        self.con.execute("SET memory_limit = '32GB'")

        # prep cache 目录
        self.prep_cache_dir = self.output_dir / '_prep_cache'
        self.prep_cache_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"✅ 主进程 DuckDB 初始化完成 (threads=32, n_workers={self.n_workers})")

    def run(self, start_date: str, end_date: str, factor_names=None):
        """
        并行计算因子（Plan B）
        """
        start_dt = start_date.replace('-', '')
        end_dt = end_date.replace('-', '')

        if factor_names is None:
            all_factors = get_factor_names(enabled_only=True)
        else:
            all_factors = list(factor_names)

        total = len(all_factors)
        logger.info(f"\n{'='*60}")
        logger.info(f"并行因子引擎 [Plan B]")
        logger.info(f"  因子总数: {total}")
        logger.info(f"  Workers: {self.n_workers}")
        logger.info(f"  区间: {start_dt} ~ {end_dt}")
        logger.info(f"{'='*60}")

        # ---- Step 1: 注册视图 + 预计算 + 导出 prep cache ----
        prep_start = datetime.now()
        self._register_views()
        self._prepare_and_export_prep_cache(start_dt, end_dt)
        prep_elapsed = (datetime.now() - prep_start).total_seconds()
        logger.info(f"  Prep (主进程): {prep_elapsed:.1f}秒")

        # ---- Step 2: 均分因子给 workers ----
        chunk_size = math.ceil(total / self.n_workers)
        factor_chunks = []
        for i in range(0, total, chunk_size):
            factor_chunks.append(all_factors[i:i + chunk_size])

        worker_args = []
        for wid, chunk in enumerate(factor_chunks):
            sub_dir = self.output_dir / f'_worker_{wid}'
            sub_dir.mkdir(parents=True, exist_ok=True)
            worker_args.append((
                wid, chunk, start_dt, end_dt,
                str(sub_dir),
                str(self.prep_cache_dir),
                str(self.data_dir)
            ))

        # ---- Step 3: Worker 并行计算 ----
        worker_start = datetime.now()
        ctx = mp.get_context('spawn')
        with ctx.Pool(processes=self.n_workers) as pool:
            results = pool.map(_worker_run_planb, worker_args)
        worker_elapsed = (datetime.now() - worker_start).total_seconds()

        # ---- Step 4: 收集结果 ----
        total_computed = 0
        total_failed = 0
        all_factor_files = []

        for wid, computed, failed in results:
            total_computed += len(computed)
            total_failed += len(failed)
            sub_dir = self.output_dir / f'_worker_{wid}'
            for fname, nrows, elapsed in computed:
                fpath = sub_dir / f'{fname}.parquet'
                if fpath.exists():
                    all_factor_files.append((fname, fpath))

        total_elapsed = (datetime.now() - prep_start).total_seconds()

        logger.info(f"\n{'='*60}")
        logger.info(f"✅ 计算完成")
        logger.info(f"  成功: {total_computed}/{total}")
        logger.info(f"  失败: {total_failed}")
        logger.info(f"  Prep: {prep_elapsed:.1f}秒")
        logger.info(f"  Workers: {worker_elapsed:.1f}秒")
        logger.info(f"  总耗时: {total_elapsed:.1f}秒")
        logger.info(f"{'='*60}")

        if total_computed > 0:
            self._merge_factors(all_factor_files)

        # ---- Step 5: 清理 prep cache ----
        shutil.rmtree(self.prep_cache_dir, ignore_errors=True)

        return [f[0] for f in all_factor_files]

    def _register_views(self):
        views = {
            'prices': self.data_dir / 'daily_hfq',
            'daily_basic': self.data_dir / 'daily_basic',
            'moneyflow': self.data_dir / 'moneyflow',
            'stk_holdernumber': self.data_dir / 'stk_holdernumber',
            'stk_factor_pro': self.data_dir / 'stk_factor_pro',
            'income_vip': self.data_dir / 'income',
            'income_raw': self.data_dir / 'income',
            'fina_indicator': self.data_dir / 'fina_indicator',
            'fina_cashflow_vip': self.data_dir / 'fina_cashflow_vip',
            'fina_balancesheet_vip': self.data_dir / 'fina_balancesheet',
            'fina_audit': self.data_dir / 'fina_audit',
            'dividend': self.data_dir / 'dividend',
            'top10_holders': self.data_dir / 'top10_holders',
            'top10_floatholders': self.data_dir / 'top10_floatholders',
            'stk_holdertrade': self.data_dir / 'stk_holdertrade',
            'stk_repurchase': self.data_dir / 'stk_repurchase',
            'express': self.data_dir / 'express',
            'report_rc': self.data_dir / 'report_rc',
            'broker_recommend': self.data_dir / 'broker_recommend',
            'hk_hold': self.data_dir / 'hk_hold',
            'top_list': self.data_dir / 'top_list',
            'stk_limit': self.data_dir / 'stk_limit',
            'suspend_d': self.data_dir / 'suspend_d.parquet',
            'index_weight': self.data_dir / 'index_weight',
            'block_trade': self.data_dir / 'block_trade',
        }

        for name, path in views.items():
            if path.exists():
                pattern = str(path / '*.parquet') if path.is_dir() else str(path)
                try:
                    self.con.execute(f"CREATE OR REPLACE VIEW {name} AS SELECT * FROM read_parquet('{pattern}')")
                except Exception as e:
                    logger.warning(f"视图 {name} 创建失败: {e}")

    def _prepare_and_export_prep_cache(self, start_dt: str, end_dt: str):
        """
        执行 prep tables 计算，并将结果导出为 parquet 文件。
        Worker 从这些 parquet 加载，避免重复计算。
        """
        try:
            from .core import FactorEngineV72
        except ImportError:
            from core import FactorEngineV72
        engine = FactorEngineV72.__new__(FactorEngineV72)
        engine.con = self.con
        engine.data_dir = self.data_dir
        engine._register_views = lambda: None
        engine._prepare_financial_tables_fixed()
        logger.info("✅ 财务数据预处理完成")

        # 导出 prep tables 到 parquet
        export_start = datetime.now()
        prep_tables = [
            'fina_indicator_prep',
            'fina_indicator_ly',
            'income_prep',
            'income_ly',
            'income_sorted',
            'fina_indicator_sorted',
            'stk_holdernumber_prep',
            'dividend_prep',
            'fina_cashflow_vip_prep',
            'fina_balancesheet_vip_prep',
            'income_exp_sorted',
            'fina_ind_full_sorted',
            'finabal_full_sorted',
            'finacf_full_sorted',
            'income_ttm_prep',
            'ar_turn_latest',
        ]

        # 创建 ar_turn_latest 预物化表（AR_TURNOVER_CHANGE 优化，99%提速）
        logger.info("  创建 ar_turn_latest 预物化表...")
        try:
            engine.con.execute("DROP TABLE IF EXISTS ar_turn_latest")
            engine.con.execute("""
                CREATE TABLE ar_turn_latest AS
                WITH db AS (
                    SELECT DISTINCT ts_code, CAST(trade_date AS INTEGER) AS td_int
                    FROM daily_basic
                ),
                fi AS (
                    SELECT ts_code,
                           CAST(end_date AS INTEGER) AS ed_int,
                           CAST(ann_date AS INTEGER) AS ad_int,
                           CAST(ar_turn AS DOUBLE) AS ar_turn,
                           ROW_NUMBER() OVER (PARTITION BY ts_code, end_date ORDER BY ann_date DESC) AS rn_ed
                    FROM fina_indicator
                    WHERE ar_turn IS NOT NULL
                ),
                fi_dedup AS (
                    SELECT ts_code, ed_int, ad_int, ar_turn FROM fi WHERE rn_ed = 1
                ),
                joined AS (
                    SELECT db.ts_code, db.td_int, fi_dedup.ar_turn,
                           ROW_NUMBER() OVER (
                               PARTITION BY db.ts_code, db.td_int
                               ORDER BY fi_dedup.ed_int DESC, fi_dedup.ad_int DESC
                           ) AS rn
                    FROM db
                    LEFT JOIN fi_dedup
                        ON db.ts_code = fi_dedup.ts_code
                        AND fi_dedup.ed_int <= db.td_int
                        AND fi_dedup.ad_int <= db.td_int
                )
                SELECT ts_code, td_int, ar_turn
                FROM joined
                WHERE ar_turn IS NOT NULL AND rn = 1
                ORDER BY ts_code, td_int
            """)
            ar_cnt = engine.con.execute("SELECT COUNT(*) FROM ar_turn_latest").fetchone()[0]
            logger.info(f"     ar_turn_latest: {ar_cnt:,}行")
        except Exception as e:
            logger.warning(f"     ar_turn_latest 创建失败: {e}")

        logger.info(f"  导出 {len(prep_tables)} 个 prep tables 到 cache...")
        for tbl in prep_tables:
            try:
                df = self.con.execute(f"SELECT * FROM {tbl}").fetchdf()
                out_path = self.prep_cache_dir / f'{tbl}.parquet'
                df.to_parquet(out_path, index=False)
            except Exception as e:
                logger.warning(f"  导出 {tbl} 失败: {e}")

        export_elapsed = (datetime.now() - export_start).total_seconds()

        # 报告 cache 大小
        cache_size = sum(f.stat().st_size for f in self.prep_cache_dir.glob('*.parquet'))
        logger.info(f"  Prep cache 大小: {cache_size / 1024 / 1024:.1f} MB, 导出耗时: {export_elapsed:.1f}秒")

    def _merge_factors(self, factor_files: list):
        """合并所有因子 parquet"""
        import time
        merge_start = time.time()
        BATCH_SIZE = 8

        output_path = self.output_dir / 'factors_all.parquet'
        output_path_str = str(output_path).replace('\\', '/')

        logger.info(f"\n合并 {len(factor_files)} 个因子...")

        if len(factor_files) <= BATCH_SIZE:
            self._merge_batch(
                [f[1] for f in factor_files],
                [f[0] for f in factor_files],
                output_path
            )
        else:
            batch_files = []
            for batch_start in range(0, len(factor_files), BATCH_SIZE):
                batch = factor_files[batch_start:batch_start + BATCH_SIZE]
                batch_idx = batch_start // BATCH_SIZE + 1
                batch_path = self.output_dir / f'_batch_{batch_idx}.parquet'
                batch_files.append(str(batch_path).replace('\\', '/'))
                self._merge_batch(
                    [f[1] for f in batch],
                    [f[0] for f in batch],
                    batch_path
                )
            self._merge_batch_files(batch_files, output_path)
            for bf in batch_files:
                Path(bf).unlink(missing_ok=True)

        # 清理 worker 子目录
        for wid in range(self.n_workers):
            sub_dir = self.output_dir / f'_worker_{wid}'
            if sub_dir.exists():
                shutil.rmtree(sub_dir, ignore_errors=True)

        merge_elapsed = time.time() - merge_start
        if output_path.exists():
            size_mb = output_path.stat().st_size / 1024 / 1024
            logger.info(f"✅ 合并完成: {output_path.name} ({size_mb:.1f} MB), 耗时: {merge_elapsed:.2f}s")

    def _merge_batch(self, file_paths: list, factor_names: list, output_path: Path):
        output_path_str = str(output_path).replace('\\', '/')
        first = factor_names[0]
        first_pq = str(file_paths[0]).replace('\\', '/')

        from_clause = f"(SELECT ts_code, trade_date, {first} FROM read_parquet('{first_pq}') GROUP BY ts_code, trade_date, {first}) t0"
        join_clauses = []
        select_cols = [f"t0.{first}"]

        for i, (fname, fpath) in enumerate(zip(factor_names[1:], file_paths[1:]), 1):
            alias = f"t{i}"
            pq_path = str(fpath).replace('\\', '/')
            join_clauses.append(
                f"LEFT JOIN (SELECT ts_code, trade_date, {fname} FROM read_parquet('{pq_path}') GROUP BY ts_code, trade_date, {fname}) {alias} "
                f"ON {alias}.ts_code = t0.ts_code AND {alias}.trade_date = t0.trade_date"
            )
            select_cols.append(f"{alias}.{fname}")

        select_clause = 't0.ts_code, t0.trade_date, ' + ', '.join(select_cols)
        sql = f"COPY (SELECT {select_clause} FROM {from_clause} {' '.join(join_clauses)}) TO '{output_path_str}' (FORMAT PARQUET)"
        self.con.execute(sql)

    def _merge_batch_files(self, batch_files: list, output_path: Path):
        output_path_str = str(output_path).replace('\\', '/')
        first = batch_files[0]
        first_cols = self.con.execute(f"SELECT * FROM read_parquet('{first}') LIMIT 0").fetchdf().columns.tolist()
        first_extra = [c for c in first_cols if c not in ('ts_code', 'trade_date')]
        first_agg = ', '.join([f"ANY_VALUE({c}) AS {c}" for c in first_extra])

        from_clause = f"(SELECT ts_code, trade_date, {first_agg} FROM read_parquet('{first}') GROUP BY ts_code, trade_date) t0"
        select_cols = list(first_extra)
        join_clauses = []

        for i, fpath in enumerate(batch_files[1:], 1):
            alias = f"t{i}"
            sample_cols = self.con.execute(f"SELECT * FROM read_parquet('{fpath}') LIMIT 0").fetchdf().columns.tolist()
            extra_cols = [c for c in sample_cols if c not in ('ts_code', 'trade_date')]
            for col in extra_cols:
                select_cols.append(f"{alias}.{col}")
            agg = ', '.join([f"ANY_VALUE({c}) AS {c}" for c in extra_cols])
            join_clauses.append(
                f"LEFT JOIN (SELECT ts_code, trade_date, {agg} FROM read_parquet('{fpath}') GROUP BY ts_code, trade_date) {alias} "
                f"ON {alias}.ts_code = t0.ts_code AND {alias}.trade_date = t0.trade_date"
            )

        select_clause = 't0.ts_code, t0.trade_date, ' + ', '.join(select_cols)
        sql = f"COPY (SELECT {select_clause} FROM {from_clause} {' '.join(join_clauses)}) TO '{output_path_str}' (FORMAT PARQUET)"
        self.con.execute(sql)

    def close(self):
        self.con.close()
