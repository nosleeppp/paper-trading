# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 统一视图注册模块

这是整个包中数据视图注册的**唯一入口**。
所有组件（BatchEngine、IncrementalEngine、OnlineEngine、Worker、Template）
均通过此模块注册视图，确保一致性。

数据视图映射关系:
  prices               → data_dir/daily_hfq/*.parquet
  daily_basic          → data_dir/daily_basic/*.parquet
  moneyflow            → data_dir/moneyflow/*.parquet
  stk_holdernumber     → data_dir/stk_holdernumber/*.parquet
  stk_factor_pro       → data_dir/stk_factor_pro/stk_factor_pro.parquet
  income_vip           → data_dir/income/*.parquet
  income_raw           → data_dir/income/*.parquet
  fina_indicator       → data_dir/fina_indicator/*.parquet
  fina_cashflow_vip    → data_dir/fina_cashflow_vip/*.parquet
  fina_balancesheet_vip → data_dir/fina_balancesheet/*.parquet
  fina_audit           → data_dir/fina_audit/*.parquet
  dividend             → data_dir/dividend/*.parquet
  top10_holders        → data_dir/top10_holders/*.parquet
  top10_floatholders   → data_dir/top10_floatholders/*.parquet
  stk_holdertrade      → data_dir/stk_holdertrade/*.parquet
  stk_repurchase       → data_dir/stk_repurchase/*.parquet
  express              → data_dir/express/*.parquet
  broker_recommend     → data_dir/broker_recommend/*.parquet
  hk_hold              → data_dir/hk_hold/*.parquet
  top_list             → data_dir/top_list/*.parquet
  stk_limit            → data_dir/stk_limit/*.parquet
  suspend_d            → data_dir/suspend_d.parquet
  index_weight         → data_dir/index_weight/*.parquet
  block_trade          → data_dir/block_trade/*.parquet
"""

import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# ── 视图定义 ──────────────────────────────────────────────────────────

def _get_view_definitions(data_dir: str) -> dict:
    """
    返回所有数据视图的 (name → path_pattern) 映射。

    调用方应使用此函数获取视图定义，而非自行维护。
    """
    return {
        # 基础行情
        'prices':               f'{data_dir}/daily_hfq',
        'daily_basic':          f'{data_dir}/daily_basic',
        'moneyflow':            f'{data_dir}/moneyflow',
        'stk_holdernumber':     f'{data_dir}/stk_holdernumber',
        'stk_factor_pro':       f'{data_dir}/stk_factor_pro',
        # 财务原始表
        'income_vip':           f'{data_dir}/income',
        'income_raw':           f'{data_dir}/income',
        'fina_indicator':       f'{data_dir}/fina_indicator',
        'fina_cashflow_vip':    f'{data_dir}/fina_cashflow_vip',
        'fina_balancesheet_vip': f'{data_dir}/fina_balancesheet',
        'fina_audit':           f'{data_dir}/fina_audit',
        # 股东/分红
        'dividend':             f'{data_dir}/dividend',
        'top10_holders':        f'{data_dir}/top10_holders',
        'top10_floatholders':   f'{data_dir}/top10_floatholders',
        'stk_holdertrade':      f'{data_dir}/stk_holdertrade',
        'stk_repurchase':       f'{data_dir}/stk_repurchase',
        # 公告/业绩
        'express':              f'{data_dir}/express',
        'broker_recommend':     f'{data_dir}/broker_recommend',
        # 资金流
        'hk_hold':              f'{data_dir}/hk_hold',
        'top_list':             f'{data_dir}/top_list',
        'stk_limit':            f'{data_dir}/stk_limit',
        # 涨跌/指数
        'suspend_d':            f'{data_dir}/suspend_d.parquet',
        'index_weight':         f'{data_dir}/index_weight',
        # 大宗
        'block_trade':          f'{data_dir}/block_trade',
    }


def register_all_views(con, data_dir: str):
    """
    将数据目录中的所有 parquet 文件注册为 DuckDB 视图。

    Args:
        con: DuckDB 连接
        data_dir: 数据根目录路径
    """
    views = _get_view_definitions(data_dir)
    for name, path in views.items():
        if os.path.exists(path):
            pattern = f'{path}/*.parquet' if os.path.isdir(path) else path
            try:
                con.execute(
                    f"CREATE OR REPLACE VIEW {name} AS "
                    f"SELECT * FROM read_parquet('{pattern}')"
                )
            except Exception as e:
                logger.debug(f"视图 {name} 创建失败（可忽略）: {e}")
        else:
            logger.debug(f"视图路径不存在，跳过: {name} → {path}")


# ── Prep 表导出/加载 ──────────────────────────────────────────────────

PREP_TABLES = [
    'fina_indicator_prep',
    'income_prep',
    'stk_holdernumber_prep',
    'dividend_prep',
    'fina_cashflow_vip_prep',
    'fina_balancesheet_vip_prep',
    'stk_repurchase_prep',
    'fina_indicator_sorted',
    'income_sorted',
    'income_ttm_prep',
    'fina_indicator_ly',
    'income_ly',
    'income_exp_sorted',
    'fina_ind_full_sorted',
    'finabal_full_sorted',
    'finacf_full_sorted',
    'ar_turn_latest',
]


def export_prep_tables(con, prep_dir: str) -> list[str]:
    """
    将主进程 DuckDB 中的 prep 表导出为 parquet 文件。

    Returns:
        成功导出的表名列表
    """
    os.makedirs(prep_dir, exist_ok=True)
    exported = []
    for tbl in PREP_TABLES:
        out_path = os.path.join(prep_dir, f'{tbl}.parquet')
        try:
            df = con.execute(f"SELECT * FROM {tbl}").fetchdf()
            df.to_parquet(out_path, index=False)
            exported.append(tbl)
        except Exception:
            pass
    return exported


def register_prep_views_from_parquet(con, prep_dir: str) -> list[str]:
    """
    从 prep parquet 文件注册 DuckDB 视图（跳过耗时的 SQL 预处理）。

    Returns:
        成功注册的视图名列表
    """
    registered = []
    for tbl in PREP_TABLES:
        parquet_path = os.path.join(prep_dir, f'{tbl}.parquet')
        if os.path.exists(parquet_path):
            try:
                con.execute(
                    f"CREATE OR REPLACE VIEW {tbl} AS "
                    f"SELECT * FROM read_parquet('{parquet_path}')"
                )
                registered.append(tbl)
            except Exception:
                pass
    return registered
