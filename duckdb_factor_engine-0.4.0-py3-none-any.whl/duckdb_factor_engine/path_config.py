#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine 路径配置管理

支持通过环境变量或代码配置路径，移除硬编码。

环境变量：
- DUCKDB_DATA_DIR: 数据目录路径
- DUCKDB_OUTPUT_DIR: 输出目录路径
- DUCKDB_MONEYFLOW_DIR: 资金流数据目录路径
- DUCKDB_LOG_DIR: 日志目录路径

使用示例：
    import os
    os.environ['DUCKDB_DATA_DIR'] = '/path/to/data'
    
    from duckdb_factor_engine.path_config import get_data_dir
    print(get_data_dir())
"""

import os
from pathlib import Path
from typing import Optional


class DuckDBPathConfig:
    """
    DuckDB Factor Engine 路径配置类
    
    支持三种配置方式（优先级从高到低）：
    1. 直接设置属性
    2. 环境变量
    3. 默认值
    """
    
    def __init__(self):
        # 数据目录
        self._data_dir: Optional[Path] = None
        
        # 输出目录
        self._output_dir: Optional[Path] = None
        
        # 资金流数据目录
        self._moneyflow_dir: Optional[Path] = None
        
        # 日志目录
        self._log_dir: Optional[Path] = None
        
        # 参考文件路径
        self._ref_file: Optional[Path] = None
    
    @property
    def data_dir(self) -> Path:
        """数据目录"""
        if self._data_dir is not None:
            return self._data_dir
        
        # 从环境变量获取
        env_val = os.getenv('DUCKDB_DATA_DIR')
        if env_val:
            return Path(env_val)
        
        # 默认值：当前目录下的data文件夹
        return Path.cwd() / 'data'
    
    @data_dir.setter
    def data_dir(self, value: str or Path):
        self._data_dir = Path(value) if value else None
    
    @property
    def output_dir(self) -> Path:
        """输出目录"""
        if self._output_dir is not None:
            return self._output_dir
        
        # 从环境变量获取
        env_val = os.getenv('DUCKDB_OUTPUT_DIR')
        if env_val:
            return Path(env_val)
        
        # 默认值：当前目录下的output文件夹
        return Path.cwd() / 'output'
    
    @output_dir.setter
    def output_dir(self, value: str or Path):
        self._output_dir = Path(value) if value else None
    
    @property
    def moneyflow_dir(self) -> Path:
        """资金流数据目录"""
        if self._moneyflow_dir is not None:
            return self._moneyflow_dir
        
        # 从环境变量获取
        env_val = os.getenv('DUCKDB_MONEYFLOW_DIR')
        if env_val:
            return Path(env_val)
        
        # 默认值：data目录下的moneyflow文件夹
        return self.data_dir / 'moneyflow'
    
    @moneyflow_dir.setter
    def moneyflow_dir(self, value: str or Path):
        self._moneyflow_dir = Path(value) if value else None
    
    @property
    def log_dir(self) -> Path:
        """日志目录"""
        if self._log_dir is not None:
            return self._log_dir
        
        # 从环境变量获取
        env_val = os.getenv('DUCKDB_LOG_DIR')
        if env_val:
            return Path(env_val)
        
        # 默认值：当前目录下的logs文件夹
        return Path.cwd() / 'logs'
    
    @log_dir.setter
    def log_dir(self, value: str or Path):
        self._log_dir = Path(value) if value else None
    
    @property
    def ref_file(self) -> Path:
        """参考因子文件路径"""
        if self._ref_file is not None:
            return self._ref_file
        
        # 从环境变量获取
        env_val = os.getenv('DUCKDB_REF_FILE')
        if env_val:
            return Path(env_val)
        
        # 默认值：output目录下的factors_all_v3.parquet
        return self.output_dir / 'factors_all_v3.parquet'
    
    @ref_file.setter
    def ref_file(self, value: str or Path):
        self._ref_file = Path(value) if value else None
    
    def set_paths(
        self,
        data_dir: str or Path = None,
        output_dir: str or Path = None,
        moneyflow_dir: str or Path = None,
        log_dir: str or Path = None,
        ref_file: str or Path = None
    ):
        """
        批量设置路径
        
        Args:
            data_dir: 数据目录
            output_dir: 输出目录
            moneyflow_dir: 资金流数据目录
            log_dir: 日志目录
            ref_file: 参考因子文件路径
        """
        if data_dir is not None:
            self.data_dir = data_dir
        if output_dir is not None:
            self.output_dir = output_dir
        if moneyflow_dir is not None:
            self.moneyflow_dir = moneyflow_dir
        if log_dir is not None:
            self.log_dir = log_dir
        if ref_file is not None:
            self.ref_file = ref_file
    
    def __repr__(self):
        return (f"DuckDBPathConfig(\n"
                f"  data_dir={self.data_dir},\n"
                f"  output_dir={self.output_dir},\n"
                f"  moneyflow_dir={self.moneyflow_dir},\n"
                f"  log_dir={self.log_dir},\n"
                f"  ref_file={self.ref_file}\n"
                f")")


# 创建全局配置实例
_path_config = DuckDBPathConfig()


def get_data_dir() -> Path:
    """获取数据目录路径"""
    return _path_config.data_dir


def get_output_dir() -> Path:
    """获取输出目录路径"""
    return _path_config.output_dir


def get_moneyflow_dir() -> Path:
    """获取资金流数据目录路径"""
    return _path_config.moneyflow_dir


def get_log_dir() -> Path:
    """获取日志目录路径"""
    return _path_config.log_dir


def get_ref_file() -> Path:
    """获取参考因子文件路径"""
    return _path_config.ref_file


def configure_paths(
    data_dir: str or Path = None,
    output_dir: str or Path = None,
    moneyflow_dir: str or Path = None,
    log_dir: str or Path = None,
    ref_file: str or Path = None
):
    """
    配置DuckDB Factor Engine的路径
    
    Args:
        data_dir: 数据目录
        output_dir: 输出目录
        moneyflow_dir: 资金流数据目录
        log_dir: 日志目录
        ref_file: 参考因子文件路径
    
    使用示例：
        from duckdb_factor_engine import configure_paths
        
        # 方式1：使用函数配置
        configure_paths(
            data_dir='/path/to/data',
            output_dir='/path/to/output'
        )
        
        # 方式2：使用环境变量
        import os
        os.environ['DUCKDB_DATA_DIR'] = '/path/to/data'
        os.environ['DUCKDB_OUTPUT_DIR'] = '/path/to/output'
    """
    _path_config.set_paths(
        data_dir=data_dir,
        output_dir=output_dir,
        moneyflow_dir=moneyflow_dir,
        log_dir=log_dir,
        ref_file=ref_file
    )


# 导出
__all__ = [
    'DuckDBPathConfig',
    'get_data_dir',
    'get_output_dir',
    'get_moneyflow_dir',
    'get_log_dir',
    'get_ref_file',
    'configure_paths'
]
