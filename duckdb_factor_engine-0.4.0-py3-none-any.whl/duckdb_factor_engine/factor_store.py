# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 因子数据存储管理器 (FactorStore)

长表格式: ts_code, trade_date, factor_name, factor_value
存储后端: parquet 文件（单个或按年分片）

使用示例:
    >>> store = FactorStore('./output/factors_all.parquet')
    >>> latest = store.get_latest_date()
    >>> df = store.read(start_date='20240101', factor_names=['BP', 'TTM_EP'])
    >>> store.write(new_df, mode='append')
"""

import os
import logging
from pathlib import Path
from typing import Optional, Union

import pandas as pd
import duckdb

logger = logging.getLogger(__name__)


class DateGapError(Exception):
    """日期空洞异常：已有数据最新日期与请求起始日期之间存在交易日缺失"""
    pass


class OverlapError(Exception):
    """数据重叠异常：请求的起始日期与已有数据存在重叠"""
    pass


class FactorStore:
    """因子数据存储管理器"""

    def __init__(self, store_path: str):
        """
        Args:
            store_path: parquet 文件或目录路径。
                        - 单文件: './output/factors_all.parquet'
                        - 分年目录: './output/' (含 factors_2024.parquet, factors_2025.parquet 等)
        """
        self.store_path = Path(store_path)
        self._con = duckdb.connect(':memory:')
        self._con.execute("SET threads = 4")
        self._con.execute("SET memory_limit = '4GB'")

        # 检测存储模式
        if self.store_path.is_dir():
            self._mode = 'directory'
            self._file_pattern = str(self.store_path / 'factors_*.parquet')
        elif self.store_path.is_file() or self.store_path.suffix == '.parquet':
            self._mode = 'file'
            self._file_pattern = str(self.store_path)
        else:
            # 文件尚不存在
            self._mode = 'file'
            self._file_pattern = str(self.store_path)

        # 注册已有数据视图
        self._register_view()

    def _register_view(self):
        """将已有 parquet 文件注册为 DuckDB 视图 'factors_data'"""
        try:
            if self._mode == 'file':
                self._con.execute(
                    f"CREATE OR REPLACE VIEW factors_data AS "
                    f"SELECT * FROM read_parquet('{self._file_pattern}')"
                )
            else:
                self._con.execute(
                    f"CREATE OR REPLACE VIEW factors_data AS "
                    f"SELECT * FROM read_parquet('{self._file_pattern}')"
                )
        except Exception:
            # 文件不存在，创建空视图
            self._con.execute(
                "CREATE OR REPLACE VIEW factors_data AS "
                "SELECT CAST(NULL AS VARCHAR) AS ts_code, "
                "CAST(NULL AS VARCHAR) AS trade_date, "
                "CAST(NULL AS VARCHAR) AS factor_name, "
                "CAST(NULL AS DOUBLE) AS factor_value "
                "WHERE FALSE"
            )

    @property
    def has_data(self) -> bool:
        """是否存在已有数据"""
        try:
            cnt = self._con.execute("SELECT COUNT(*) FROM factors_data").fetchone()[0]
            return cnt > 0
        except Exception:
            return False

    def get_latest_date(self) -> Optional[str]:
        """返回数据中最新 trade_date，无数据返回 None"""
        if not self.has_data:
            return None
        result = self._con.execute(
            "SELECT MAX(trade_date) FROM factors_data"
        ).fetchone()[0]
        return result

    def get_earliest_date(self) -> Optional[str]:
        """返回数据中最早 trade_date"""
        if not self.has_data:
            return None
        result = self._con.execute(
            "SELECT MIN(trade_date) FROM factors_data"
        ).fetchone()[0]
        return result

    def get_all_factor_names(self) -> list:
        """返回已有数据中的所有因子名"""
        if not self.has_data:
            return []
        result = self._con.execute(
            "SELECT DISTINCT factor_name FROM factors_data ORDER BY factor_name"
        ).fetchdf()['factor_name'].tolist()
        return result

    def get_summary(self) -> pd.DataFrame:
        """每个因子的统计: 日期范围、行数、缺失率"""
        if not self.has_data:
            return pd.DataFrame()
        return self._con.execute("""
            SELECT
                factor_name,
                COUNT(*) AS n_rows,
                COUNT(DISTINCT trade_date) AS n_dates,
                COUNT(DISTINCT ts_code) AS n_stocks,
                MIN(trade_date) AS min_date,
                MAX(trade_date) AS max_date,
                SUM(CASE WHEN factor_value IS NULL THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS null_ratio
            FROM factors_data
            GROUP BY factor_name
            ORDER BY factor_name
        """).fetchdf()

    def get_trading_dates(self) -> list:
        """返回已有数据中的所有交易日（去重排序）"""
        if not self.has_data:
            return []
        result = self._con.execute(
            "SELECT DISTINCT trade_date FROM factors_data ORDER BY trade_date"
        ).fetchdf()['trade_date'].tolist()
        return result

    def read(self, start_date=None, end_date=None,
             factor_names=None, ts_codes=None) -> pd.DataFrame:
        """
        读取因子数据（长表格式）。

        Args:
            start_date: 起始日期 (YYYYMMDD)
            end_date: 截止日期 (YYYYMMDD)
            factor_names: 因子名列表（None=全部）
            ts_codes: 股票代码列表（None=全部）

        Returns:
            DataFrame: ts_code, trade_date, factor_name, factor_value
        """
        if not self.has_data:
            return pd.DataFrame(columns=['ts_code', 'trade_date', 'factor_name', 'factor_value'])

        where_clauses = []
        if start_date:
            where_clauses.append(f"trade_date >= '{start_date}'")
        if end_date:
            where_clauses.append(f"trade_date <= '{end_date}'")
        if factor_names:
            names_str = "', '".join(factor_names)
            where_clauses.append(f"factor_name IN ('{names_str}')")
        if ts_codes:
            codes_str = "', '".join(ts_codes)
            where_clauses.append(f"ts_code IN ('{codes_str}')")

        where = ' AND '.join(where_clauses) if where_clauses else 'TRUE'
        return self._con.execute(
            f"SELECT * FROM factors_data WHERE {where} ORDER BY factor_name, trade_date, ts_code"
        ).fetchdf()

    def read_wide(self, start_date=None, end_date=None,
                  factor_names=None, ts_codes=None) -> pd.DataFrame:
        """
        读取因子数据（宽表格式）。

        Returns:
            DataFrame: ts_code, trade_date, factor1, factor2, ...
        """
        df_long = self.read(start_date, end_date, factor_names, ts_codes)
        if df_long.empty:
            return pd.DataFrame(columns=['ts_code', 'trade_date'])

        return df_long.pivot_table(
            index=['ts_code', 'trade_date'],
            columns='factor_name',
            values='factor_value'
        ).reset_index()

    def write(self, df: pd.DataFrame, mode='append'):
        """
        写入因子数据。

        Args:
            df: 长表格式 DataFrame (ts_code, trade_date, factor_name, factor_value)
            mode: 'overwrite' 覆盖写入 / 'append' 追加写入（按 key 去重）
        """
        required_cols = {'ts_code', 'trade_date', 'factor_name', 'factor_value'}
        missing = required_cols - set(df.columns)
        if missing:
            raise ValueError(f"DataFrame 缺少必需列: {missing}")

        # 确保 trade_date 为字符串
        df = df.copy()
        df['trade_date'] = df['trade_date'].astype(str)
        df['ts_code'] = df['ts_code'].astype(str)

        if mode == 'overwrite':
            df.to_parquet(self._file_pattern, index=False)
        elif mode == 'append':
            if self.has_data:
                # DuckDB UNION + 去重
                self._con.execute("DROP TABLE IF EXISTS _new_data")
                self._con.execute("CREATE TABLE _new_data AS SELECT * FROM df")
                self._con.execute("""
                    CREATE OR REPLACE TABLE _merged AS
                    SELECT ts_code, trade_date, factor_name, factor_value FROM _new_data
                    UNION ALL
                    SELECT ts_code, trade_date, factor_name, factor_value FROM factors_data
                    QUALIFY ROW_NUMBER() OVER (
                        PARTITION BY ts_code, trade_date, factor_name
                        ORDER BY trade_date DESC
                    ) = 1
                """)
                merged = self._con.execute("SELECT * FROM _merged").fetchdf()
                merged.to_parquet(self._file_pattern, index=False)
                self._con.execute("DROP TABLE IF EXISTS _new_data")
                self._con.execute("DROP TABLE IF EXISTS _merged")
            else:
                df.to_parquet(self._file_pattern, index=False)

        # 重新注册视图
        self._register_view()
        logger.info(f"FactorStore: 写入 {len(df):,} 行 (mode={mode}) → {self._file_pattern}")

    def validate_no_gap(self, requested_start: str):
        """
        校验请求的起始日期与已有数据最新日期之间无交易日空洞。

        Args:
            requested_start: 请求的起始日期 (YYYYMMDD)

        Raises:
            DateGapError: 存在交易日空洞
            OverlapError: 请求日期与已有数据重叠
        """
        if not self.has_data:
            return  # 无已有数据，允许从任意日期开始

        latest = self.get_latest_date()
        if requested_start <= latest:
            raise OverlapError(
                f"请求起始日期 {requested_start} <= 已有最新日期 {latest}。"
                f"请使用更大的起始日期，或使用 'overwrite' 模式。"
            )

        # 检查 latest 和 requested_start 之间是否有交易日存在
        dates = self.get_trading_dates()
        gap_dates = [d for d in dates if latest < d < requested_start]
        if gap_dates:
            raise DateGapError(
                f"已有最新日期 {latest} 与请求起始日期 {requested_start} "
                f"之间存在 {len(gap_dates)} 个交易日空洞: "
                f"{gap_dates[0]} ~ {gap_dates[-1]}"
            )

    def close(self):
        """关闭 DuckDB 连接"""
        if self._con:
            self._con.close()
