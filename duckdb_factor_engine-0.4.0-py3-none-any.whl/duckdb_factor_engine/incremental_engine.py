# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 增量因子计算引擎 (IncrementalEngine)

在已有因子数据基础上增量计算新增日期的因子值。
支持 gap 检测、部分因子更新、NaN 自动填充。

使用示例:
    >>> ie = IncrementalEngine(data_dir='/data', store_path='./output/factors_all.parquet')
    >>> # 自动从最新日期+1开始
    >>> ie.run(end_date='20260601')
    >>> # 指定起始日期 + 部分因子
    >>> ie.run(start_date='20260401', end_date='20260601', factors=['BP', 'TTM_EP'])
"""

import os
import logging
from pathlib import Path
from datetime import datetime

import pandas as pd

from .factor_store import FactorStore, DateGapError, OverlapError

logger = logging.getLogger(__name__)


class IncrementalEngine:
    """增量因子计算引擎"""

    def __init__(self, data_dir: str, store_path: str):
        """
        Args:
            data_dir: 原始数据根目录
            store_path: 因子存储路径（parquet 文件或目录）
        """
        self.data_dir = Path(data_dir)
        self.store = FactorStore(store_path)
        self._batch_engine = None  # 延迟初始化

    def _get_batch_engine(self):
        """延迟初始化 BatchEngine（避免重复创建 DuckDB 连接）"""
        if self._batch_engine is None:
            from .batch_engine import FactorEngineV72
            self._batch_engine = FactorEngineV72(
                data_dir=str(self.data_dir),
                output_dir=str(Path(self.store.store_path).parent)
            )
        return self._batch_engine

    def latest_date(self) -> str:
        """返回已有数据最新日期"""
        return self.store.get_latest_date()

    def status(self) -> dict:
        """
        返回增量状态摘要。
        
        Returns:
            dict: {latest_date, n_factors, n_rows, n_stocks, ...}
        """
        if not self.store.has_data:
            return {'latest_date': None, 'n_factors': 0, 'n_rows': 0, 'n_stocks': 0}

        summary = self.store.get_summary()
        return {
            'latest_date': self.store.get_latest_date(),
            'earliest_date': self.store.get_earliest_date(),
            'n_factors': len(summary),
            'n_rows': summary['n_rows'].sum(),
            'n_stocks': summary['n_stocks'].max(),
            'factor_summary': summary.to_dict('records'),
        }

    def run(self, end_date: str = None, start_date: str = None,
            factors: list = None, parallel: bool = True) -> list:
        """
        增量计算入口。

        Args:
            end_date: 计算截止日期 (YYYYMMDD)。如果未提供 start_date，
                      则从已有数据最新日期的下一个交易日开始计算。
            start_date: 计算起始日期 (YYYYMMDD)。如果提供，将校验 gap。
            factors: 需要计算的因子列表（None=全部启用因子）。
                     如果仅计算部分因子，其他因子在增量日期段自动填充 NaN。
            parallel: 是否使用多进程并行

        Returns:
            list: 成功计算的因子名称列表

        Raises:
            DateGapError: 日期存在空洞
            OverlapError: 日期与已有数据重叠
            ValueError: 参数不合法
        """
        if end_date is None and start_date is None:
            raise ValueError("必须提供 end_date 或 start_date 中的至少一个")

        # 标准化日期格式
        if end_date:
            end_date = end_date.replace('-', '')
        if start_date:
            start_date = start_date.replace('-', '')

        # 确定实际计算区间
        if start_date is None:
            # 自动从最新日期+1开始
            latest = self.store.get_latest_date()
            if latest is None:
                raise ValueError(
                    "存储中无已有数据，无法自动确定起始日期。"
                    "请使用 start_date 参数指定起始日期。"
                )
            # 从 prices 表获取下一个交易日
            actual_start = self._next_trading_date(latest)
            if actual_start is None:
                raise ValueError(
                    f"无法确定 {latest} 之后的下一个交易日。请手动提供 start_date。"
                )
            logger.info(f"自动确定起始日期: 最新={latest}, 下一个交易日={actual_start}")
        else:
            # 校验 gap
            if self.store.has_data:
                try:
                    self.store.validate_no_gap(start_date)
                except OverlapError:
                    logger.warning(
                        f"请求起始日期 {start_date} 与已有数据重叠，将被覆盖。"
                    )
            actual_start = start_date

        logger.info(f"增量计算: {actual_start} ~ {end_date}")

        # 确定要计算的因子列表
        from .config import get_factor_names
        all_enabled = get_factor_names(enabled_only=True)
        existing_factors = self.store.get_all_factor_names()

        if factors is None:
            compute_factors = all_enabled
        else:
            compute_factors = [f for f in factors if f in all_enabled]
            unknown = set(factors) - set(all_enabled)
            if unknown:
                logger.warning(f"未知因子（跳过）: {unknown}")

        logger.info(f"计算 {len(compute_factors)} 个因子")

        # 调用 BatchEngine 计算因子
        engine = self._get_batch_engine()
        computed = engine.run(
            start_date=actual_start,
            end_date=end_date,
            factor_names=compute_factors,
            parallel=parallel,
        )

        # 如果仅计算部分因子，NaN 填充其他因子
        if existing_factors and set(compute_factors) != set(existing_factors):
            logger.info(f"填充 NaN: {len(existing_factors) - len(compute_factors)} 个未计算因子...")
            self._nan_fill_and_append(actual_start, end_date, compute_factors, existing_factors)
        elif computed:
            # 全部因子直接追加
            self._append_computed_factors(actual_start, end_date, computed)

        logger.info(f"增量计算完成: {len(computed)} 个因子")
        return computed

    def _next_trading_date(self, date: str) -> str:
        """
        获取 date 的下一个交易日。
        优先从 prices 视图查询，失败则从 store 中的日期列表推断。
        """
        try:
            engine = self._get_batch_engine()
            result = engine.con.execute(
                f"SELECT MIN(trade_date) FROM prices "
                f"WHERE trade_date > '{date}'"
            ).fetchone()[0]
            if result:
                return str(result)
        except Exception:
            pass
        return None

    def _append_computed_factors(self, start_date, end_date, computed_factors):
        """将计算好的因子 parquet 文件读取并追加到 store"""
        output_dir = Path(self.store.store_path).parent
        dfs = []
        for fname in computed_factors:
            fpath = output_dir / f'{fname}.parquet'
            if fpath.exists():
                df = pd.read_parquet(fpath)
                # 转为长表
                id_vars = ['ts_code', 'trade_date']
                value_cols = [c for c in df.columns if c not in id_vars]
                if value_cols:
                    col = value_cols[0]
                    df_long = pd.DataFrame({
                        'ts_code': df['ts_code'],
                        'trade_date': df['trade_date'].astype(str),
                        'factor_name': fname,
                        'factor_value': df[col],
                    }).dropna(subset=['factor_value'])
                    dfs.append(df_long)

        if dfs:
            all_data = pd.concat(dfs, ignore_index=True)
            self.store.write(all_data, mode='append')

    def _nan_fill_and_append(self, start_date, end_date, computed_factors, existing_factors):
        """
        为未计算的因子填充 NaN 并追加到 store。

        步骤:
        1. 读取已计算的因子数据
        2. 确定未计算因子列表
        3. 获取增量日期的股票 universe
        4. 为未计算因子 × 增量日期 × 股票 universe 生成 NaN 行
        5. 合并所有数据并追加写入
        """
        output_dir = Path(self.store.store_path).parent
        dfs = []

        # 读取已计算的因子
        for fname in computed_factors:
            fpath = output_dir / f'{fname}.parquet'
            if fpath.exists():
                df = pd.read_parquet(fpath)
                id_vars = ['ts_code', 'trade_date']
                value_cols = [c for c in df.columns if c not in id_vars]
                if value_cols:
                    col = value_cols[0]
                    df_long = pd.DataFrame({
                        'ts_code': df['ts_code'],
                        'trade_date': df['trade_date'].astype(str),
                        'factor_name': fname,
                        'factor_value': df[col],
                    }).dropna(subset=['factor_value'])
                    dfs.append(df_long)

        if not dfs:
            logger.warning("无已计算因子数据")
            return

        # 从已计算数据中提取股票 universe 和日期
        computed_all = pd.concat(dfs, ignore_index=True)
        universe = computed_all['ts_code'].unique()
        dates = computed_all['trade_date'].unique()

        # 确定未计算因子
        other_factors = [f for f in existing_factors if f not in computed_factors]

        if other_factors:
            logger.info(f"  为 {len(other_factors)} 个因子填充 NaN...")
            # 构建 NaN 行
            nan_rows = []
            for date in dates:
                for ts in universe:
                    for fn in other_factors:
                        nan_rows.append({
                            'ts_code': ts,
                            'trade_date': date,
                            'factor_name': fn,
                            'factor_value': None,
                        })

            nan_df = pd.DataFrame(nan_rows)
            all_data = pd.concat([computed_all, nan_df], ignore_index=True)
        else:
            all_data = computed_all

        self.store.write(all_data, mode='append')

    def close(self):
        """清理资源"""
        if self._batch_engine:
            self._batch_engine.close()
        if self.store:
            self.store.close()
