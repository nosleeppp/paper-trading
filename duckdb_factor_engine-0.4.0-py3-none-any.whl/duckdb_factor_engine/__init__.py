# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 可配置的 DuckDB 因子计算引擎 v0.4.0

提供三种计算模式：
  - BatchEngine:   批量因子计算（文件输出 / 内存返回，支持多进程并行）
  - IncrementalEngine: 增量因子计算（gap 检测 + NaN 填充）
  - OnlineEngine:  在线因子计算（回测实时集成，单日期内存返回）

使用示例:
    >>> from duckdb_factor_engine import BatchEngine
    >>> engine = BatchEngine(data_dir='./data', output_dir='./output')
    >>> # 文件输出模式
    >>> results = engine.run('2025-01-01', '2025-12-31')
    >>> # 内存返回模式
    >>> df = engine.compute('2025-01-01', '2025-01-31', factors=['BP', 'TTM_EP'])
    >>> engine.close()

    >>> from duckdb_factor_engine import IncrementalEngine
    >>> ie = IncrementalEngine(data_dir='./data', store_path='./output/factors_all.parquet')
    >>> ie.run(end_date='2026-06-01', factors=['BP', 'TTM_EP'])

    >>> from duckdb_factor_engine import OnlineEngine
    >>> oe = OnlineEngine(data_dir='./data', factors=['BP', 'TTM_EP'])
    >>> df = oe.compute('2026-06-01')
    >>> oe.close()

Attributes:
    __version__ (str): 包版本号
"""

__version__ = '0.4.0'
__author__ = 'Li Baiwan'
__email__ = 'quant@example.com'

# ── 因子配置 ──────────────────────────────────────────────────────
from .config import (
    FACTORS_CONFIG,
    get_factor_names,
    get_factor_config,
    get_factors_by_category,
    get_all_categories,
    add_factor,
    remove_factor,
    enable_factor,
    list_factors,
    CATEGORY_VALUATION,
    CATEGORY_MOMENTUM,
    CATEGORY_LIQUIDITY,
    CATEGORY_VOLATILITY,
    CATEGORY_MONEYFLOW,
    CATEGORY_FINANCIAL,
    CATEGORY_TECHNICAL,
)

# ── 批量引擎（原 FactorEngineV72 重构） ────────────────────────────
from .batch_engine import BatchEngine, FactorEngineV72

# ── 增量引擎 ──────────────────────────────────────────────────────
from .incremental_engine import IncrementalEngine

# ── 在线引擎（回测集成） ──────────────────────────────────────────
from .online_engine import OnlineEngine

# ── 数据存储层 ────────────────────────────────────────────────────
from .factor_store import FactorStore

# ── 因子处理函数 ──────────────────────────────────────────────────
from .factor_processor import (
    fill_na,
    winsorize,
    normalize,
    process_factor,
)

# ── 视图注册 ──────────────────────────────────────────────────────
from .views import register_all_views

# ── 并行引擎（保留兼容） ──────────────────────────────────────────
from .parallel_engine import ParallelFactorEngine

# 向后兼容别名
FactorEngine = BatchEngine

# Define public API
__all__ = [
    # Version info
    '__version__',
    '__author__',
    '__email__',

    # Engines
    'BatchEngine',
    'FactorEngine',       # 向后兼容
    'FactorEngineV72',    # 向后兼容
    'IncrementalEngine',
    'OnlineEngine',

    # Data
    'FactorStore',

    # Configuration
    'FACTORS_CONFIG',
    'get_factor_names',
    'get_factor_config',
    'get_factors_by_category',
    'get_all_categories',
    'add_factor',
    'remove_factor',
    'enable_factor',
    'list_factors',

    # Category constants
    'CATEGORY_VALUATION',
    'CATEGORY_MOMENTUM',
    'CATEGORY_LIQUIDITY',
    'CATEGORY_VOLATILITY',
    'CATEGORY_MONEYFLOW',
    'CATEGORY_FINANCIAL',
    'CATEGORY_TECHNICAL',

    # Factor processor functions
    'fill_na',
    'winsorize',
    'normalize',
    'process_factor',

    # Views
    'register_all_views',

    # Parallel engine
    'ParallelFactorEngine',
]
