# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 因子配置聚合入口

本文件从 factors/ 子包中导入所有因子定义并聚合为 FACTORS_CONFIG。
保留所有辅助函数不变，保持向后兼容。

因子类别常量：
  CATEGORY_VALUATION  — 估值因子
  CATEGORY_MOMENTUM   — 动量因子
  CATEGORY_LIQUIDITY  — 流动性因子
  CATEGORY_VOLATILITY — 波动性因子
  CATEGORY_MONEYFLOW  — 资金流因子
  CATEGORY_FINANCIAL  — 财务因子
  CATEGORY_TECHNICAL  — 技术指标因子
"""

# ── 因子类别常量 ──────────────────────────────────────────────────
CATEGORY_VALUATION = 'valuation'
CATEGORY_MOMENTUM = 'momentum'
CATEGORY_LIQUIDITY = 'liquidity'
CATEGORY_VOLATILITY = 'volatility'
CATEGORY_MONEYFLOW = 'moneyflow'
CATEGORY_FINANCIAL = 'financial'
CATEGORY_TECHNICAL = 'technical'

# ── 从子包中导入并聚合所有因子 ────────────────────────────────────
from .factors import ALL_FACTOR_LISTS

FACTORS_CONFIG = []
for factor_list in ALL_FACTOR_LISTS:
    FACTORS_CONFIG.extend(factor_list)


# ── 辅助函数 ──────────────────────────────────────────────────────

def get_factor_names(enabled_only=True):
    """获取因子名称列表"""
    if enabled_only:
        return [f['name'] for f in FACTORS_CONFIG if f.get('enabled', True)]
    return [f['name'] for f in FACTORS_CONFIG]


def get_factor_config(name):
    """获取单个因子配置"""
    for factor in FACTORS_CONFIG:
        if factor['name'] == name:
            return factor
    return None


def get_factors_by_category(category):
    """按类别获取因子名称列表"""
    return [f['name'] for f in FACTORS_CONFIG if f['category'] == category]


def get_all_categories():
    """获取所有类别"""
    return list(set(f['category'] for f in FACTORS_CONFIG))


def add_factor(name, category, description, sql_template, enabled=True):
    """
    添加新因子到配置列表

    参数:
        name: 因子名称
        category: 因子类别 (使用 CATEGORY_* 常量)
        description: 因子描述
        sql_template: SQL计算模板（使用 {start_dt} 和 {end_dt} 占位符）
        enabled: 是否启用（默认True）

    返回:
        True: 添加成功
        False: 因子已存在
    """
    if get_factor_config(name) is not None:
        return False

    FACTORS_CONFIG.append({
        'name': name,
        'category': category,
        'description': description,
        'sql_template': sql_template,
        'enabled': enabled
    })
    return True


def remove_factor(name):
    """
    从配置列表中移除因子

    参数:
        name: 因子名称

    返回:
        True: 移除成功
        False: 因子不存在
    """
    global FACTORS_CONFIG
    for i, factor in enumerate(FACTORS_CONFIG):
        if factor['name'] == name:
            FACTORS_CONFIG.pop(i)
            return True
    return False


def enable_factor(name, enabled=True):
    """
    启用或禁用因子

    参数:
        name: 因子名称
        enabled: True启用, False禁用

    返回:
        True: 操作成功
        False: 因子不存在
    """
    factor = get_factor_config(name)
    if factor is None:
        return False
    factor['enabled'] = enabled
    return True


def list_factors(enabled_only=False, category=None):
    """
    列出所有因子

    参数:
        enabled_only: 是否只列出启用的因子
        category: 按类别筛选（None表示所有类别）

    返回:
        因子信息列表
    """
    factors = FACTORS_CONFIG
    if enabled_only:
        factors = [f for f in factors if f.get('enabled', True)]
    if category:
        factors = [f for f in factors if f['category'] == category]
    return [{'name': f['name'], 'category': f['category'],
             'description': f['description'], 'enabled': f.get('enabled', True)}
            for f in factors]
