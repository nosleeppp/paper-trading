# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine - Utility Scripts

包含数据获取、因子修复等一次性使用脚本。
不属于包API，仅供独立运行。

用法示例：
    python -m duckdb_factor_engine.utils.fetch_daily_basic --year 2024
    python -m duckdb_factor_engine.utils.fetch_financial --table income
"""

# ────────────────────────────────────────────────────────────
# fetch_daily_basic.py
# ────────────────────────────────────────────────────────────
#!/usr/bin/env python3
"""
后台获取 daily_basic 数据（2016-2026）
"""
import sys
import pandas as pd
import os
import time
import glob
from datetime import datetime
from sqlalchemy import text, create_engine
import logging

# ── 配置管理 ────────────────────────────────────────────────────────────────
from .path_config import get_data_dir, get_log_dir

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(str(get_log_dir() / 'daily_basic_fetch.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def get_mysql_engine():
    """创建MySQL连接引擎"""
    host = '101.36.228.189'
    port = 3306
    user = 'quant_ro'
    password = 'B4$mL8nW3#zR7vT2yX!P6'
    database = 'stock_db'
    
    engine = create_engine(f'mysql+pymysql://{user}:{password}@{host}:{port}/{database}')
    return engine

def get_year_data(year, output_dir):
    """获取指定年份的数据"""
    logger.info(f"开始获取 {year} 年数据...")
    
    engine = get_mysql_engine()
    
    # 查询该年份数据量
    start_date = f"{year}0101"
    end_date = f"{year}1231"
    
    with engine.connect() as conn:
        query = text(f"SELECT COUNT(*) FROM daily_basic WHERE trade_date BETWEEN '{start_date}' AND '{end_date}'")
        result = conn.execute(query)
        total_count = result.fetchone()[0]
    
    if total_count == 0:
        logger.info(f"{year} 年无数据")
        return 0
    
    logger.info(f"{year} 年数据行数: {total_count:,}")
    
    # 分批获取
    batch_size = 200000  # 每批20万行
    offset = 0
    total_fetched = 0
    batch_num = 1
    start_time = time.time()
    
    batch_files = []
    
    while True:
        logger.info(f"{year}年 - 批次 {batch_num}: offset={offset:,}")
        
        query = text(f"""
            SELECT * FROM daily_basic 
            WHERE trade_date BETWEEN '{start_date}' AND '{end_date}'
            ORDER BY trade_date, ts_code
            LIMIT {batch_size} OFFSET {offset}
        """)
        
        with engine.connect() as conn:
            df_batch = pd.read_sql(query, conn)
        
        if df_batch.empty:
            logger.info(f"{year}年 - 数据获取完成")
            break
        
        rows_in_batch = len(df_batch)
        total_fetched += rows_in_batch
        
        # 保存批次
        batch_file = f"{output_dir}/daily_basic_{year}_batch{batch_num:03d}.parquet"
        df_batch.to_parquet(batch_file)
        batch_files.append(batch_file)
        
        # 进度
        elapsed = time.time() - start_time
        progress = total_fetched / total_count * 100
        
        logger.info(f"{year}年 - 批次 {batch_num}: {rows_in_batch:,} 行 (总计: {total_fetched:,}/{total_count:,}, {progress:.1f}%), 耗时: {elapsed:.1f}秒")
        
        offset += batch_size
        batch_num += 1
        
        # 安全限制
        if batch_num > 50:
            logger.warning(f"{year}年 - 达到批次安全限制")
            break
    
    # 合并批次文件
    if batch_files:
        logger.info(f"{year}年 - 合并 {len(batch_files)} 个批次文件...")
        
        dfs = []
        for batch_file in batch_files:
            dfs.append(pd.read_parquet(batch_file))
        
        combined_df = pd.concat(dfs, ignore_index=True)
        combined_file = f"{output_dir}/daily_basic_{year}.parquet"
        combined_df.to_parquet(combined_file)
        
        # 清理批次文件
        for batch_file in batch_files:
            os.remove(batch_file)
        
        elapsed_total = time.time() - start_time
        logger.info(f"{year}年 - 合并完成: {combined_file} ({len(combined_df):,} 行), 总耗时: {elapsed_total:.1f}秒")
        
        # 验证
        logger.info(f"{year}年 - 日期范围: {combined_df.trade_date.min()} ~ {combined_df.trade_date.max()}")
        logger.info(f"{year}年 - 股票数: {combined_df.ts_code.nunique():,}")
        logger.info(f"{year}年 - 交易日数: {combined_df.trade_date.nunique():,}")
    
    return total_fetched

def main():
    """主函数"""
    logger.info("="*60)
    logger.info("开始后台获取 daily_basic 数据 (2016-2026)")
    logger.info("="*60)
    
    # 输出目录
    output_dir = str(get_data_dir() / 'daily_basic')
    os.makedirs(output_dir, exist_ok=True)
    
    # 要获取的年份
    years = list(range(2016, 2027))  # 2016-2026
    
    total_rows = 0
    start_time = time.time()
    
    for year in years:
        year_start = time.time()
        rows = get_year_data(year, output_dir)
        total_rows += rows
        
        year_elapsed = time.time() - year_start
        logger.info(f"{year}年 - 获取完成: {rows:,} 行, 耗时: {year_elapsed:.1f}秒")
        logger.info("-"*40)
    
    total_elapsed = time.time() - start_time
    logger.info("="*60)
    logger.info(f"全部完成! 总计: {total_rows:,} 行, 总耗时: {total_elapsed:.1f}秒")
    logger.info(f"平均速度: {total_rows/total_elapsed if total_elapsed>0 else 0:.1f} 行/秒")
    logger.info("="*60)
    
    # 创建完成标记
    with open(f"{output_dir}/FETCH_COMPLETE.txt", "w") as f:
        f.write(f"完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"总行数: {total_rows:,}\n")
        f.write(f"总耗时: {total_elapsed:.1f}秒\n")
    
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        logger.error(f"主程序错误: {e}", exc_info=True)
        sys.exit(1)


# ────────────────────────────────────────────────────────────
# fetch_financial.py
# ────────────────────────────────────────────────────────────
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
拉取三张财务表到本地 parquet
"""
import pymysql
import pandas as pd
from pathlib import Path
import logging

# ── 配置管理 ────────────────────────────────────────────────────────────────
from .path_config import get_data_dir, get_log_dir
import signal
import time

signal.signal(signal.SIGTERM, signal.SIG_IGN)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(str(get_log_dir() / 'fetch_financial.log'), mode='w')
    ]
)
logger = logging.getLogger(__name__)

MYSQL_CONFIG = {
    'host': '101.36.228.189',
    'port': 3306,
    'user': 'quant_ro',
    'password': 'B4$mL8nW3#zR7vT2yX!P6',
    'database': 'stock_db',
    'charset': 'utf8mb4',
    'connect_timeout': 30,
    'read_timeout': 600,
    'autocommit': True,
}

BASE_DIR = get_data_dir()


def fetch_full_table(table_name: str, save_dir: Path, chunk_size=200000):
    """高效分块拉取大表"""
    save_dir.mkdir(parents=True, exist_ok=True)
    conn = pymysql.connect(**MYSQL_CONFIG)

    sql = f"SELECT * FROM {table_name} ORDER BY ts_code, end_date, ann_date"
    logger.info(f"开始拉取 {table_name}，分块 {chunk_size:,}...")

    chunks = []
    offset = 0
    total = 0
    t0 = time.time()

    while True:
        query = f"{sql} LIMIT {chunk_size} OFFSET {offset}"
        df_chunk = pd.read_sql(query, conn)
        if df_chunk.empty:
            break
        chunks.append(df_chunk)
        offset += chunk_size
        total += len(df_chunk)
        elapsed = time.time() - t0
        logger.info(f"  {table_name}: 已读取 {total:,} 行，耗时 {elapsed:.1f}s")
        if total >= 10_000_000:  # 安全上限
            break

    conn.close()

    df = pd.concat(chunks, ignore_index=True)
    out_path = save_dir / f'{table_name}.parquet'
    df.to_parquet(out_path, index=False)
    size_mb = out_path.stat().st_size / 1024 / 1024
    logger.info(f"✅ {table_name}: {len(df):,} 行 → {out_path} ({size_mb:.1f} MB)")
    logger.info(f"  列: {df.columns.tolist()}")
    logger.info(f"  日期范围: {df['end_date'].min()} ~ {df['end_date'].max()}")
    return df


def main():
    # 1. income_vip（完整利润表，含季度+年度）
    fetch_full_table('income_vip', BASE_DIR / 'income')

    # 2. fina_indicator（财务指标，有预计算的 ROE/ROA/YOY）
    fetch_full_table('fina_indicator', BASE_DIR / 'fina_indicator')

    # 3. fina_balancesheet_vip（资产负债表）
    fetch_full_table('fina_balancesheet_vip', BASE_DIR / 'fina_balancesheet')

    logger.info("全部财务数据拉取完成 ✅")


if __name__ == '__main__':
    main()


# ────────────────────────────────────────────────────────────
# fetch_stk_factor_pro.py
# ────────────────────────────────────────────────────────────
#!/usr/bin/env python3
"""
后台获取 stk_factor_pro 技术指标数据（2017-2026）
来源：MySQL stock_db.stk_factor_pro（远程）
备选：Tushare pro Api（待实现）
"""
import sys
import pandas as pd
import os
import time
import glob
from datetime import datetime
from sqlalchemy import text, create_engine
import logging

# ── 配置管理 ────────────────────────────────────────────────────────────────
from .path_config import get_data_dir, get_log_dir

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(str(get_log_dir() / 'stk_factor_pro_fetch.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ── MySQL 配置 ──────────────────────────────────────────────────────────────
MYSQL_HOST = '101.36.228.189'
MYSQL_PORT = 3306
MYSQL_USER = 'quant_ro'
MYSQL_PASSWORD = 'B4$mL8nW3#zR7vT2yX!P6'
MYSQL_DATABASE = 'stock_db'

# ── 要获取的36个技术指标列 ────────────────────────────────────────────────────
# 与 factors_all.parquet 中的列名完全一致
TECH_COLUMNS = [
    # MA 系列
    'ma_bfq_5', 'ma_bfq_10', 'ma_bfq_20', 'ma_bfq_30', 'ma_bfq_60', 'ma_bfq_90', 'ma_bfq_250',
    # EMA 系列
    'ema_bfq_5', 'ema_bfq_10', 'ema_bfq_20', 'ema_bfq_30', 'ema_bfq_60', 'ema_bfq_90', 'ema_bfq_250',
    # RSI 系列
    'rsi_bfq_6', 'rsi_bfq_12', 'rsi_bfq_24',
    # KDJ 系列
    'kdj_bfq', 'kdj_k_bfq', 'kdj_d_bfq',
    # MACD 系列
    'macd_bfq', 'macd_dif_bfq', 'macd_dea_bfq',
    # BOLL
    'boll_upper_bfq', 'boll_mid_bfq', 'boll_lower_bfq',
    # 其他
    'cci_bfq', 'atr_bfq', 'mtm_bfq', 'mtmma_bfq', 'roc_bfq', 'vr_bfq', 'obv_bfq',
    'volume_ratio', 'turnover_rate', 'turnover_rate_f',
]

SELECT_COLUMNS = ['ts_code', 'trade_date'] + TECH_COLUMNS


def get_mysql_engine():
    """创建MySQL连接引擎"""
    engine = create_engine(
        f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE}'
    )
    return engine


def get_year_data(year, output_dir):
    """获取指定年份的数据（keyset pagination 优化）"""
    logger.info(f"开始获取 {year} 年数据...")

    engine = get_mysql_engine()
    start_date = f"{year}0101"
    end_date = f"{year}1231"

    # 先查询该年份总行数
    with engine.connect() as conn:
        query = text(f"""
            SELECT COUNT(*) FROM stk_factor_pro
            WHERE trade_date BETWEEN '{start_date}' AND '{end_date}'
        """)
        total_count = conn.execute(query).fetchone()[0]

    if total_count == 0:
        logger.info(f"{year} 年无数据")
        return 0

    logger.info(f"{year} 年数据行数: {total_count:,}")

    # Keyset pagination（避免 OFFSET 慢）
    batch_size = 200000
    last_date = start_date
    last_ts = ''
    total_fetched = 0
    batch_num = 1
    start_time = time.time()
    batch_files = []

    while True:
        query = text(f"""
            SELECT {', '.join(SELECT_COLUMNS)}
            FROM stk_factor_pro
            WHERE (trade_date > '{last_date}')
               OR (trade_date = '{last_date}' AND ts_code > '{last_ts}')
            ORDER BY trade_date, ts_code
            LIMIT {batch_size}
        """)

        with engine.connect() as conn:
            df_batch = pd.read_sql(query, conn)

        if df_batch.empty:
            break

        rows_in_batch = len(df_batch)
        total_fetched += rows_in_batch

        # 更新游标
        last_date = str(df_batch['trade_date'].iloc[-1])
        last_ts = str(df_batch['ts_code'].iloc[-1])

        # 保存批次
        batch_file = f"{output_dir}/stk_factor_pro_{year}_batch{batch_num:03d}.parquet"
        df_batch.to_parquet(batch_file)
        batch_files.append(batch_file)

        elapsed = time.time() - start_time
        progress = total_fetched / total_count * 100
        speed = total_fetched / elapsed if elapsed > 0 else 0
        logger.info(
            f"{year}年 - 批次{batch_num}: {rows_in_batch:,}行 "
            f"(总计:{total_fetched:,}/{total_count:,}, {progress:.1f}%) "
            f"速度:{speed:.0f}行/s 耗时:{elapsed:.1f}秒"
        )

        batch_num += 1

        if total_fetched >= total_count:
            break
        if batch_num > 100:
            logger.warning(f"{year}年 - 达到批次安全限制")
            break

    engine.dispose()

    # 合并批次文件
    if batch_files:
        logger.info(f"{year}年 - 合并 {len(batch_files)} 个批次文件...")
        dfs = [pd.read_parquet(f) for f in batch_files]
        combined_df = pd.concat(dfs, ignore_index=True)
        combined_file = f"{output_dir}/stk_factor_pro_{year}.parquet"
        combined_df.to_parquet(combined_file)

        # 清理批次文件
        for f in batch_files:
            os.remove(f)

        elapsed_total = time.time() - start_time
        logger.info(
            f"{year}年 - 合并完成: {combined_file} "
            f"({len(combined_df):,}行, {combined_df.ts_code.nunique():,}股, "
            f"{combined_df.trade_date.nunique():,}交易日) "
            f"总耗时:{elapsed_total:.1f}秒"
        )

    return total_fetched


def main():
    """主函数"""
    logger.info("=" * 60)
    logger.info("开始后台获取 stk_factor_pro 技术指标数据 (2017-2026)")
    logger.info("=" * 60)

    output_dir = str(get_data_dir() / 'stk_factor_pro')
    os.makedirs(output_dir, exist_ok=True)
    logger.info(f"输出目录: {output_dir}")

    years = list(range(2017, 2027))

    total_rows = 0
    start_time = time.time()

    for year in years:
        rows = get_year_data(year, output_dir)
        total_rows += rows
        logger.info("-" * 40)

    total_elapsed = time.time() - start_time
    logger.info("=" * 60)
    logger.info(f"全部完成! 总计: {total_rows:,} 行, 总耗时: {total_elapsed:.1f}秒")
    logger.info(f"平均速度: {total_rows/total_elapsed:.0f} 行/秒")
    logger.info("=" * 60)

    with open(f"{output_dir}/FETCH_COMPLETE.txt", "w") as f:
        f.write(f"完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"总行数: {total_rows:,}\n")
        f.write(f"总耗时: {total_elapsed:.1f}秒\n")

    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        logger.error(f"主程序错误: {e}", exc_info=True)
        sys.exit(1)


# ────────────────────────────────────────────────────────────
# fix_remaining.py
# ────────────────────────────────────────────────────────────
import re

with open('config.py', 'r') as f:
    content = f.read()

print("修复剩余窗口因子...")

# 需要修复的因子（需要扩展窗口 + 外层WHERE）
window_factors = {
    'TURNOVER_1M': {'window': 800000, 'rows': 20},
    'TURNOVER_3M': {'window': 800000, 'rows': 60},
    'ATR_1M': {'window': 800000, 'rows': 20},
    'ATR_3M': {'window': 800000, 'rows': 60},
    'MAIN_FORCE_5D': {'window': 800000, 'rows': 5},
    'MAIN_FORCE_20D': {'window': 800000, 'rows': 20},
    'TTM_EP_PCT_1Y': {'window': 800000, 'type': 'percentile'},
}

fixed = []

for factor_name, config in window_factors.items():
    # 找到该因子的SQL
    pattern = f"'name': '{factor_name}'.*?('sql_template': \"\"\"(.*?)\"\"\")"
    match = re.search(pattern, content, re.DOTALL)
    
    if not match:
        print(f"❌ {factor_name}: 未找到")
        continue
    
    sql = match.group(2)
    
    # 检查是否已有正确的外层WHERE
    if "WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'" in sql:
        # 检查内层是否也是目标范围（错误）
        if "WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'" in sql.split('FROM')[0]:
            # 内层错误，需要改回扩展窗口
            old_inner = "WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'"
            new_inner = f"WHERE trade_date >= (CAST('{{start_dt}}' AS INTEGER) - {config['window']})::VARCHAR AND trade_date <= '{{end_dt}}'"
            new_sql = sql.replace(old_inner, new_inner, 1)  # 只替换第一个（内层）
            content = content.replace(sql, new_sql)
            fixed.append(factor_name)
            print(f"✅ {factor_name}: 修复内层扩展窗口")
        else:
            print(f"✅ {factor_name}: 已有正确结构")
    else:
        # 需要添加外层WHERE
        # 在SQL结尾添加
        if sql.strip().endswith('"""'):
            # 在最后一个"""之前添加WHERE
            new_sql = sql.rstrip()[:-3]
            new_sql += f"\nWHERE trade_date >= '{{start_dt}}' AND trade_date <= '{{end_dt}}'\n        \"\"\""
            content = content.replace(sql, new_sql)
            fixed.append(factor_name)
            print(f"✅ {factor_name}: 添加外层WHERE")

# 简单因子：改为目标日期范围（不需要扩展窗口）
simple_factors = [
    'TTM_EP', 'TTM_SP', 'BP', 'DIVIDEND_RATE', 'PEG',
    'ROE_QUARTER', 'ROA_QUARTER', 'DELTA_ROE', 'DELTA_ROA',
    'EP_QUARTER', 'SP_QUARTER',
    'YOY_QUARTER_NP', 'YOY_QUARTER_OR', 'YOY_QUARTER_OP'
]

print("\n修复简单因子...")
for factor_name in simple_factors:
    pattern = f"'name': '{factor_name}'.*?('sql_template': \"\"\"(.*?)\"\"\")"
    match = re.search(pattern, content, re.DOTALL)
    
    if not match:
        continue
    
    sql = match.group(2)
    
    # 替换为简单WHERE
    old_pattern = "WHERE trade_date >= (CAST('{start_dt}' AS INTEGER) - 800000)::VARCHAR AND trade_date <= '{end_dt}'"
    new_pattern = "WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'"
    
    if old_pattern in sql:
        new_sql = sql.replace(old_pattern, new_pattern)
        content = content.replace(sql, new_sql)
        fixed.append(factor_name)
        print(f"✅ {factor_name}: 改内层WHERE")

# 保存
with open('config.py', 'w') as f:
    f.write(content)

print(f"\n共修复 {len(fixed)} 个因子")


# ────────────────────────────────────────────────────────────
# precompute.py
# ────────────────────────────────────────────────────────────
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
财务因子预计算模块
预计算季度财务因子，避免每日实时复杂JOIN

预计算内容：
- DELTA_ROA, DELTA_ROE (同比变化)
- YOY_QUARTER_NP, YOY_QUARTER_OR, YOY_QUARTER_OP (同比增长)
- ROE_QUARTER, ROA_QUARTER (季度指标)
- EP_QUARTER, SP_QUARTER (估值比率)

输出: fina_factors_precomputed.parquet
结构: ts_code, end_date, trade_date, factor1, factor2, ...
"""

import duckdb
import pandas as pd
from pathlib import Path

# ── 配置管理 ────────────────────────────────────────────────────────────────
from .path_config import get_data_dir, get_output_dir
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = get_data_dir()
OUTPUT_PATH = get_data_dir() / 'fina_factors_precomputed.parquet'


def precompute_financial_factors():
    """预计算所有财务相关因子"""
    
    con = duckdb.connect()
    
    # 注册视图
    views = {
        'v_income': DATA_DIR / 'income',
        'v_fina_indicator': DATA_DIR / 'fina_indicator',
        'v_balance': DATA_DIR / 'fina_balancesheet',
        'v_daily_basic': DATA_DIR / 'daily_basic',
    }
    
    for name, path in views.items():
        if path.exists():
            pattern = str(path / '*.parquet')
            con.execute(f"CREATE OR REPLACE VIEW {name} AS SELECT * FROM read_parquet('{pattern}')")
            logger.info(f"注册 {name}")
    
    logger.info("开始预计算财务因子...")
    
    sql = """
    WITH 
    -- 获取所有财报日期
    fina_dates AS (
        SELECT DISTINCT ts_code, end_date, ann_date
        FROM v_fina_indicator
        WHERE ann_date IS NOT NULL
    ),
    
    -- 当前期财务指标
    current_fina AS (
        SELECT 
            fd.ts_code,
            fd.end_date,
            fd.ann_date,
            fi.roa,
            fi.roe_yoy,
            fi.q_roe,
            -- fi.q_roa  -- 列不存在，使用roa代替
        FROM fina_dates fd
        LEFT JOIN v_fina_indicator fi 
            ON fd.ts_code = fi.ts_code 
            AND fd.end_date = fi.end_date
            AND fd.ann_date = fi.ann_date
    ),
    
    -- 去年同期财务指标 (end_date - 10000)
    last_year_fina AS (
        SELECT 
            cf.ts_code,
            cf.end_date,
            fi2.roa AS roa_ly
        FROM current_fina cf
        LEFT JOIN v_fina_indicator fi2
            ON cf.ts_code = fi2.ts_code
            AND CAST(fi2.end_date AS INTEGER) = CAST(cf.end_date AS INTEGER) - 10000
    ),
    
    -- 当前期利润表
    current_income AS (
        SELECT 
            fd.ts_code,
            fd.end_date,
            fd.ann_date,
            i.n_income_attr_p,
            i.revenue,
            i.operate_profit
        FROM fina_dates fd
        LEFT JOIN v_income i
            ON fd.ts_code = i.ts_code
            AND fd.end_date = i.end_date
            AND fd.ann_date = i.ann_date
    ),
    
    -- 去年同期利润表
    last_year_income AS (
        SELECT 
            ci.ts_code,
            ci.end_date,
            i2.n_income_attr_p AS n_income_attr_p_ly,
            i2.revenue AS revenue_ly,
            i2.operate_profit AS operate_profit_ly
        FROM current_income ci
        LEFT JOIN v_income i2
            ON ci.ts_code = i2.ts_code
            AND CAST(i2.end_date AS INTEGER) = CAST(ci.end_date AS INTEGER) - 10000
    ),
    
    -- 合并所有数据并计算因子
    combined AS (
        SELECT 
            cf.ts_code,
            cf.end_date,
            cf.ann_date,
            cf.ann_date AS trade_date,  -- 财报公布日作为生效日
            
            -- 原始指标
            CAST(cf.roa AS DOUBLE) AS roa,
            CAST(lyf.roa_ly AS DOUBLE) AS roa_ly,
            CAST(cf.roe_yoy AS DOUBLE) AS roe_yoy,
            CAST(cf.q_roe AS DOUBLE) AS q_roe,
            CAST(ci.n_income_attr_p AS DOUBLE) AS n_income_attr_p,
            CAST(lyi.n_income_attr_p_ly AS DOUBLE) AS n_income_attr_p_ly,
            CAST(ci.revenue AS DOUBLE) AS revenue,
            CAST(lyi.revenue_ly AS DOUBLE) AS revenue_ly,
            CAST(ci.operate_profit AS DOUBLE) AS operate_profit,
            CAST(lyi.operate_profit_ly AS DOUBLE) AS operate_profit_ly,
            
            -- 预计算财务因子
            CAST(cf.roe_yoy AS DOUBLE) AS DELTA_ROE,
            
            CASE WHEN CAST(cf.roa AS DOUBLE) IS NOT NULL AND CAST(lyf.roa_ly AS DOUBLE) IS NOT NULL AND CAST(lyf.roa_ly AS DOUBLE) != 0
                 THEN (CAST(cf.roa AS DOUBLE) / CAST(lyf.roa_ly AS DOUBLE) - 1) * 100
                 ELSE NULL END AS DELTA_ROA,
            
            CASE WHEN CAST(lyi.n_income_attr_p_ly AS DOUBLE) IS NOT NULL AND ABS(CAST(lyi.n_income_attr_p_ly AS DOUBLE)) > 0
                 THEN (CAST(ci.n_income_attr_p AS DOUBLE) - CAST(lyi.n_income_attr_p_ly AS DOUBLE)) / ABS(CAST(lyi.n_income_attr_p_ly AS DOUBLE)) * 100
                 ELSE NULL END AS YOY_QUARTER_NP,
            
            CASE WHEN CAST(lyi.revenue_ly AS DOUBLE) IS NOT NULL AND ABS(CAST(lyi.revenue_ly AS DOUBLE)) > 0
                 THEN (CAST(ci.revenue AS DOUBLE) - CAST(lyi.revenue_ly AS DOUBLE)) / ABS(CAST(lyi.revenue_ly AS DOUBLE)) * 100
                 ELSE NULL END AS YOY_QUARTER_OR,
            
            CASE WHEN CAST(lyi.operate_profit_ly AS DOUBLE) IS NOT NULL AND ABS(CAST(lyi.operate_profit_ly AS DOUBLE)) > 0
                 THEN (CAST(ci.operate_profit AS DOUBLE) - CAST(lyi.operate_profit_ly AS DOUBLE)) / ABS(CAST(lyi.operate_profit_ly AS DOUBLE)) * 100
                 ELSE NULL END AS YOY_QUARTER_OP,
            
            CAST(cf.q_roe AS DOUBLE) AS ROE_QUARTER,
            CAST(cf.roa AS DOUBLE) AS ROA_QUARTER
            
        FROM current_fina cf
        LEFT JOIN last_year_fina lyf 
            ON cf.ts_code = lyf.ts_code AND cf.end_date = lyf.end_date
        LEFT JOIN current_income ci
            ON cf.ts_code = ci.ts_code AND cf.end_date = ci.end_date
        LEFT JOIN last_year_income lyi
            ON cf.ts_code = lyi.ts_code AND cf.end_date = lyi.end_date
    )
    
    SELECT * FROM combined
    WHERE trade_date IS NOT NULL
    ORDER BY ts_code, trade_date
    """
    
    t0 = datetime.now()
    df = con.execute(sql).fetchdf()
    elapsed = (datetime.now() - t0).total_seconds()
    
    logger.info(f"预计算完成，耗时 {elapsed:.1f}s，行数 {len(df):,}")
    
    # 保存
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(OUTPUT_PATH, index=False)
    logger.info(f"已保存: {OUTPUT_PATH}")
    
    con.close()
    return df


if __name__ == '__main__':
    df = precompute_financial_factors()
    print(f"\n✅ 财务因子预计算完成！")
    print(f"输出: {len(df):,} 行")
    print(f"因子: DELTA_ROA, DELTA_ROE, YOY_QUARTER_NP, YOY_QUARTER_OR, YOY_QUARTER_OP, ROE_QUARTER, ROA_QUARTER")
    print(f"\n前5行:")
    print(df.head())

# ────────────────────────────────────────────────────────────
# repair_factors.py
# ────────────────────────────────────────────────────────────
#!/usr/bin/env python3
"""
修复23个因子外层WHERE过滤
策略：
1. 不需要扩展窗口的因子：直接改内层WHERE为目标日期范围
2. 需要扩展窗口的因子：保持扩展窗口，添加外层WHERE过滤
"""

import re

def main():
    print("系统化修复23个因子外层WHERE过滤...")
    print("="*60)
    
    with open('config.py', 'r') as f:
        content = f.read()
    
    # 步骤1: 识别所有因子
    factors = re.findall(r"'name': '([^']+)'.*?('sql_template': \"\"\"(.*?)\"\"\")", content, re.DOTALL)
    factor_dict = {name: sql for name, _, sql in factors}
    
    # 分类定义
    no_extended_needed = [
        'TTM_EP', 'TTM_SP', 'BP', 'DIVIDEND_RATE', 'PEG',
        'ROE_QUARTER', 'ROA_QUARTER', 'DELTA_ROE', 'DELTA_ROA',
        'EP_QUARTER', 'SP_QUARTER', 
        'YOY_QUARTER_NP', 'YOY_QUARTER_OR', 'YOY_QUARTER_OP'
    ]
    
    needs_outer_where = [
        'TTM_EP_PCT_1Y', 'RETURN_12M', 'REVERSE_1M', 'REVERSE_3M',
        'TURNOVER_1M', 'TURNOVER_3M', 'ATR_1M', 'ATR_3M',
        'MAIN_FORCE_5D', 'MAIN_FORCE_20D'
    ]
    
    print(f"因子总数: {len(factors)}")
    print(f"不需要扩展窗口: {len(no_extended_needed)}个")
    print(f"需要外层WHERE: {len(needs_outer_where)}个")
    
    # 步骤2: 修复不需要扩展窗口的因子
    print("\n1. 修复不需要扩展窗口的因子...")
    count_fixed_simple = 0
    
    old_pattern = "WHERE trade_date >= (CAST('{start_dt}' AS INTEGER) - 800000)::VARCHAR AND trade_date <= '{end_dt}'"
    new_pattern = "WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'"
    
    for factor_name in no_extended_needed:
        if factor_name in factor_dict:
            factor_sql = factor_dict[factor_name]
            if old_pattern in factor_sql:
                # 替换整个SQL中的模式
                new_sql = factor_sql.replace(old_pattern, new_pattern)
                # 更新内容
                content = content.replace(factor_sql, new_sql)
                count_fixed_simple += 1
                print(f"  ✅ {factor_name}")
            else:
                print(f"  ⏭️ {factor_name}: 已修复或无需修复")
    
    print(f"已修复: {count_fixed_simple}/{len(no_extended_needed)}")
    
    # 步骤3: 修复需要外层WHERE的因子
    print("\n2. 修复需要外层WHERE的因子...")
    count_fixed_outer = 0
    
    for factor_name in needs_outer_where:
        if factor_name in factor_dict:
            factor_sql = factor_dict[factor_name]
            
            # 检查是否已有外层WHERE
            has_outer_where = False
            lines = factor_sql.strip().split('\n')
            for line in lines:
                line = line.strip()
                if line.startswith("WHERE trade_date >=") or line.startswith("WHERE p.trade_date >="):
                    # 检查是否是正确的外层WHERE
                    if "'{start_dt}'" in line and "'{end_dt}'" in line:
                        has_outer_where = True
                        break
                    # 检查是否是错误的扩展窗口WHERE
                    elif "- 800000" in line:
                        # 需要修复外层WHERE
                        new_sql = factor_sql.replace(
                            "WHERE trade_date >= (CAST('{start_dt}' AS INTEGER) - 800000)::VARCHAR AND trade_date <= '{end_dt}'",
                            "WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'"
                        )
                        content = content.replace(factor_sql, new_sql)
                        count_fixed_outer += 1
                        print(f"  ✅ {factor_name}: 修复外层WHERE")
                        break
            
            if not has_outer_where and factor_sql in content:
                # 添加外层WHERE
                # 找到SQL的结尾位置（在最后一个")"之后）
                lines = factor_sql.strip().split('\n')
                new_lines = []
                for line in lines:
                    new_lines.append(line)
                    # 在适当位置添加WHERE
                    if line.strip().startswith("SELECT") and "ts_code" in line and "trade_date" in line:
                        # 这是最外层的SELECT，跳过
                        pass
                
                # 在SQL结尾添加WHERE
                new_sql = factor_sql.rstrip()
                if not new_sql.endswith("\"\"\""):
                    new_sql += f"\nWHERE trade_date >= '{{start_dt}}' AND trade_date <= '{{end_dt}}'"
                
                content = content.replace(factor_sql, new_sql)
                count_fixed_outer += 1
                print(f"  ✅ {factor_name}: 添加外层WHERE")
    
    print(f"已修复: {count_fixed_outer}/{len(needs_outer_where)}")
    
    # 保存修复后的文件
    with open('config.py', 'w') as f:
        f.write(content)
    
    print(f"\n{'='*60}")
    print(f"修复完成!")
    print(f"- 简单因子: {count_fixed_simple}/{len(no_extended_needed)}")
    print(f"- 外层WHERE: {count_fixed_outer}/{len(needs_outer_where)}")
    print(f"- 总计: {count_fixed_simple + count_fixed_outer}/23")
    
    # 验证修复结果
    print(f"\n验证修复结果...")
    with open('config.py', 'r') as f:
        final_content = f.read()
    
    # 检查是否还有扩展窗口在内层WHERE
    bad_patterns = re.findall(r"WHERE trade_date >= \(CAST\('\{start_dt\}' AS INTEGER\) - 800000\)::VARCHAR", final_content)
    print(f"剩余错误内层WHERE: {len(bad_patterns)}处")
    
    # 检查正确的外层WHERE数量
    good_patterns = re.findall(r"WHERE trade_date >= '\{start_dt\}' AND trade_date <= '\{end_dt\}'", final_content)
    print(f"正确外层WHERE: {len(good_patterns)}处")

if __name__ == '__main__':
    main()

# ────────────────────────────────────────────────────────────
# sql_engine.py
# ────────────────────────────────────────────────────────────
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DuckDB SQL窗口函数因子计算引擎 v2
核心优化：
1. 所有因子都用DuckDB窗口函数计算（纯向量化）
2. 避免子查询嵌套，使用LATERAL JOIN
3. 财务因子使用DuckDB的聚合窗口函数
"""

import duckdb

# ── 配置管理 ────────────────────────────────────────────────────────────────
from .path_config import get_moneyflow_dir
import pandas as pd
from pathlib import Path
from datetime import datetime
import logging
import signal

signal.signal(signal.SIGTERM, signal.SIG_IGN)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)


class FactorEngineV2:
    """DuckDB优化引擎v2：纯窗口函数，无Python循环"""
    
    def __init__(self, data_dir: str, output_path: str):
        self.data_dir = Path(data_dir)
        self.output_path = Path(output_path)
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.con = duckdb.connect()
        self.con.execute("SET memory_limit = '16GB'")
        self.con.execute("SET threads = 4")
        
        self._register_views()
        logger.info(f"引擎v2初始化完成")
    
    def _register_views(self):
        views = {
            'v_daily_hfq': self.data_dir / 'daily_hfq',
            'v_daily_basic': self.data_dir / 'daily_basic',
            'v_income': self.data_dir / 'income',
            'v_fina_indicator': self.data_dir / 'fina_indicator',
            'v_moneyflow': get_moneyflow_dir(),
        }
        for name, path in views.items():
            if path.exists():
                pattern = str(path / '*.parquet') if path.is_dir() else str(path)
                self.con.execute(f"CREATE OR REPLACE VIEW {name} AS SELECT * FROM read_parquet('{pattern}')")
                logger.info(f"注册 {name}")
    
    def run(self, start_date: str, end_date: str) -> pd.DataFrame:
        """执行因子计算（全部使用DuckDB窗口函数）"""
        logger.info(f"\n{'='*60}")
        logger.info(f"开始计算，区间: {start_date} ~ {end_date}")
        logger.info(f"{'='*60}")
        
        t0_total = datetime.now()
        
        # 转换日期格式
        start_dt = start_date.replace('-', '')
        end_dt = end_date.replace('-', '')
        
        sql = f"""
        WITH
        -- 步骤1: 基础行情数据 + LAG列（窗口函数）
        price_base AS (
            SELECT 
                h.ts_code,
                h.trade_date,
                h.close,
                h.open,
                h.high,
                h.low,
                h.vol,
                b.pb,
                b.pe_ttm,
                b.pe,
                b.ps_ttm,
                b.turnover_rate,
                b.total_mv,
                b.dv_ratio,
                b.dv_ttm,
                COALESCE(
                    NULLIF(b.dv_ratio, 0),
                    NULLIF(b.dv_ttm, 0)
                ) AS dividend_rate,
                mf.buy_lg_amount,
                mf.sell_lg_amount,
                COALESCE(mf.buy_lg_amount, 0) - COALESCE(mf.sell_lg_amount, 0) AS main_force,
                -- LAG窗口函数
                LAG(h.close, 1) OVER w AS close_lag1,
                LAG(h.close, 20) OVER w AS close_lag20,
                LAG(h.close, 60) OVER w AS close_lag60,
                LAG(h.close, 252) OVER w AS close_lag252,
                LAG(b.turnover_rate, 1) OVER w AS turnover_rate_lag1,
                LAG(b.turnover_rate, 20) OVER w AS turnover_rate_lag20,
                LAG(b.turnover_rate, 60) OVER w AS turnover_rate_lag60
            FROM v_daily_hfq h
            LEFT JOIN v_daily_basic b ON h.ts_code = b.ts_code AND h.trade_date = b.trade_date
            LEFT JOIN v_moneyflow mf ON h.ts_code = mf.ts_code AND h.trade_date = mf.trade_date
            WHERE h.trade_date >= '{start_dt}' AND h.trade_date <= '{end_dt}'
            WINDOW w AS (PARTITION BY h.ts_code ORDER BY h.trade_date)
        ),
        
        -- 步骤2: 计算滚动因子（窗口函数）
        rolling_factors AS (
            SELECT 
                ts_code,
                trade_date,
                close,
                pb,
                pe_ttm,
                ps_ttm,
                turnover_rate,
                dividend_rate,
                main_force,
                close_lag1,
                close_lag20,
                close_lag60,
                close_lag252,
                -- BP
                CASE WHEN pb > 0 THEN 1.0 / pb ELSE NULL END AS BP,
                -- TTM_EP
                CASE WHEN pe_ttm > 0 THEN 1.0 / pe_ttm
                     WHEN pe > 0 THEN 1.0 / pe
                     ELSE NULL END AS TTM_EP,
                -- TTM_SP
                CASE WHEN ps_ttm > 0 THEN 1.0 / ps_ttm ELSE NULL END AS TTM_SP,
                -- REVERSE
                CASE WHEN close_lag20 IS NOT NULL AND close_lag20 > 0 
                     THEN -((close / close_lag20) - 1) * 100 
                     ELSE NULL END AS REVERSE_1M,
                CASE WHEN close_lag60 IS NOT NULL AND close_lag60 > 0 
                     THEN -((close / close_lag60) - 1) * 100 
                     ELSE NULL END AS REVERSE_3M,
                -- RETURN
                CASE WHEN close_lag252 IS NOT NULL AND close_lag252 > 0 
                     THEN ((close - close_lag252) / close_lag252) * 100 
                     ELSE NULL END AS RETURN_12M,
                -- ATR（True Range）
                GREATEST(
                    high - low,
                    ABS(high - close_lag1),
                    ABS(low - close_lag1)
                ) AS tr,
                -- TURNOVER滚动平均
                turnover_rate,
                AVG(turnover_rate) OVER w_20d AS TURNOVER_1M,
                AVG(turnover_rate) OVER w_60d AS TURNOVER_3M,
                -- ATR滚动平均
                AVG(GREATEST(
                    high - low,
                    ABS(high - close_lag1),
                    ABS(low - close_lag1)
                )) OVER w_20d AS ATR_1M,
                AVG(GREATEST(
                    high - low,
                    ABS(high - close_lag1),
                    ABS(low - close_lag1)
                )) OVER w_60d AS ATR_3M,
                -- MAIN_FORCE累加
                SUM(main_force) OVER w_5d AS MAIN_FORCE_5D,
                SUM(main_force) OVER w_20d AS MAIN_FORCE_20D
            FROM price_base
            WINDOW 
                w AS (PARTITION BY ts_code ORDER BY trade_date),
                w_5d AS (PARTITION BY ts_code ORDER BY trade_date ROWS BETWEEN 4 PRECEDING AND CURRENT ROW),
                w_20d AS (PARTITION BY ts_code ORDER BY trade_date ROWS BETWEEN 19 PRECEDING AND CURRENT ROW),
                w_60d AS (PARTITION BY ts_code ORDER BY trade_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW)
        ),
        
        -- 步骤3: 获取最新财务数据（使用窗口函数ROW_NUMBER）
        fina_with_roa AS (
            SELECT 
                p.ts_code,
                p.trade_date,
                f.end_date,
                CAST(f.roa AS DOUBLE) AS roa,
                CAST(f.roe_yoy AS DOUBLE) AS roe_yoy,
                CAST(f.q_roe AS DOUBLE) AS q_roe
            FROM price_base p
            INNER JOIN v_fina_indicator f 
                ON p.ts_code = f.ts_code
            WHERE CAST(f.end_date AS INTEGER) <= CAST(p.trade_date AS INTEGER)
              AND CAST(f.ann_date AS INTEGER) <= CAST(p.trade_date AS INTEGER)
        ),
        
        fina_latest AS (
            SELECT 
                ts_code,
                trade_date,
                end_date,
                FIRST_VALUE(roa) OVER w AS roa,
                FIRST_VALUE(roe_yoy) OVER w AS roe_yoy,
                FIRST_VALUE(q_roe) OVER w AS q_roe
            FROM fina_with_roa
            WINDOW w AS (PARTITION BY ts_code, trade_date ORDER BY end_date DESC)
        ),
        
        fina_with_ly AS (
            SELECT 
                ts_code,
                trade_date,
                end_date,
                roa,
                roe_yoy,
                q_roe,
                LAG(roa, 4) OVER (PARTITION BY ts_code ORDER BY end_date) AS roa_ly
            FROM fina_latest
        ),
        
        fina_ranked AS (
            SELECT 
                ts_code,
                trade_date,
                roa,
                roe_yoy,
                q_roe,
                roa_ly
            FROM fina_with_ly
        ),
        
        -- 步骤4: 合并财务因子
        fina_final AS (
            SELECT 
                ts_code,
                trade_date,
                roa,
                roe_yoy,
                q_roe,
                -- DELTA_ROA: (roa/roa_ly - 1) * 100
                CASE WHEN roa IS NOT NULL AND roa_ly IS NOT NULL AND roa_ly != 0
                     THEN (roa / roa_ly - 1) * 100
                     ELSE NULL END AS DELTA_ROA,
                -- DELTA_ROE直接使用roe_yoy
                roe_yoy AS DELTA_ROE,
                -- ROE_QUARTER
                q_roe AS ROE_QUARTER,
                -- ROA_QUARTER
                roa AS ROA_QUARTER
            FROM fina_ranked
        ),
        
        -- 步骤5: 获取利润表数据（YOY计算）
        income_ranked AS (
            SELECT 
                p.ts_code,
                p.trade_date,
                CAST(i.n_income_attr_p AS DOUBLE) AS net_profit,
                CAST(i.revenue AS DOUBLE) AS revenue,
                CAST(i.operate_profit AS DOUBLE) AS operate_profit,
                CAST(i.end_date AS INTEGER) AS end_date_int,
                -- 去年同期数据
                LAG(CAST(i.n_income_attr_p AS DOUBLE)) OVER w AS net_profit_ly,
                LAG(CAST(i.revenue AS DOUBLE)) OVER w AS revenue_ly,
                LAG(CAST(i.operate_profit AS DOUBLE)) OVER w AS operate_profit_ly
            FROM price_base p
            INNER JOIN v_income i
                ON p.ts_code = i.ts_code
            WHERE CAST(i.end_date AS INTEGER) <= CAST(p.trade_date AS INTEGER)
              AND CAST(i.ann_date AS INTEGER) <= CAST(p.trade_date AS INTEGER)
              AND i.report_type IN (1, 2)  -- 合并报表
            WINDOW w AS (PARTITION BY p.ts_code ORDER BY CAST(i.end_date AS INTEGER))
        ),
        
        income_final AS (
            SELECT 
                ts_code,
                trade_date,
                -- YOY_QUARTER_NP
                CASE WHEN net_profit IS NOT NULL AND net_profit_ly IS NOT NULL AND net_profit_ly != 0
                     THEN ((net_profit - net_profit_ly) / ABS(net_profit_ly)) * 100
                     ELSE NULL END AS YOY_QUARTER_NP,
                -- YOY_QUARTER_OR
                CASE WHEN revenue IS NOT NULL AND revenue_ly IS NOT NULL AND revenue_ly != 0
                     THEN ((revenue - revenue_ly) / ABS(revenue_ly)) * 100
                     ELSE NULL END AS YOY_QUARTER_OR,
                -- YOY_QUARTER_OP
                CASE WHEN operate_profit IS NOT NULL AND operate_profit_ly IS NOT NULL AND operate_profit_ly != 0
                     THEN ((operate_profit - operate_profit_ly) / ABS(operate_profit_ly)) * 100
                     ELSE NULL END AS YOY_QUARTER_OP
            FROM income_ranked
        ),
        
        -- 步骤6: 最终合并
        final_merge AS (
            SELECT 
                r.ts_code,
                r.trade_date,
                r.BP,
                r.TTM_EP,
                r.TTM_SP,
                r.REVERSE_1M,
                r.REVERSE_3M,
                r.RETURN_12M,
                r.TURNOVER_1M,
                r.TURNOVER_3M,
                r.ATR_1M,
                r.ATR_3M,
                r.dividend_rate AS DIVIDEND_RATE,
                r.MAIN_FORCE_5D,
                r.MAIN_FORCE_20D,
                f.DELTA_ROA,
                f.DELTA_ROE,
                f.ROE_QUARTER,
                f.ROA_QUARTER,
                i.YOY_QUARTER_NP,
                i.YOY_QUARTER_OR,
                i.YOY_QUARTER_OP
            FROM rolling_factors r
            LEFT JOIN fina_final f 
                ON r.ts_code = f.ts_code AND r.trade_date = f.trade_date
            LEFT JOIN income_final i
                ON r.ts_code = i.ts_code AND r.trade_date = i.trade_date
        )
        
        -- 最终输出
        SELECT * FROM final_merge
        ORDER BY ts_code, trade_date
        """
        
        logger.info("开始执行SQL（纯DuckDB窗口函数）...")
        t0 = datetime.now()
        
        try:
            df = self.con.execute(sql).fetchdf()
            elapsed = (datetime.now() - t0).total_seconds()
            
            logger.info(f"✅ SQL执行完成，耗时 {elapsed:.1f}s，行数 {len(df):,}")
            
            # 添加占位因子（简化处理）
            df['TTM_EP_PCT_1Y'] = None
            df['PEG'] = None
            df['EP_QUARTER'] = None
            df['SP_QUARTER'] = None
            
            # 保存
            df.to_parquet(self.output_path, index=False)
            elapsed_total = (datetime.now() - t0_total).total_seconds()
            
            logger.info(f"✅ 全部完成，总耗时 {elapsed_total:.1f}s")
            logger.info(f"已保存: {self.output_path}")
            
            return df
            
        except Exception as e:
            logger.error(f"SQL执行失败: {e}")
            raise
    
    def close(self):
        self.con.close()


def test_performance():
    """性能测试"""
    print("\n" + "="*60)
    print("性能测试：DuckDB优化引擎v2")
    print("="*60)
    
    engine = FactorEngineV2(
        data_dir='./data',
        output_path='./output/factors_v2_202401_test.parquet'
    )
    
    t0 = datetime.now()
    df = engine.run('2024-01-01', '2024-01-10')
    engine.close()
    
    elapsed = (datetime.now() - t0).total_seconds()
    
    print(f"\n✅ 测试完成！")
    print(f"总耗时: {elapsed:.1f}秒")
    print(f"输出: {len(df):,} 行，{len(df.columns)} 列")
    print(f"\n前5行:")
    print(df.head())


if __name__ == '__main__':
    test_performance()
