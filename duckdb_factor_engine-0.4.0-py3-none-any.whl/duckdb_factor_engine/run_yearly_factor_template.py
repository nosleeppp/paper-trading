#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
因子生成标准模板 - duckdb_factor_engine v0.3.0
年度分块 + 年度并行 + 最终合并方案

====================================================================
  核心思路：分年度生成 → 年度并行 → 最终合并
====================================================================
  1. 按年循环，每年独立生成该年度所有因子的长表文件
     - 每年内部：因子串行生成（SET threads=1）
     - 每因子写入独立 parquet，最后合并为该年年度 parquet
  2. 年度间并行执行（ProcessPoolExecutor，max_workers=4）
     - 避免 8 个年度同时跑，控制在 4 个并行
     - 每完成一个年度，清理内存
  3. 8 个年度文件全部生成后，用 DuckDB 合并为一个完整长表
     - 使用 read_parquet() 读取所有年度文件
     - UNION ALL 后写入最终文件
  4. 最终长表通过 Flight Server 提供给回测系统

====================================================================
"""

# ============================================================
# ============ 用户配置区 ====================================
# ============================================================

DATA_DIR = '/root/lqq_bot_workspace/data'
OUTPUT_DIR = '/root/lqq_bot_workspace/data/factors_yearly_output'
START_DATE = '20170101'
END_DATE = '20260601'
N_WORKERS = 4
FACTOR_SCOPE = 'all'
# 可通过命令行覆盖：--years 2017,2025,2026 --factors all

# ============================================================
# ============ 以下代码不需要修改 =============================
# ============================================================

import os
import sys
import math
import shutil
import signal
import logging
import multiprocessing as mp
from pathlib import Path
from datetime import datetime

_TEMPLATE_DIR = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(_TEMPLATE_DIR) == 'duckdb_factor_engine':
    _PACKAGE_DIR = _TEMPLATE_DIR
else:
    import duckdb_factor_engine as _pkg
    _PACKAGE_DIR = os.path.dirname(os.path.abspath(_pkg.__file__))
sys.path.insert(0, _PACKAGE_DIR)

_logger = logging.getLogger()
if not _logger.handlers:
    _h = logging.StreamHandler(sys.stdout)
    _h.setFormatter(logging.Formatter(
        '%(asctime)s [%(levelname)s] %(message)s', datefmt='%H:%M:%S'))
    _logger.addHandler(_h)
    _logger.setLevel(logging.INFO)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S',
    force=True,
)
logger = logging.getLogger('factor_template')

signal.signal(signal.SIGTERM, signal.SIG_IGN)


def _import_config():
    try:
        import duckdb_factor_engine.config as _cfg
        return _cfg.get_factor_names, _cfg.get_factors_by_category, _cfg.get_factor_config
    except ImportError:
        from config import get_factor_names, get_factors_by_category, get_factor_config
        return get_factor_names, get_factors_by_category, get_factor_config

get_factor_names, get_factors_by_category, get_factor_config = _import_config()


def resolve_factor_list(scope):
    if scope == 'all':
        return get_factor_names(enabled_only=True)
    elif isinstance(scope, str):
        factors = get_factors_by_category(scope)
        if not factors:
            raise ValueError(f"类别 '{scope}' 无已启用因子")
        return factors
    elif isinstance(scope, (list, tuple)):
        all_enabled = set(get_factor_names(enabled_only=True))
        for f in scope:
            if f not in all_enabled:
                raise ValueError(f"因子 '{f}' 不在已启用列表中")
        return list(scope)
    else:
        raise ValueError(f"FACTOR_SCOPE 类型不支持: {type(scope)}")


def _register_views(con, data_dir):
    views = {
        'prices':               data_dir + '/daily_hfq',
        'daily_basic':          data_dir + '/daily_basic',
        'moneyflow':            data_dir + '/moneyflow',
        'stk_holdernumber':     data_dir + '/stk_holdernumber',
        'stk_factor_pro':       data_dir + '/stk_factor_pro',
        'income_vip':           data_dir + '/income',
        'income_raw':           data_dir + '/income',
        'fina_indicator':      data_dir + '/fina_indicator',
        'fina_cashflow_vip':    data_dir + '/fina_cashflow_vip',
        'fina_balancesheet_vip': data_dir + '/fina_balancesheet',
        'fina_audit':          data_dir + '/fina_audit',
        'dividend':             data_dir + '/dividend',
        'top10_holders':        data_dir + '/top10_holders',
        'top10_floatholders':   data_dir + '/top10_floatholders',
        'stk_holdertrade':      data_dir + '/stk_holdertrade',
        'stk_repurchase':       data_dir + '/stk_repurchase',
        'express':              data_dir + '/express',
        'broker_recommend':     data_dir + '/broker_recommend',
        'hk_hold':             data_dir + '/hk_hold',
        'top_list':             data_dir + '/top_list',
        'stk_limit':            data_dir + '/stk_limit',
        'suspend_d':            data_dir + '/suspend_d.parquet',
        'index_weight':         data_dir + '/index_weight',
        'block_trade':          data_dir + '/block_trade',
    }
    for name, path in views.items():
        if os.path.exists(path):
            pattern = path + '/*.parquet' if os.path.isdir(path) else path
            try:
                con.execute(
                    f"CREATE OR REPLACE VIEW {name} AS "
                    f"SELECT * FROM read_parquet('{pattern}')"
                )
            except Exception:
                pass


def _worker_compute_year(args):
    """
    每个年度的计算逻辑（独立进程）：
      1. 独立 DuckDB 连接（threads=1，4GB 内存）
      2. 注册数据视图 + prep 表视图
      3. 串行计算每个因子，写入独立 parquet
      4. 年度内所有因子完成后，用 DuckDB 合并为年度长表 parquet
      5. 返回 (year, computed, failed, elapsed, error)
    """
    year, start_dt, end_dt, output_dir, data_dir, prep_parquet_paths, factor_list = args

    import duckdb
    import pandas as pd
    from datetime import datetime as _dt, timedelta

    t0 = _dt.now()
    year_dir = os.path.join(output_dir, f'_year_{year}')
    os.makedirs(year_dir, exist_ok=True)

    factor_parquet_paths = []  # (factor_name, path)
    computed = 0
    failed = 0

    try:
        con = duckdb.connect()
        con.execute("SET threads = 1")
        con.execute("SET memory_limit = '4GB'")

        _register_views(con, data_dir)

        for view_name, parquet_path in prep_parquet_paths.items():
            if os.path.exists(parquet_path):
                try:
                    con.execute(
                        f"CREATE OR REPLACE VIEW {view_name} AS "
                        f"SELECT * FROM read_parquet('{parquet_path}')"
                    )
                except Exception:
                    pass

        for fname in factor_list:
            cfg = get_factor_config(fname)
            if cfg is None or not cfg.get('enabled', True):
                continue

            fpath = os.path.join(year_dir, f'{fname}.parquet')
            if os.path.exists(fpath):
                # 跳过已完成
                factor_parquet_paths.append((fname, fpath))
                computed += 1
                continue

            dt_start = _dt.strptime(start_dt, '%Y%m%d')
            start_dt_20d = (dt_start - timedelta(days=30)).strftime('%Y%m%d')
            start_dt_60d = (dt_start - timedelta(days=90)).strftime('%Y%m%d')
            start_dt_2y  = (dt_start - timedelta(days=740)).strftime('%Y%m%d')

            sql = cfg['sql_template'].format(
                start_dt=start_dt,
                end_dt=end_dt,
                start_dt_20d=start_dt_20d,
                start_dt_60d=start_dt_60d,
                start_dt_2y=start_dt_2y,
            )

            try:
                df = con.execute(sql).fetchdf()
                if len(df) == 0:
                    failed += 1
                    continue

                # 转为长表
                id_vars = ['ts_code', 'trade_date']
                value_cols = [c for c in df.columns if c not in id_vars]
                if not value_cols:
                    failed += 1
                    continue

                col = value_cols[0]
                df_long = pd.DataFrame({
                    'ts_code': df['ts_code'],
                    'trade_date': df['trade_date'],
                    'factor_name': fname,
                    'factor_value': df[col],
                }).dropna(subset=['factor_value'])

                if len(df_long) > 0:
                    df_long.to_parquet(fpath, index=False)
                    factor_parquet_paths.append((fname, fpath))

                computed += 1

            except Exception as e:
                failed += 1

        con.close()

        # ── 年度合并：DuckDB glob ──────────────────
        if factor_parquet_paths:
            annual_path = os.path.join(output_dir, f'_annual_{year}.parquet')

            merge_con = duckdb.connect()
            merge_con.execute("SET threads=1")
            merge_con.execute("SET memory_limit='2GB'")

            merge_con.execute(f"""
                COPY (SELECT * FROM read_parquet('{year_dir}/*.parquet'))
                TO '{annual_path}' (FORMAT PARQUET, COMPRESSION 'zstd')
            """)

            merge_con.close()

            # 清理因子独立文件
            for _, p in factor_parquet_paths:
                try:
                    os.remove(p)
                except Exception:
                    pass

            logger.info(f"    [{year}] ✅ 年度文件: {annual_path} ({os.path.getsize(annual_path)/1024/1024:.1f}MB, {computed}因子)")
        else:
            logger.warning(f"    [{year}] 无因子数据")

    except Exception as e:
        return year, computed, failed, (_dt.now() - t0).total_seconds(), str(e)[:100]

    elapsed = (_dt.now() - t0).total_seconds()
    return year, computed, failed, elapsed, None


def main():
    import argparse
    parser = argparse.ArgumentParser(description='因子生成')
    parser.add_argument('--years', type=str, default=None,
                        help='逗号分隔的年份列表，如 2017,2025,2026。默认从 START_DATE/END_DATE 计算')
    parser.add_argument('--factors', type=str, default=None,
                        help='因子范围：all 或逗号分隔的因子名。默认使用 FACTOR_SCOPE')
    parser.add_argument('--workers', type=int, default=N_WORKERS,
                        help=f'并行 worker 数，默认 {N_WORKERS}')
    args = parser.parse_args()

    # 确定年份列表
    if args.years is not None:
        years = [int(y.strip()) for y in args.years.split(',')]
    else:
        years = list(range(int(START_DATE[:4]), int(END_DATE[:4]) + 1))

    # 确定因子范围
    factor_scope = args.factors if args.factors else FACTOR_SCOPE

    t_start = datetime.now()

    logger.info("=" * 60)
    logger.info("  duckdb_factor_engine - 年度并行因子生成 v0.3.0")
    logger.info("=" * 60)
    logger.info(f"  数据目录 : {DATA_DIR}")
    logger.info(f"  输出目录 : {OUTPUT_DIR}")
    logger.info(f"  生成年份 : {years}")
    logger.info(f"  并行年度数: {args.workers}")
    logger.info(f"  因子范围 : {factor_scope}")
    logger.info("=" * 60)

    if not os.path.isdir(DATA_DIR):
        logger.error(f"数据目录不存在: {DATA_DIR}")
        sys.exit(1)

    factor_list = resolve_factor_list(factor_scope)
    total = len(factor_list)
    logger.info(f"\n将生成 {total} 个因子")

    needed_prep = set()
    for fname in factor_list:
        cfg = get_factor_config(fname)
        if cfg:
            sql_l = cfg['sql_template'].lower()
            for prep in [
                'fina_indicator_prep', 'income_prep', 'fina_cashflow_vip_prep',
                'fina_balancesheet_vip_prep', 'income_ttm_prep', 'income_sorted',
                'fina_indicator_sorted', 'moneyflow_rolling_prep',
                'turnover_rolling_prep', 'prices_return_prep',
                'stk_holdernumber_prep', 'dividend_prep',
                'income_exp_sorted', 'fina_ind_full_sorted',
                'finabal_full_sorted', 'finacf_full_sorted',
            ]:
                if prep in sql_l:
                    needed_prep.add(prep)
    logger.info(f"  需要的Prep表: {sorted(needed_prep) or '无'}")

    out_path = Path(OUTPUT_DIR)
    out_path.mkdir(parents=True, exist_ok=True)

    # ── Step 1: 主进程 DuckDB 财务预计算 ────────────────
    t_prep = datetime.now()
    logger.info("\n[Step 1/5] 主进程 DuckDB 初始化 + 财务预计算...")

    import duckdb
    main_con = duckdb.connect()
    main_con.execute("SET threads=4")
    main_con.execute("SET memory_limit='2GB'")

    _register_views(main_con, DATA_DIR)
    logger.info("  视图注册完成")

    logger.info("  预计算财务共享数据...")
    import duckdb_factor_engine.core as _core_mod
    engine = object.__new__(FactorEngineV72 := _core_mod.FactorEngineV72)
    engine.con = main_con
    engine.data_dir = Path(DATA_DIR)
    engine._register_views = lambda: None
    engine._prepare_financial_tables_fixed()
    prep_elapsed = (datetime.now() - t_prep).total_seconds()
    logger.info(f"  ✅ 预计算完成，耗时 {prep_elapsed:.1f}s")

    # ── Step 2: 导出 prep 表 ─────────────────────────────
    logger.info("\n[Step 2/5] 导出预计算表为共享 parquet...")
    prep_cache_dir = out_path / '_prep_cache'
    prep_cache_dir.mkdir(parents=True, exist_ok=True)

    all_prep_tables = [
        'fina_indicator_prep', 'fina_indicator_ly',
        'income_prep', 'income_ly',
        'income_sorted', 'fina_indicator_sorted',
        'stk_holdernumber_prep', 'dividend_prep',
        'fina_cashflow_vip_prep', 'fina_balancesheet_vip_prep',
        'income_exp_sorted', 'fina_ind_full_sorted',
        'finabal_full_sorted', 'finacf_full_sorted',
        'income_ttm_prep',
    ]
    prep_table_names = [t for t in all_prep_tables if t in needed_prep]

    prep_parquet_paths = {}
    for tbl in prep_table_names:
        out_file = prep_cache_dir / f'{tbl}.parquet'
        try:
            df = main_con.execute(f"SELECT * FROM {tbl}").fetchdf()
            df.to_parquet(str(out_file), index=False)
            prep_parquet_paths[tbl] = str(out_file)
            logger.info(f"    {tbl}: {len(df):,} 行 → {out_file.stat().st_size / 1024 / 1024:.1f} MB")
        except Exception as e:
            logger.warning(f"    {tbl} 导出失败: {e}")

    main_con.close()
    export_elapsed = (datetime.now() - t_prep).total_seconds() - prep_elapsed
    logger.info(f"  ✅ 导出完成，耗时 {export_elapsed:.1f}s")

    # ── Step 3: 年度列表 ────────────────────────────────
    from datetime import timedelta
    logger.info(f"\n[Step 3/5] 年度列表: {years}")

    year_args = []
    for year in years:
        y_start = f"{year}0101"
        y_end = f"{year}1231"
        year_args.append((
            year, y_start, y_end,
            str(out_path), DATA_DIR,
            prep_parquet_paths, factor_list,
        ))

    # ── Step 4: 年度并行计算 ────────────────────────────
    t_worker = datetime.now()
    logger.info(f"\n[Step 4/5] 年度并行计算（{len(years)}个年度，max_workers={args.workers}）...")

    ctx = mp.get_context('spawn')
    total_computed = 0
    total_failed = 0
    year_results = []

    with ctx.Pool(processes=args.workers) as pool:
        results = pool.map(_worker_compute_year, year_args)

    worker_elapsed = (datetime.now() - t_worker).total_seconds()

    for year, computed, failed, elapsed, err in results:
        total_computed += computed
        total_failed += failed
        year_results.append((year, computed, failed, elapsed, err))
        if err:
            logger.error(f"  [{year}] ❌ 错误: {err}")
        else:
            logger.info(f"  [{year}] ✅ {computed}成功/{failed}失败，{elapsed:.1f}s")

    # ── Step 5: DuckDB UNION ALL 合并所有年度 ───────────
    logger.info(f"\n[Step 5/5] DuckDB 合并 {len(years)} 个年度文件...")

    annual_files = []
    for year in years:
        fpath = out_path / f'_annual_{year}.parquet'
        if fpath.exists() and fpath.stat().st_size > 0:
            sz = fpath.stat().st_size / 1024 / 1024
            annual_files.append(str(fpath))
            logger.info(f"    [{year}] {sz:.1f} MB ✓")
        else:
            logger.warning(f"    [{year}] 文件不存在或为空，跳过: {fpath}")

    if not annual_files:
        logger.error("没有找到任何年度文件，退出")
        sys.exit(1)

    final_path = out_path / 'factors_all.parquet'

    merge_con = duckdb.connect()
    merge_con.execute("SET threads=4")
    merge_con.execute("SET memory_limit='4GB'")

    t_merge = datetime.now()

    if len(annual_files) == 1:
        merge_con.execute(f"""
            COPY (SELECT * FROM read_parquet('{annual_files[0]}'))
            TO '{final_path}' (FORMAT PARQUET, COMPRESSION 'zstd')
        """)
    else:
        # 构建 UNION ALL 查询
        union_parts = ' UNION ALL '.join([f"SELECT * FROM read_parquet('{f}')" for f in annual_files])
        merge_con.execute(f"""
            COPY ({union_parts})
            TO '{final_path}' (FORMAT PARQUET, COMPRESSION 'zstd')
        """)

    merge_con.close()
    merge_elapsed = (datetime.now() - t_merge).total_seconds()

    total_elapsed = (datetime.now() - t_start).total_seconds()

    # ── 摘要 ──────────────────────────────────────────────
    logger.info("")
    logger.info("=" * 60)
    logger.info(f"  ✅ 完成！{total_computed} 成功 / {total_failed} 失败")
    logger.info(f"  预计算 : {prep_elapsed:.1f}s")
    logger.info(f"  导出   : {export_elapsed:.1f}s")
    logger.info(f"  年度并行: {worker_elapsed:.1f}s ({worker_elapsed/60:.1f}分钟)")
    logger.info(f"  合并   : {merge_elapsed:.1f}s")
    logger.info(f"  总耗时 : {total_elapsed:.1f}s ({total_elapsed/60:.1f}分钟)")
    logger.info(f"  输出   : {final_path}")
    logger.info("=" * 60)

    # ── 验证 ─────────────────────────────────────────────
    if final_path.exists():
        size_mb = final_path.stat().st_size / 1024 / 1024
        logger.info(f"\n📦 输出: {final_path} ({size_mb:.1f} MB)")
        import pandas as pd
        df = pd.read_parquet(final_path)
        logger.info(f"   格式: 长表 (factor_name, factor_value)")
        logger.info(f"   行数: {len(df):,}")
        logger.info(f"   因子数: {df['factor_name'].nunique()}")
        logger.info(f"   股票数: {df['ts_code'].nunique():,}")
        logger.info(f"   日期: {df['trade_date'].min()} ~ {df['trade_date'].max()}")


if __name__ == '__main__':
    import functools, sys
    print = functools.partial(print, flush=True)
    sys.stdout.reconfigure(line_buffering=True)
    main()
