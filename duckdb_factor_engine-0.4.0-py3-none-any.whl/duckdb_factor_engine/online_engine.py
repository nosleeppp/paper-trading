# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 在线因子计算引擎 (OnlineEngine)

为回测系统（quant_backtest）提供逐日实时因子计算。
初始化时一次性加载 prep 表到内存，后续每次 compute() 调用仅计算当日因子。

使用示例（在 quant_backtest 回测循环中）:
    >>> from duckdb_factor_engine import OnlineEngine
    >>> oe = OnlineEngine(data_dir='/data', factors=['BP', 'TTM_EP', 'RETURN_12M'])
    >>> for trade_date in backtest_dates:
    ...     factors = oe.compute(trade_date)
    ...     signal = strategy.generate(factors, prices)
    ...     orders = executor.execute(signal)
    >>> oe.close()

性能目标:
    - 初始化: ~30-60s（一次性 prep 表加载）
    - compute(): < 100ms/日（50 因子，全市场 ~5000 只股票）
    - 内存: < 8GB
"""

import os
import logging
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Union

import duckdb
import pandas as pd

logger = logging.getLogger(__name__)


class OnlineEngine:
    """在线因子计算引擎（回测实时集成）"""

    def __init__(self, data_dir: str, factors: list = None):
        """
        Args:
            data_dir: 原始数据根目录
            factors: 需要预加载的因子列表（None=全部启用因子）
        """
        self.data_dir = Path(data_dir)

        # 创建 DuckDB 连接（内存模式）
        self.con = duckdb.connect(':memory:')
        self.con.execute("SET threads = 4")
        self.con.execute("SET memory_limit = '8GB'")

        # 确定因子列表
        from .config import get_factor_names, get_factor_config
        if factors is None:
            self.factor_names = get_factor_names(enabled_only=True)
        else:
            all_enabled = set(get_factor_names(enabled_only=True))
            self.factor_names = [f for f in factors if f in all_enabled]

        self._factor_configs = {
            name: get_factor_config(name)
            for name in self.factor_names
            if get_factor_config(name) is not None
        }

        logger.info(f"OnlineEngine: 初始化 {len(self._factor_configs)} 个因子")

        # 注册所有数据视图
        from .views import register_all_views
        register_all_views(self.con, str(self.data_dir))

        # 物化 prep 表到内存（CREATE TABLE 而非 VIEW，避免每次查询重新扫描）
        self._materialize_prep_tables()

        logger.info(f"OnlineEngine: 初始化完成")

    def _materialize_prep_tables(self):
        """
        将 prep 表从 parquet 文件物化到 DuckDB 内存。
        物化后的表在后续 compute() 调用中可以直接使用，无需重新扫描磁盘。
        """
        prep_tables = [
            'fina_indicator_prep',
            'income_prep',
            'fina_cashflow_vip_prep',
            'fina_balancesheet_vip_prep',
            'stk_holdernumber_prep',
            'dividend_prep',
            'stk_repurchase_prep',
            'income_sorted',
            'fina_indicator_sorted',
            'income_ttm_prep',
            'income_exp_sorted',
            'fina_ind_full_sorted',
            'finabal_full_sorted',
            'finacf_full_sorted',
        ]

        for tbl in prep_tables:
            try:
                result = self.con.execute(
                    f"SELECT COUNT(*) FROM information_schema.tables "
                    f"WHERE table_name = '{tbl}'"
                ).fetchone()[0]
                if result > 0:
                    logger.debug(f"  Prep 表已存在: {tbl}")
                    continue

                # 尝试从视图创建物化表
                try:
                    self.con.execute(f"CREATE TABLE {tbl} AS SELECT * FROM {tbl}")
                    cnt = self.con.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
                    logger.debug(f"  物化 {tbl}: {cnt:,} 行")
                except Exception as e:
                    logger.debug(f"  跳过 {tbl}: {e}")
            except Exception:
                pass

    def compute(self, trade_date: str, factors: list = None) -> pd.DataFrame:
        """
        计算指定日期的因子值。

        Args:
            trade_date: 交易日 (YYYYMMDD 或 YYYY-MM-DD)
            factors: 需要计算的因子列表（None=使用初始化时的全部因子）

        Returns:
            DataFrame: index=ts_code, columns=因子名（宽表）

        Point-in-time 保证:
            - 所有 SQL 使用 trade_date 作为数据截止点
            - 财务数据过滤 ann_date <= trade_date
            - 价格数据仅使用 <= trade_date 的历史
        """
        trade_date = trade_date.replace('-', '')

        if factors is None:
            factors = self.factor_names
        else:
            factors = [f for f in factors if f in self._factor_configs]

        if not factors:
            return pd.DataFrame()

        # 按因子类型分组，减少 SQL 往返
        results = {}
        daily_factors = []
        rolling_factors = []
        fina_factors = []

        for fname in factors:
            cfg = self._factor_configs[fname]
            sql = cfg['sql_template'].lower()
            if 'window' in sql or 'rows between' in sql or 'lag(' in sql or 'over' in sql:
                # 滚动窗口因子从 prices 或 daily_basic 窗口计算
                if 'prices' in sql:
                    rolling_factors.append(fname)
                else:
                    daily_factors.append(fname)
            elif 'fina_indicator' in sql or 'income_' in sql or 'fina_' in sql or 'fina_' in sql:
                fina_factors.append(fname)
            else:
                daily_factors.append(fname)

        # 计算日频因子（单日期查询，利用分区裁剪）
        if daily_factors:
            df_daily = self._compute_daily_factors(trade_date, daily_factors)
            if not df_daily.empty:
                for col in df_daily.columns:
                    if col not in ('ts_code', 'trade_date'):
                        results[col] = df_daily.set_index('ts_code')[col]

        # 计算滚动窗口因子（需要回溯历史数据）
        if rolling_factors:
            df_rolling = self._compute_rolling_factors(trade_date, rolling_factors)
            if not df_rolling.empty:
                for col in df_rolling.columns:
                    if col not in ('ts_code', 'trade_date'):
                        results[col] = df_rolling.set_index('ts_code')[col]

        # 计算财务 ASOF 因子
        if fina_factors:
            df_fina = self._compute_financial_factors(trade_date, fina_factors)
            if not df_fina.empty:
                for col in df_fina.columns:
                    if col not in ('ts_code', 'trade_date'):
                        results[col] = df_fina.set_index('ts_code')[col]

        # 合并所有因子
        if not results:
            return pd.DataFrame()

        result = pd.DataFrame(results)
        result.index.name = 'ts_code'
        return result

    def compute_batch(self, dates: list, factors: list = None) -> pd.DataFrame:
        """
        批量计算多个日期的因子值。

        Args:
            dates: 交易日列表
            factors: 因子列表

        Returns:
            DataFrame: ts_code, trade_date, factor1, factor2, ...（宽表）
        """
        all_dfs = []
        for date in dates:
            df = self.compute(date, factors)
            if not df.empty:
                df['trade_date'] = date.replace('-', '')
                df = df.reset_index()
                all_dfs.append(df)
        if not all_dfs:
            return pd.DataFrame()
        return pd.concat(all_dfs, ignore_index=True)

    def _compute_daily_factors(self, trade_date: str, factor_names: list) -> pd.DataFrame:
        """计算日频因子：直接查询 daily_basic 或类似表，仅过滤单日期"""
        dt_start = datetime.strptime(trade_date, '%Y%m%d')
        start_dt_20d = (dt_start - timedelta(days=30)).strftime('%Y%m%d')
        start_dt_60d = (dt_start - timedelta(days=90)).strftime('%Y%m%d')
        start_dt_90d = (dt_start - timedelta(days=95)).strftime('%Y%m%d')
        start_dt_2y = (dt_start - timedelta(days=740)).strftime('%Y%m%d')

        # 对每个因子执行 SQL
        dfs = []
        for fname in factor_names:
            cfg = self._factor_configs[fname]
            try:
                sql = cfg['sql_template'].format(
                    start_dt=trade_date, end_dt=trade_date,
                    start_dt_20d=start_dt_20d, start_dt_60d=start_dt_60d,
                    start_dt_90d=start_dt_90d, start_dt_2y=start_dt_2y,
                )
                # 优化：将日期范围替换为单日期过滤
                # (如果 SQL 模板本身有滚动窗口，这里会被 rolling 分支处理)
                df = self.con.execute(sql).fetchdf()
                if not df.empty:
                    if 'trade_date' not in df.columns:
                        df['trade_date'] = trade_date
                    dfs.append(df)
            except Exception as e:
                logger.warning(f"因子 {fname} 计算失败: {e}")

        if not dfs:
            return pd.DataFrame()

        # Merge all daily factor results on ts_code
        result = dfs[0]
        for df in dfs[1:]:
            result = pd.merge(result, df, on=['ts_code', 'trade_date'], how='outer')
        return result

    def _compute_rolling_factors(self, trade_date: str, factor_names: list) -> pd.DataFrame:
        """计算滚动窗口因子：需要回溯一定天数的历史数据"""
        dt_start = datetime.strptime(trade_date, '%Y%m%d')
        start_dt_20d = (dt_start - timedelta(days=30)).strftime('%Y%m%d')
        start_dt_60d = (dt_start - timedelta(days=90)).strftime('%Y%m%d')
        start_dt_90d = (dt_start - timedelta(days=95)).strftime('%Y%m%d')
        start_dt_2y = (dt_start - timedelta(days=740)).strftime('%Y%m%d')

        dfs = []
        for fname in factor_names:
            cfg = self._factor_configs[fname]
            try:
                sql = cfg['sql_template'].format(
                    start_dt=trade_date, end_dt=trade_date,
                    start_dt_20d=start_dt_20d, start_dt_60d=start_dt_60d,
                    start_dt_90d=start_dt_90d, start_dt_2y=start_dt_2y,
                )
                df = self.con.execute(sql).fetchdf()
                if not df.empty:
                    if 'trade_date' not in df.columns:
                        df['trade_date'] = trade_date
                    dfs.append(df)
            except Exception as e:
                logger.warning(f"滚动因子 {fname} 计算失败: {e}")

        if not dfs:
            return pd.DataFrame()
        result = dfs[0]
        for df in dfs[1:]:
            result = pd.merge(result, df, on=['ts_code', 'trade_date'], how='outer')
        return result

    def _compute_financial_factors(self, trade_date: str, factor_names: list) -> pd.DataFrame:
        """计算财务因子：使用 ASOF JOIN，prep 表已在内存"""
        dt_start = datetime.strptime(trade_date, '%Y%m%d')
        start_dt_20d = (dt_start - timedelta(days=30)).strftime('%Y%m%d')
        start_dt_60d = (dt_start - timedelta(days=90)).strftime('%Y%m%d')
        start_dt_90d = (dt_start - timedelta(days=95)).strftime('%Y%m%d')
        start_dt_2y = (dt_start - timedelta(days=740)).strftime('%Y%m%d')

        dfs = []
        for fname in factor_names:
            cfg = self._factor_configs[fname]
            try:
                sql = cfg['sql_template'].format(
                    start_dt=trade_date, end_dt=trade_date,
                    start_dt_20d=start_dt_20d, start_dt_60d=start_dt_60d,
                    start_dt_90d=start_dt_90d, start_dt_2y=start_dt_2y,
                )
                df = self.con.execute(sql).fetchdf()
                if not df.empty:
                    if 'trade_date' not in df.columns:
                        df['trade_date'] = trade_date
                    dfs.append(df)
            except Exception as e:
                logger.warning(f"财务因子 {fname} 计算失败: {e}")

        if not dfs:
            return pd.DataFrame()
        result = dfs[0]
        for df in dfs[1:]:
            result = pd.merge(result, df, on=['ts_code', 'trade_date'], how='outer')
        return result

    def get_factor_names(self) -> list:
        """返回已注册的因子名称列表"""
        return list(self._factor_configs.keys())

    def get_universe(self, trade_date: str) -> pd.Index:
        """
        返回指定日期可交易的股票列表。

        基于 prices 表中当天有交易数据的股票。
        """
        trade_date = trade_date.replace('-', '')
        result = self.con.execute(
            f"SELECT DISTINCT ts_code FROM prices WHERE trade_date = '{trade_date}'"
        ).fetchdf()
        if result.empty:
            return pd.Index([])
        return pd.Index(result['ts_code'].unique())

    def close(self):
        """关闭 DuckDB 连接"""
        if self.con:
            self.con.close()
            logger.info("OnlineEngine: 已关闭")
