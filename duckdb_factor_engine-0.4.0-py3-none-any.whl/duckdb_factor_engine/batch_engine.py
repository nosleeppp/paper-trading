#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DuckDB Factor Engine — 批量因子计算引擎 (BatchEngine)

继承自 v0.3.5 的 FactorEngineV72，新增:
- compute() / compute_long() 内存返回模式
- 使用 views.py 统一视图注册
- 修复 worker 静默错误和硬编码路径

向后兼容: FactorEngineV72 保持不变，BatchEngine = FactorEngineV72
"""
import threading
import os
import logging
import sys

_BATCH_LOGGER = logging.getLogger(__name__)


def _export_prep_tables_to_parquet(con, prep_dir):
    """将prep表导出为parquet文件（主进程执行一次）"""
    prep_tables = [
        'fina_indicator_prep',
        'income_prep',
        'stk_holdernumber_prep',
        'dividend_prep',
        'fina_cashflow_vip_prep',
        'fina_balancesheet_vip_prep',
        'stk_repurchase_prep',
        # v7.4 修复：补充缺失的prep表（因子SQL模板依赖）
        'fina_indicator_sorted',
        'income_sorted',
        'income_ttm_prep',
    ]
    os.makedirs(prep_dir, exist_ok=True)
    for tbl in prep_tables:
        out_path = os.path.join(prep_dir, f'{tbl}.parquet')
        try:
            df = con.execute(f"SELECT * FROM {tbl}").fetchdf()
            df.to_parquet(out_path, index=False)
        except Exception:
            pass


def _register_prep_views_from_parquet(con, prep_dir):
    """从prep parquet文件注册视图（跳过耗时的_prepare_financial_inner）"""
    tables = [
        ('fina_indicator_prep', f'{prep_dir}/fina_indicator_prep.parquet'),
        ('income_prep', f'{prep_dir}/income_prep.parquet'),
        ('stk_holdernumber_prep', f'{prep_dir}/stk_holdernumber_prep.parquet'),
        ('dividend_prep', f'{prep_dir}/dividend_prep.parquet'),
        ('fina_cashflow_vip_prep', f'{prep_dir}/fina_cashflow_vip_prep.parquet'),
        ('fina_balancesheet_vip_prep', f'{prep_dir}/fina_balancesheet_vip_prep.parquet'),
        ('stk_repurchase_prep', f'{prep_dir}/stk_repurchase_prep.parquet'),
        # v7.4 修复：补充缺失的prep表（因子SQL模板依赖）
        ('fina_indicator_sorted', f'{prep_dir}/fina_indicator_sorted.parquet'),
        ('income_sorted', f'{prep_dir}/income_sorted.parquet'),
        ('income_ttm_prep', f'{prep_dir}/income_ttm_prep.parquet'),
    ]
    for name, path in tables:
        if os.path.exists(path):
            try:
                con.execute(f"CREATE OR REPLACE VIEW {name} AS SELECT * FROM read_parquet('{path}')")
            except Exception:
                pass


def _worker_process_batch(start_dt: str, end_dt: str, factor_names: list,
                          data_dir: str, output_dir: str, worker_id: int,
                          prep_dir: str = None):
    """
    独立进程：为自己的因子批次初始化一个DuckDB连接，
    然后顺序执行所有因子（连接复用）。
    """
    import os, sys, time, logging
    from datetime import datetime, timedelta

    # 配置logging（子进程需要独立配置）
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s',
    )
    logger = logging.getLogger(f'worker_{worker_id}')

    # 确保包路径在子进程中可用
    _pkg_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _pkg_dir not in sys.path:
        sys.path.insert(0, _pkg_dir)

    try:
        from duckdb_factor_engine.config import get_factor_config

        # 创建独立DuckDB连接（每个进程只创建一次）
        import duckdb
        con = duckdb.connect(database=':memory:')

        # 注册视图（同主进程）
        _register_views_inner(con, data_dir)

        # P2优化：使用预生成的prep parquet文件，避免每个worker重复预处理
        if prep_dir and os.path.exists(os.path.join(prep_dir, 'fina_indicator_prep.parquet')):
            _register_prep_views_from_parquet(con, prep_dir)
        else:
            _prepare_financial_inner(con, data_dir)

        # ── v7.4 全市场股票池对齐 ──────────────────────────────────────
        # 使用已注册的 prices 视图（daily_hfq）构建每日股票网格
        # prices 覆盖全市场所有股票，无日期限制
        full_grid = con.execute(f"""
            SELECT DISTINCT ts_code, CAST(trade_date AS VARCHAR) AS trade_date
            FROM prices
            WHERE trade_date >= '{start_dt}' AND trade_date <= '{end_dt}'
        """).fetchdf()
        logger.info(f"  全市场网格: {len(full_grid):,} 行 (目标日期范围)")

        logger.info(f"  Worker-{worker_id} 初始化完成，处理 {len(factor_names)} 个因子...")
        t0 = time.time()

        computed = []
        for fname in factor_names:
            config = get_factor_config(fname)
            if config is None or not config.get('enabled', True):
                continue

            dt_start = datetime.strptime(start_dt, '%Y%m%d')
            start_dt_20d = (dt_start - timedelta(days=30)).strftime('%Y%m%d')
            start_dt_60d = (dt_start - timedelta(days=90)).strftime('%Y%m%d')
            start_dt_90d = (dt_start - timedelta(days=95)).strftime('%Y%m%d')
            start_dt_2y = (dt_start - timedelta(days=740)).strftime('%Y%m%d')

            try:
                sql = config['sql_template'].format(
                    start_dt=start_dt,
                    end_dt=end_dt,
                    start_dt_20d=start_dt_20d,
                    start_dt_60d=start_dt_60d,
                    start_dt_90d=start_dt_90d,
                    start_dt_2y=start_dt_2y,
                )
                df = con.execute(sql).fetchdf()
                if df is not None and len(df) > 0:
                    # LEFT JOIN 全市场网格，补齐缺失的 stock-day 组合（填充 NaN）
                    merged = full_grid.merge(
                        df, on=['ts_code', 'trade_date'], how='left'
                    )
                    out_path = os.path.join(output_dir, f'{fname}.parquet')
                    merged.to_parquet(out_path, index=False)
                    computed.append(fname)
            except Exception as e:
                logger.warning(f"Worker-{worker_id} 因子 {fname} 计算失败: {e}")

        elapsed = time.time() - t0
        logger.info(f"  Worker-{worker_id} 完成: {len(computed)}/{len(factor_names)} 因子, 耗时 {elapsed:.1f}s")
        con.close()
        return computed
    except Exception as e:
        logger.error(f"  Worker-{worker_id} 初始化失败: {e}")
        return []


def _register_views_inner(con, data_dir):
    """子进程中注册DuckDB视图（使用 views.py 统一入口）"""
    from .views import register_all_views
    register_all_views(con, data_dir)


def _prepare_financial_inner(con, data_dir):
    """子进程中预处理财务表（与主进程相同逻辑）"""
    import logging
    logger = logging.getLogger()

    # 正确的 parquet 路径
    income_pattern = f"{data_dir}/income/*.parquet"
    finabal_pattern = f"{data_dir}/fina_balancesheet/*.parquet"
    finacf_pattern = f"{data_dir}/fina_cashflow_vip/*.parquet"
    fina_ind_pattern = f"{data_dir}/fina_indicator/*.parquet"

    try:
        # fina_indicator_prep（去重）
        con.execute(f"""
            CREATE TABLE IF NOT EXISTS fina_indicator_prep AS
            SELECT * FROM (
                SELECT *,
                    ROW_NUMBER() OVER (
                        PARTITION BY ts_code, CAST(end_date AS INTEGER)
                        ORDER BY CAST(ann_date AS INTEGER) DESC
                    ) AS rn
                FROM fina_indicator
                WHERE end_date IS NOT NULL AND ann_date IS NOT NULL
            ) t WHERE rn = 1
        """)

        # income_prep（去重）
        con.execute(f"""
            CREATE TABLE IF NOT EXISTS income_prep AS
            SELECT * FROM (
                SELECT
                    ts_code,
                    CAST(end_date AS INTEGER) AS end_date_int,
                    CAST(ann_date AS INTEGER) AS ann_date_int,
                    CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                    CAST(n_income_attr_p AS DOUBLE) AS net_profit,
                    CAST(revenue AS DOUBLE) AS revenue,
                    CAST(operate_profit AS DOUBLE) AS operate_profit,
                    ROW_NUMBER() OVER (
                        PARTITION BY ts_code, CAST(end_date AS INTEGER)
                        ORDER BY CAST(ann_date AS INTEGER) DESC,
                                 CAST(f_ann_date AS INTEGER) DESC
                    ) AS rn
                FROM read_parquet('{income_pattern}')
                WHERE end_date IS NOT NULL
                  AND ann_date IS NOT NULL
                  AND f_ann_date IS NOT NULL
                  AND CAST(report_type AS INTEGER) IN (2, 3)
            ) t WHERE rn = 1
        """)

        # stk_holdernumber_prep（去重）
        con.execute("""
            CREATE TABLE IF NOT EXISTS stk_holdernumber_prep AS
            SELECT * FROM (
                SELECT
                    ts_code, end_date, ann_date,
                    CAST(end_date AS INTEGER) AS end_date_int,
                    CAST(ann_date AS INTEGER) AS ann_date_int,
                    holder_num,
                    ROW_NUMBER() OVER (
                        PARTITION BY ts_code, end_date
                        ORDER BY ann_date DESC
                    ) AS rn
                FROM stk_holdernumber
                WHERE end_date IS NOT NULL AND ann_date IS NOT NULL
            ) t WHERE rn = 1
        """)

        # dividend_prep（去重）
        con.execute("""
            CREATE TABLE IF NOT EXISTS dividend_prep AS
            SELECT * FROM (
                SELECT
                    ts_code, end_date, ann_date,
                    CAST(end_date AS INTEGER) AS end_date_int,
                    CAST(ann_date AS INTEGER) AS ann_date_int,
                    COALESCE(CAST(cash_div AS DOUBLE), 0.0) AS cash_div,
                    ROW_NUMBER() OVER (
                        PARTITION BY ts_code, end_date
                        ORDER BY ann_date DESC
                    ) AS rn
                FROM dividend
                WHERE end_date IS NOT NULL AND ann_date IS NOT NULL
            ) t WHERE rn = 1
        """)

        # fina_cashflow_vip_prep（去重）
        con.execute(f"""
            CREATE TABLE IF NOT EXISTS fina_cashflow_vip_prep AS
            SELECT * FROM (
                SELECT
                    ts_code, end_date, ann_date, f_ann_date,
                    CAST(end_date AS INTEGER) AS end_date_int,
                    CAST(ann_date AS INTEGER) AS ann_date_int,
                    CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                    COALESCE(CAST(n_cashflow_act AS DOUBLE), 0.0) AS n_cashflow_act,
                    COALESCE(CAST(net_profit AS DOUBLE), 0.0) AS net_profit,
                    COALESCE(CAST(free_cashflow AS DOUBLE), 0.0) AS free_cashflow,
                    COALESCE(CAST(c_recp_borrow AS DOUBLE), 0.0) AS c_recp_borrow,
                    COALESCE(CAST(c_prepay_amt_borr AS DOUBLE), 0.0) AS c_prepay_amt_borr,
                    COALESCE(CAST(c_recp_cap_contrib AS DOUBLE), 0.0) AS c_recp_cap_contrib,
                    ROW_NUMBER() OVER (
                        PARTITION BY ts_code, end_date
                        ORDER BY ann_date DESC
                    ) AS rn
                FROM fina_cashflow_vip
                WHERE end_date IS NOT NULL AND ann_date IS NOT NULL AND f_ann_date IS NOT NULL
            ) t WHERE rn = 1
        """)

        # fina_balancesheet_vip_prep（去重）
        con.execute(f"""
            CREATE TABLE IF NOT EXISTS fina_balancesheet_vip_prep AS
            SELECT * FROM (
                SELECT
                    ts_code, end_date, ann_date, f_ann_date,
                    CAST(end_date AS INTEGER) AS end_date_int,
                    CAST(ann_date AS INTEGER) AS ann_date_int,
                    CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                    COALESCE(CAST(accounts_receiv AS DOUBLE), 0.0) AS accounts_receiv,
                    COALESCE(CAST(goodwill AS DOUBLE), 0.0) AS goodwill,
                    COALESCE(CAST(total_liab AS DOUBLE), 0.0) AS total_liab,
                    COALESCE(CAST(total_assets AS DOUBLE), 1.0) AS total_assets,
                    COALESCE(CAST(total_cur_assets AS DOUBLE), 0.0) AS total_cur_assets,
                    COALESCE(CAST(total_cur_liab AS DOUBLE), 0.0) AS total_cur_liab,
                    COALESCE(CAST(money_cap AS DOUBLE), 0.0) AS money_cap,
                    COALESCE(CAST(st_borr AS DOUBLE), 0.0) AS st_borr,
                    COALESCE(CAST(notes_payable AS DOUBLE), 0.0) AS notes_payable,
                    COALESCE(CAST(lt_borr AS DOUBLE), 0.0) AS lt_borr,
                    COALESCE(CAST(bond_payable AS DOUBLE), 0.0) AS bond_payable,
                    COALESCE(CAST(total_hldr_eqy_exc_min_int AS DOUBLE), 0.0) AS total_hldr_eqy_exc_min_int,
                    COALESCE(CAST(inventories AS DOUBLE), 0.0) AS inventories,
                    ROW_NUMBER() OVER (
                        PARTITION BY ts_code, end_date
                        ORDER BY ann_date DESC, CAST(f_ann_date AS INTEGER) DESC
                    ) AS rn
                FROM fina_balancesheet_vip
                WHERE end_date IS NOT NULL AND ann_date IS NOT NULL AND f_ann_date IS NOT NULL
            ) t WHERE rn = 1
        """)

        # stk_repurchase_prep
        con.execute("""
            CREATE TABLE IF NOT EXISTS stk_repurchase_prep AS
            SELECT * FROM stk_repurchase
            WHERE ann_date IS NOT NULL
        """)

        logger.info(f"  Worker 财务预处理完成")
    except Exception as e:
        logger.warning(f"  Worker 财务预处理失败: {e}")


"""
DuckDB 因子计算引擎 v7.2 修复版
修复重复问题：预处理时使用 QUALIFY ROW_NUMBER() = 1 去重

修复内容：
1. fina_indicator_prep: 按 ts_code, end_date_int 分组，ann_date_int DESC 排序，取第一条
2. income_prep: 按 ts_code, end_date_int 分组，f_ann_date_int DESC 排序，取第一条
3. 确保 _ly 表继承已去重数据
4. v7.3: 新增17个数据视图 + 4个扩展排序表（income_exp_sorted, fina_ind_full_sorted, finabal_full_sorted, finacf_full_sorted）
"""

import duckdb
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import logging
import signal

# 导入因子配置（兼容直接运行脚本的情况）
try:
    from .config import FACTORS_CONFIG, get_factor_names, get_factor_config
except ImportError:
    from config import FACTORS_CONFIG, get_factor_names, get_factor_config

signal.signal(signal.SIGTERM, signal.SIG_IGN)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)


class FactorEngineV72:
    """DuckDB因子引擎v7.2：修复重复问题"""

    def __init__(self, data_dir: str, output_dir: str):
        self.data_dir = Path(data_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 连接DuckDB（内存模式）
        self.con = duckdb.connect()
        self.con.execute("SET memory_limit = '32GB'")
        self.con.execute("SET threads = 8")

        # 注册数据视图
        self._register_views()

        # 预处理财务数据（修复版：使用 QUALIFY 去重）
        self._prepare_financial_tables_fixed()

        logger.info("✅ 引擎v7.2初始化完成")

    def _register_views(self):
        """注册数据视图（使用 views.py 统一入口）"""
        from .views import register_all_views
        register_all_views(self.con, str(self.data_dir))

    def _prepare_financial_tables_fixed(self):
        """
        预处理财务数据（v7.2修复版）
        按用户描述的逻辑：
          - prep表保留所有期间数据（不去重），ASOF JOIN时用三边界条件筛选
          - ASOF 条件：end_date <= trade_date AND ann_date <= trade_date AND f_ann_date <= trade_date
        """
        logger.info("预处理财务数据（v7.2修复版：保留所有期间）...")

        # 预计算数据路径
        fina_indicator_pattern = str(self.data_dir / 'fina_indicator' / '*.parquet')
        income_pattern = str(self.data_dir / 'income' / '*.parquet')
        finabal_pattern = str(self.data_dir / 'fina_balancesheet' / '*.parquet')
        finacf_pattern = str(self.data_dir / 'fina_cashflow_vip' / '*.parquet')

        # ============================================================
        # 1. 处理 fina_indicator 表（去重prep，保留所有列）
        # ============================================================
        logger.info("  1. 预处理 fina_indicator（完整列）...")
        self.con.execute(f"""
            CREATE OR REPLACE TABLE fina_indicator_prep AS
            SELECT * FROM (
                SELECT *,
                    ROW_NUMBER() OVER (
                        PARTITION BY ts_code, CAST(end_date AS INTEGER)
                        ORDER BY CAST(ann_date AS INTEGER) DESC
                    ) AS rn
                FROM fina_indicator
                WHERE end_date IS NOT NULL AND ann_date IS NOT NULL
            ) t WHERE rn = 1
        """)
        count_after = self.con.execute("SELECT COUNT(*) FROM fina_indicator_prep").fetchone()[0]
        logger.info(f"     fina_indicator_prep: {count_after:,}行")

        # ============================================================
        # 2. 创建 fina_indicator_ly 表（去年同期数据）
        # ============================================================
        logger.info("  2. 创建 fina_indicator_ly 表...")
        self.con.execute("""
            CREATE OR REPLACE TABLE fina_indicator_ly AS
            SELECT
                ts_code,
                CAST(end_date AS INTEGER) AS end_date_int_ly,
                CAST(end_date AS INTEGER) + 10000 AS end_date_int_curr,
                CAST(ann_date AS INTEGER) AS ann_date_int_ly,
                roa AS roa_ly
            FROM fina_indicator_prep
        """)
        logger.info(f"     fina_indicator_ly: {self.con.execute('SELECT COUNT(*) FROM fina_indicator_ly').fetchone()[0]:,}行")

        # ============================================================
        # 3. 处理 income 表（去重prep）
        # ============================================================
        logger.info("  3. 预处理 income...")
        self.con.execute(f"""
            CREATE OR REPLACE TABLE income_prep AS
            SELECT * FROM (
                SELECT
                    ts_code,
                    CAST(end_date AS INTEGER) AS end_date_int,
                    CAST(ann_date AS INTEGER) AS ann_date_int,
                    CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                    CAST(n_income_attr_p AS DOUBLE) AS net_profit,
                    CAST(revenue AS DOUBLE) AS revenue,
                    CAST(operate_profit AS DOUBLE) AS operate_profit,
                    ROW_NUMBER() OVER (
                        PARTITION BY ts_code, CAST(end_date AS INTEGER)
                        ORDER BY CAST(ann_date AS INTEGER) DESC,
                                 CAST(f_ann_date AS INTEGER) DESC
                    ) AS rn
                FROM read_parquet('{income_pattern}')
                WHERE end_date IS NOT NULL
                  AND ann_date IS NOT NULL
                  AND f_ann_date IS NOT NULL
                  AND CAST(report_type AS INTEGER) IN (2, 3)
            ) t WHERE rn = 1
        """)
        count_after = self.con.execute("SELECT COUNT(*) FROM income_prep").fetchone()[0]
        logger.info(f"     income_prep: {count_after:,}行")

        # ============================================================
        # 4. 创建 income_ly 表（去年同期数据）
        # ============================================================
        logger.info("  4. 创建 income_ly 表...")
        self.con.execute("""
            CREATE OR REPLACE TABLE income_ly AS
            SELECT
                ts_code,
                end_date_int AS end_date_int_ly,
                end_date_int + 10000 AS end_date_int_curr,
                ann_date_int AS ann_date_int_ly,
                f_ann_date_int AS f_ann_date_int_ly,
                net_profit AS net_profit_ly,
                revenue AS revenue_ly,
                operate_profit AS operate_profit_ly
            FROM income_prep
        """)
        logger.info(f"     income_ly: {self.con.execute('SELECT COUNT(*) FROM income_ly').fetchone()[0]:,}行")

        # ============================================================
        # 5. 创建复合排序键表
        # ============================================================
        logger.info("  5. 创建复合排序键表...")

        # income_sorted 表（LPAD 字符串复合排序键，三字段）
        self.con.execute(f"""
            CREATE OR REPLACE TABLE income_sorted AS
            SELECT
                ts_code,
                CAST(end_date AS INTEGER) AS end_date_int,
                CAST(ann_date AS INTEGER) AS ann_date_int,
                CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                CAST(n_income_attr_p AS DOUBLE) AS net_profit,
                CAST(revenue AS DOUBLE) AS revenue,
                CAST(operate_profit AS DOUBLE) AS operate_profit,
                LPAD(CAST(end_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(ann_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(f_ann_date AS VARCHAR), 8, '0') AS sort_key_str
            FROM read_parquet('{income_pattern}')
            WHERE CAST(report_type AS INTEGER) IN (2, 3)
            ORDER BY ts_code, sort_key_str DESC
        """)
        logger.info(f"     income_sorted: {self.con.execute('SELECT COUNT(*) FROM income_sorted').fetchone()[0]:,}行")

        # fina_indicator_sorted 表（LPAD 字符串复合排序键，两字段）
        self.con.execute(f"""
            CREATE OR REPLACE TABLE fina_indicator_sorted AS
            SELECT
                ts_code,
                CAST(end_date AS INTEGER) AS end_date_int,
                CAST(ann_date AS INTEGER) AS ann_date_int,
                CAST(roa AS DOUBLE) AS roa,
                CAST(roe_yoy AS DOUBLE) AS roe_yoy,
                CAST(q_roe AS DOUBLE) AS q_roe,
                LPAD(CAST(end_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(ann_date AS VARCHAR), 8, '0') AS sort_key_str
            FROM read_parquet('{fina_indicator_pattern}')
            ORDER BY ts_code, sort_key_str DESC
        """)
        logger.info(f"     fina_indicator_sorted: {self.con.execute('SELECT COUNT(*) FROM fina_indicator_sorted').fetchone()[0]:,}行")

        # ============================================================
        # 6. 创建索引
        # ============================================================
        logger.info("  6. 创建索引...")
        try:
            self.con.execute("CREATE INDEX IF NOT EXISTS idx_income_sorted ON income_sorted(ts_code, sort_key_str DESC)")
            self.con.execute("CREATE INDEX IF NOT EXISTS idx_fina_sorted ON fina_indicator_sorted(ts_code, sort_key_str DESC)")
            logger.info("    索引创建完成")
        except Exception as e:
            logger.warning(f"    创建索引失败（可能不支持）: {e}")

        # ============================================================
        # 7. 预处理 stk_holdernumber（去重 + LPAD 排序键）
        # ============================================================
        logger.info("  7. 预处理 stk_holdernumber...")
        try:
            self.con.execute("""
                CREATE OR REPLACE TABLE stk_holdernumber_prep AS
                SELECT * FROM (
                    SELECT
                        ts_code,
                        end_date,
                        ann_date,
                        CAST(end_date AS INTEGER) AS end_date_int,
                        CAST(ann_date AS INTEGER) AS ann_date_int,
                        LPAD(REPLACE(end_date, '-', ''), 8, '0') ||
                        LPAD(REPLACE(ann_date, '-', ''), 8, '0') AS sort_key_str,
                        holder_num,
                        ROW_NUMBER() OVER (
                            PARTITION BY ts_code, end_date
                            ORDER BY ann_date DESC
                        ) AS rn
                    FROM stk_holdernumber
                    WHERE end_date IS NOT NULL AND ann_date IS NOT NULL
                ) t WHERE rn = 1
            """)
            cnt = self.con.execute("SELECT COUNT(*) FROM stk_holdernumber_prep").fetchone()[0]
            logger.info(f"     stk_holdernumber_prep: {cnt:,}行")
            self.con.execute("CREATE INDEX IF NOT EXISTS idx_holder ON stk_holdernumber_prep(ts_code, end_date_int)")
        except Exception as e:
            logger.warning(f"     stk_holdernumber 预处理失败: {e}")

        # ============================================================
        # 7b. 预处理 dividend（去重prep，用于DIVIDEND_PAYOUT_RATIO）
        # ============================================================
        logger.info("  7b. 预处理 dividend...")
        try:
            dividend_pattern = str(self.data_dir / 'dividend')
            self.con.execute(f"""
                CREATE OR REPLACE TABLE dividend_prep AS
                SELECT * FROM (
                    SELECT
                        ts_code,
                        end_date,
                        ann_date,
                        CAST(end_date AS INTEGER) AS end_date_int,
                        CAST(ann_date AS INTEGER) AS ann_date_int,
                        COALESCE(CAST(cash_div AS DOUBLE), 0.0) AS cash_div,
                        ROW_NUMBER() OVER (
                            PARTITION BY ts_code, end_date
                            ORDER BY ann_date DESC
                        ) AS rn
                    FROM read_parquet('{dividend_pattern}/*.parquet')
                    WHERE end_date IS NOT NULL AND ann_date IS NOT NULL
                ) t WHERE rn = 1
            """)
            self.con.execute("CREATE INDEX IF NOT EXISTS idx_dividend ON dividend_prep(ts_code, end_date_int)")
            cnt = self.con.execute("SELECT COUNT(*) FROM dividend_prep").fetchone()[0]
            logger.info(f"     dividend_prep: {cnt:,}行")
        except Exception as e:
            logger.warning(f"     dividend 预处理失败: {e}")

        # ============================================================
        # 8. 预处理 fina_cashflow_vip（去重 + LPAD 排序键 + 扩展列）
        # ============================================================
        logger.info("  8. 预处理 fina_cashflow_vip...")
        try:
            self.con.execute("""
                CREATE OR REPLACE TABLE fina_cashflow_vip_prep AS
                SELECT * FROM (
                    SELECT
                        ts_code,
                        end_date,
                        ann_date,
                        f_ann_date,
                        CAST(end_date AS INTEGER) AS end_date_int,
                        CAST(ann_date AS INTEGER) AS ann_date_int,
                        CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                        LPAD(REPLACE(end_date, '-', ''), 8, '0') || '|' ||
                        LPAD(REPLACE(ann_date, '-', ''), 8, '0') || '|' ||
                        LPAD(REPLACE(f_ann_date, '-', ''), 8, '0') AS sort_key_str,
                        COALESCE(CAST(n_cashflow_act AS DOUBLE), 0.0) AS n_cashflow_act,
                        COALESCE(CAST(net_profit AS DOUBLE), 0.0) AS net_profit,
                        COALESCE(CAST(free_cashflow AS DOUBLE), 0.0) AS free_cashflow,
                        COALESCE(CAST(c_recp_borrow AS DOUBLE), 0.0) AS c_recp_borrow,
                        COALESCE(CAST(c_prepay_amt_borr AS DOUBLE), 0.0) AS c_prepay_amt_borr,
                        COALESCE(CAST(c_recp_cap_contrib AS DOUBLE), 0.0) AS c_recp_cap_contrib,
                        ROW_NUMBER() OVER (
                            PARTITION BY ts_code, end_date
                            ORDER BY ann_date DESC
                        ) AS rn
                    FROM fina_cashflow_vip
                    WHERE end_date IS NOT NULL AND ann_date IS NOT NULL AND f_ann_date IS NOT NULL
                ) t WHERE rn = 1
            """)
            cnt = self.con.execute("SELECT COUNT(*) FROM fina_cashflow_vip_prep").fetchone()[0]
            logger.info(f"     fina_cashflow_vip_prep: {cnt:,}行 (增强列: borrow/capex/cf)")
            self.con.execute("CREATE INDEX IF NOT EXISTS idx_cashflow_vip ON fina_cashflow_vip_prep(ts_code, end_date_int)")
        except Exception as e:
            logger.warning(f"     fina_cashflow_vip 预处理失败: {e}")

        # ============================================================
        # 9. 预处理 fina_balancesheet_vip（去重 + LPAD 排序键）
        # ============================================================
        logger.info("  9. 预处理 fina_balancesheet_vip...")
        try:
            self.con.execute("""
                CREATE OR REPLACE TABLE fina_balancesheet_vip_prep AS
                SELECT * FROM (
                    SELECT
                        ts_code,
                        end_date,
                        ann_date,
                        f_ann_date,
                        CAST(end_date AS INTEGER) AS end_date_int,
                        CAST(ann_date AS INTEGER) AS ann_date_int,
                        CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                        LPAD(REPLACE(end_date, '-', ''), 8, '0') || '|' ||
                        LPAD(REPLACE(ann_date, '-', ''), 8, '0') || '|' ||
                        LPAD(REPLACE(f_ann_date, '-', ''), 8, '0') AS sort_key_str,
                        COALESCE(CAST(accounts_receiv AS DOUBLE), 0.0) AS accounts_receiv,
                        COALESCE(CAST(goodwill AS DOUBLE), 0.0) AS goodwill,
                        COALESCE(CAST(total_liab AS DOUBLE), 0.0) AS total_liab,
                        COALESCE(CAST(total_assets AS DOUBLE), 1.0) AS total_assets,
                        ROW_NUMBER() OVER (
                            PARTITION BY ts_code, end_date
                            ORDER BY ann_date DESC
                        ) AS rn
                    FROM fina_balancesheet_vip
                    WHERE end_date IS NOT NULL AND ann_date IS NOT NULL AND f_ann_date IS NOT NULL
                ) t WHERE rn = 1
            """)
            cnt = self.con.execute("SELECT COUNT(*) FROM fina_balancesheet_vip_prep").fetchone()[0]
            logger.info(f"     fina_balancesheet_vip_prep: {cnt:,}行")
            self.con.execute("CREATE INDEX IF NOT EXISTS idx_balance_vip ON fina_balancesheet_vip_prep(ts_code, end_date_int)")
        except Exception as e:
            logger.warning(f"     fina_balancesheet_vip 预处理失败: {e}")

        # ============================================================
        # 10. income_exp_sorted（扩展列：ebit/ebitda/total_cogs/basic_eps/sell_exp/admin_exp/fin_exp/rd_exp）
        # ============================================================
        logger.info("  10. 创建 income_exp_sorted...")
        self.con.execute(f"""
            CREATE OR REPLACE TABLE income_exp_sorted AS
            SELECT
                ts_code,
                CAST(end_date AS INTEGER) AS end_date_int,
                CAST(ann_date AS INTEGER) AS ann_date_int,
                CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                COALESCE(CAST(n_income_attr_p AS DOUBLE), 0.0) AS net_profit,
                COALESCE(CAST(revenue AS DOUBLE), 0.0) AS revenue,
                COALESCE(CAST(operate_profit AS DOUBLE), 0.0) AS operate_profit,
                COALESCE(CAST(ebit AS DOUBLE), 0.0) AS ebit,
                COALESCE(CAST(ebitda AS DOUBLE), 0.0) AS ebitda,
                COALESCE(CAST(total_cogs AS DOUBLE), 0.0) AS total_cogs,
                COALESCE(CAST(basic_eps AS DOUBLE), 0.0) AS basic_eps,
                COALESCE(CAST(sell_exp AS DOUBLE), 0.0) AS sell_exp,
                COALESCE(CAST(admin_exp AS DOUBLE), 0.0) AS admin_exp,
                COALESCE(CAST(fin_exp AS DOUBLE), 0.0) AS fin_exp,
                COALESCE(CAST(rd_exp AS DOUBLE), 0.0) AS rd_exp,
                LPAD(CAST(end_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(ann_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(f_ann_date AS VARCHAR), 8, '0') AS sort_key_str
            FROM read_parquet('{income_pattern}')
            WHERE CAST(report_type AS INTEGER) IN (1, 2, 3, 4)
            ORDER BY ts_code, sort_key_str DESC
        """)
        logger.info(f"     income_exp_sorted: {self.con.execute('SELECT COUNT(*) FROM income_exp_sorted').fetchone()[0]:,}行")

        # ============================================================
        # 11. fina_ind_full_sorted（扩展列：gross_margin/netprofit_margin/extra_item/q_gr_yoy/q_profit_qoq/profit_to_gr/fcff_ps/fa_turn/assets_to_eqt/or_yoy/assets_yoy/equity_yoy/dt_netprofit_yoy/op_yoy/bps_yoy/longdeb_to_debt/ocf_to_debt 等）
        # ============================================================
        logger.info("  11. 创建 fina_ind_full_sorted...")
        self.con.execute(f"""
            CREATE OR REPLACE TABLE fina_ind_full_sorted AS
            SELECT
                ts_code,
                CAST(end_date AS INTEGER) AS end_date_int,
                CAST(ann_date AS INTEGER) AS ann_date_int,
                COALESCE(CAST(roa AS DOUBLE), 0.0) AS roa,
                COALESCE(CAST(roe_yoy AS DOUBLE), 0.0) AS roe_yoy,
                COALESCE(CAST(q_roe AS DOUBLE), 0.0) AS q_roe,
                COALESCE(CAST(grossprofit_margin AS DOUBLE), 0.0) AS grossprofit_margin,
                COALESCE(CAST(gross_margin AS DOUBLE), 0.0) AS gross_margin,
                COALESCE(CAST(netprofit_margin AS DOUBLE), 0.0) AS netprofit_margin,
                COALESCE(CAST(extra_item AS DOUBLE), 0.0) AS extra_item,
                COALESCE(CAST(q_sales_yoy AS DOUBLE), 0.0) AS q_gr_yoy,
                COALESCE(CAST(q_op_qoq AS DOUBLE), 0.0) AS q_profit_qoq,
                COALESCE(CAST(profit_to_gr AS DOUBLE), 0.0) AS profit_to_gr,
                COALESCE(CAST(fcff_ps AS DOUBLE), 0.0) AS fcff_ps,
                COALESCE(CAST(fa_turn AS DOUBLE), 0.0) AS fa_turn,
                COALESCE(CAST(assets_to_eqt AS DOUBLE), 0.0) AS assets_to_eqt,
                COALESCE(CAST(or_yoy AS DOUBLE), 0.0) AS or_yoy,
                COALESCE(CAST(assets_yoy AS DOUBLE), 0.0) AS assets_yoy,
                COALESCE(CAST(eqt_yoy AS DOUBLE), 0.0) AS equity_yoy,
                COALESCE(CAST(eqt_yoy AS DOUBLE), 0.0) AS eqt_yoy,
                COALESCE(CAST(dt_netprofit_yoy AS DOUBLE), 0.0) AS dt_netprofit_yoy,
                COALESCE(CAST(op_yoy AS DOUBLE), 0.0) AS op_yoy,
                COALESCE(CAST(bps_yoy AS DOUBLE), 0.0) AS bps_yoy,
                COALESCE(CAST(longdeb_to_debt AS DOUBLE), 0.0) AS longdeb_to_debt,
                COALESCE(CAST(ocf_to_debt AS DOUBLE), 0.0) AS ocf_to_debt,
                COALESCE(CAST(debt_to_assets AS DOUBLE), 0.0) AS debt_to_assets,
                COALESCE(CAST(current_ratio AS DOUBLE), 0.0) AS current_ratio,
                COALESCE(CAST(quick_ratio AS DOUBLE), 0.0) AS quick_ratio,
                COALESCE(CAST(cash_ratio AS DOUBLE), 0.0) AS cash_ratio,
                COALESCE(CAST(assets_turn AS DOUBLE), 0.0) AS assets_turn,
                COALESCE(CAST(tr_yoy AS DOUBLE), 0.0) AS tr_yoy,
                COALESCE(CAST(netprofit_yoy AS DOUBLE), 0.0) AS netprofit_yoy,
                COALESCE(CAST(eps AS DOUBLE), 0.0) AS eps,
                COALESCE(CAST(bps AS DOUBLE), 0.0) AS bps,
                COALESCE(CAST(ocfps AS DOUBLE), 0.0) AS ocfps,
                COALESCE(CAST(cfps AS DOUBLE), 0.0) AS cfps,
                COALESCE(CAST(roe_dt AS DOUBLE), 0.0) AS roe_dt,
                COALESCE(CAST(roic AS DOUBLE), 0.0) AS roic,
                COALESCE(CAST(roe_yearly AS DOUBLE), 0.0) AS roe_yearly,
                COALESCE(CAST(ar_turn AS DOUBLE), 0.0) AS ar_turn,
                COALESCE(CAST(ca_turn AS DOUBLE), 0.0) AS ca_turn,
                LPAD(CAST(end_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(ann_date AS VARCHAR), 8, '0') AS sort_key_str
            FROM read_parquet('{fina_indicator_pattern}')
            ORDER BY ts_code, sort_key_str DESC
        """)
        logger.info(f"     fina_ind_full_sorted: {self.con.execute('SELECT COUNT(*) FROM fina_ind_full_sorted').fetchone()[0]:,}行")

        # ============================================================
        # 12. finabal_full_sorted（扩展列：lt_borr/bond_payable/inventories/st_borr/notes_payable/total_cur_assets/total_cur_liab/fix_assets/intan_assets/total_hldr_eqy_exc_min_int）
        # ============================================================
        logger.info("  12. 创建 finabal_full_sorted...")
        self.con.execute(f"""
            CREATE OR REPLACE TABLE finabal_full_sorted AS
            SELECT
                ts_code,
                CAST(end_date AS INTEGER) AS end_date_int,
                CAST(ann_date AS INTEGER) AS ann_date_int,
                CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                COALESCE(CAST(total_cur_assets AS DOUBLE), 0.0) AS total_cur_assets,
                COALESCE(CAST(total_cur_liab AS DOUBLE), 0.0) AS total_cur_liab,
                COALESCE(CAST(total_liab AS DOUBLE), 0.0) AS total_liab,
                COALESCE(CAST(total_assets AS DOUBLE), 1.0) AS total_assets,
                COALESCE(CAST(total_hldr_eqy_exc_min_int AS DOUBLE), 0.0) AS total_hldr_eqy_exc_min_int,
                COALESCE(CAST(goodwill AS DOUBLE), 0.0) AS goodwill,
                COALESCE(CAST(intan_assets AS DOUBLE), 0.0) AS intan_assets,
                COALESCE(CAST(fix_assets AS DOUBLE), 0.0) AS fix_assets,
                COALESCE(CAST(accounts_receiv AS DOUBLE), 0.0) AS accounts_receiv,
                COALESCE(CAST(lt_borr AS DOUBLE), 0.0) AS lt_borr,
                COALESCE(CAST(bond_payable AS DOUBLE), 0.0) AS bond_payable,
                COALESCE(CAST(inventories AS DOUBLE), 0.0) AS inventories,
                COALESCE(CAST(st_borr AS DOUBLE), 0.0) AS st_borr,
                COALESCE(CAST(notes_payable AS DOUBLE), 0.0) AS notes_payable,
                LPAD(CAST(end_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(ann_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(f_ann_date AS VARCHAR), 8, '0') AS sort_key_str
            FROM read_parquet('{finabal_pattern}')
            ORDER BY ts_code, sort_key_str DESC
        """)
        logger.info(f"     finabal_full_sorted: {self.con.execute('SELECT COUNT(*) FROM finabal_full_sorted').fetchone()[0]:,}行")

        # ============================================================
        # 13. finacf_full_sorted（扩展列：net_profit_cf/n_cashflow_act/free_cashflow/capex/c_recp_borrow/c_recp_cap_contrib/prov_depr_assets/lt_amort_deferred_exp）
        # ============================================================
        logger.info("  13. 创建 finacf_full_sorted...")
        self.con.execute(f"""
            CREATE OR REPLACE TABLE finacf_full_sorted AS
            SELECT
                ts_code,
                CAST(end_date AS INTEGER) AS end_date_int,
                CAST(ann_date AS INTEGER) AS ann_date_int,
                LPAD(CAST(end_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(ann_date AS VARCHAR), 8, '0') AS sort_key_str,
                COALESCE(CAST(net_profit AS DOUBLE), 0.0) AS net_profit_cf,
                COALESCE(CAST(n_cashflow_act AS DOUBLE), 0.0) AS n_cashflow_act,
                COALESCE(CAST(free_cashflow AS DOUBLE), 0.0) AS free_cashflow,
                COALESCE(CAST(c_pay_acq_const_fiolta AS DOUBLE), 0.0) AS capex,
                COALESCE(CAST(c_recp_borrow AS DOUBLE), 0.0) AS c_recp_borrow,
                COALESCE(CAST(c_recp_cap_contrib AS DOUBLE), 0.0) AS c_recp_cap_contrib,
                COALESCE(CAST(prov_depr_assets AS DOUBLE), 0.0) AS prov_depr_assets,
                COALESCE(CAST(lt_amort_deferred_exp AS DOUBLE), 0.0) AS lt_amort_deferred_exp
            FROM read_parquet('{finacf_pattern}')
            ORDER BY ts_code, sort_key_str DESC
        """)
        logger.info(f"     finacf_full_sorted: {self.con.execute('SELECT COUNT(*) FROM finacf_full_sorted').fetchone()[0]:,}行")

        # ============================================================
        # 14. income_ttm_prep（TTM预聚合表，供9个TTM因子高效使用）
        # ============================================================
        logger.info("  14. 创建 income_ttm_prep...")
        self.con.execute(f"""
            CREATE OR REPLACE TABLE income_ttm_prep AS
            SELECT
                ts_code,
                end_date,
                CAST(end_date AS INTEGER) AS end_date_int,
                CAST(ann_date AS INTEGER) AS ann_date_int,
                CAST(f_ann_date AS INTEGER) AS f_ann_date_int,
                LPAD(CAST(end_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(ann_date AS VARCHAR), 8, '0') || '|' ||
                LPAD(CAST(f_ann_date AS VARCHAR), 8, '0') AS sort_key_str,
                COALESCE(CAST(revenue AS DOUBLE), 0.0) AS revenue,
                COALESCE(CAST(total_cogs AS DOUBLE), 0.0) AS total_cogs,
                COALESCE(CAST(revenue AS DOUBLE), 0.0) - COALESCE(CAST(total_cogs AS DOUBLE), 0.0) AS gross_profit,
                COALESCE(CAST(operate_profit AS DOUBLE), 0.0) AS operate_profit,
                COALESCE(CAST(n_income_attr_p AS DOUBLE), 0.0) AS net_profit,
                COALESCE(CAST(total_profit AS DOUBLE), 0.0) AS total_profit,
                COALESCE(CAST(income_tax AS DOUBLE), 0.0) AS income_tax,
                COALESCE(CAST(ebit AS DOUBLE), 0.0) AS ebit,
                COALESCE(CAST(ebitda AS DOUBLE), 0.0) AS ebitda,
                ROW_NUMBER() OVER (
                    PARTITION BY ts_code, end_date
                    ORDER BY ann_date DESC, f_ann_date DESC
                ) AS rn
            FROM read_parquet('{income_pattern}')
            WHERE end_date IS NOT NULL AND ann_date IS NOT NULL AND f_ann_date IS NOT NULL
              AND CAST(report_type AS INTEGER) IN (1, 2, 3, 4)
        """)
        self.con.execute("DELETE FROM income_ttm_prep WHERE rn != 1")
        self.con.execute("ALTER TABLE income_ttm_prep DROP COLUMN rn")
        cnt = self.con.execute("SELECT COUNT(*) FROM income_ttm_prep").fetchone()[0]
        logger.info(f"     income_ttm_prep: {cnt:,}行")

        logger.info("✅ 财务数据预处理完成 + 扩展排序表创建完成")

    def _post_process_yoy_factors(self, df: pd.DataFrame) -> pd.DataFrame:
        """Post-processing 计算 YOY 因子"""
        if df.empty:
            return df
        yoy_cols = ['YOY_QUARTER_NP', 'YOY_QUARTER_OR', 'YOY_QUARTER_OP']
        has_yoy = all(col in df.columns and df[col].notna().any() for col in yoy_cols)
        if has_yoy:
            logger.info("  YOY 因子已由 SQL 计算，跳过 post-processing")
            return df
        logger.info("  Post-processing YOY 因子...")
        return df

    def _get_factor_sql_templates(self, start_dt: str, end_dt: str, factor_names=None) -> dict:
        """获取因子SQL模板（从配置文件读取）"""
        if factor_names is None:
            factor_names = get_factor_names(enabled_only=True)
        factor_sqls = {}
        for name in factor_names:
            config = get_factor_config(name)
            if config is None:
                logger.warning(f"因子 '{name}' 不存在于配置中，跳过")
                continue
            if not config.get('enabled', True):
                logger.info(f"因子 '{name}' 已禁用，跳过")
                continue
            from datetime import datetime, timedelta
            dt_start = datetime.strptime(start_dt, '%Y%m%d')
            start_dt_20d = (dt_start - timedelta(days=30)).strftime('%Y%m%d')
            start_dt_60d = (dt_start - timedelta(days=90)).strftime('%Y%m%d')
            start_dt_90d = (dt_start - timedelta(days=95)).strftime('%Y%m%d')
            start_dt_2y = (dt_start - timedelta(days=740)).strftime('%Y%m%d')
            sql = config['sql_template'].format(
                start_dt=start_dt,
                end_dt=end_dt,
                start_dt_20d=start_dt_20d,
                start_dt_60d=start_dt_60d,
                start_dt_90d=start_dt_90d,
                start_dt_2y=start_dt_2y,
            )
            factor_sqls[name] = sql
        logger.info(f"从配置加载 {len(factor_sqls)} 个因子")
        return factor_sqls

    def calculate_factor(self, factor_name: str, sql: str):
        """计算单个因子"""
        logger.info(f"  计算 {factor_name}...")
        t0 = datetime.now()
        try:
            df = self.con.execute(sql).fetchdf()
            elapsed = (datetime.now() - t0).total_seconds()
            if len(df) > 0:
                logger.info(f"  ✅ {factor_name}: {len(df):,}行, 耗时{elapsed:.2f}s")
                output_path = self.output_dir / f'{factor_name}.parquet'
                df.to_parquet(output_path, index=False)
                del df
                return True
            else:
                logger.warning(f"  ⚠️ {factor_name}: 0行")
                return False
        except Exception as e:
            logger.error(f"  ❌ {factor_name} 失败: {e}")
            return False

    def run(self, start_date: str, end_date: str, factor_names=None,
              parallel: bool = True, n_workers: int = None):
        """
        批量计算因子（默认多进程并行）

        Args:
            parallel: True=多进程并行（默认，推荐）, False=串行（调试用）
            n_workers: 并行进程数，默认=CPU核心数，上限16
        """
        if parallel:
            # 默认路径：走多进程（复用 run_process_pool 的优化A共享DB逻辑）
            return self.run_process_pool(start_date, end_date, factor_names, n_workers)

        # ── 串行路径（调试用）───────────────────────────────────────────────
        if factor_names is None:
            total_factors = len(get_factor_names(enabled_only=True))
            factor_desc = "所有启用的因子"
        else:
            total_factors = len(factor_names)
            factor_desc = f"指定的 {total_factors} 个因子"

        logger.info(f"\n{'='*60}")
        logger.info(f"DuckDB因子引擎v5 - 配置化因子生成（串行模式）")
        logger.info(f"计算区间: {start_date} ~ {end_date}")
        logger.info(f"因子集合: {factor_desc}")
        logger.info(f"{'='*60}")

        start_dt = start_date.replace('-', '')
        end_dt = end_date.replace('-', '')

        factor_sqls = self._get_factor_sql_templates(start_dt, end_dt, factor_names)
        logger.info(f"\n开始计算 {len(factor_sqls)} 个因子...")

        total_start = datetime.now()
        computed_factors = []

        for i, (factor_name, sql) in enumerate(factor_sqls.items(), 1):
            logger.info(f"[{i}/{len(factor_sqls)}] {factor_name}")
            success = self.calculate_factor(factor_name, sql)
            if success:
                computed_factors.append(factor_name)

        total_elapsed = (datetime.now() - total_start).total_seconds()
        logger.info(f"\n{'='*60}")
        logger.info(f"✅ 计算完成！")
        logger.info(f"成功: {len(computed_factors)}/{len(factor_sqls)} 个因子")
        logger.info(f"总耗时: {total_elapsed:.1f}秒")
        logger.info(f"平均: {total_elapsed/len(factor_sqls):.2f}秒/因子")
        logger.info(f"{'='*60}")

        if len(computed_factors) > 0:
            self._merge_factors_duckdb(computed_factors)

        return computed_factors

    def _merge_factors_duckdb(self, factor_names: list):
        """使用 DuckDB SQL JOIN 合并所有因子 parquet 文件"""
        import time, os, glob as glob_module
        merge_start = time.time()
        BATCH_SIZE = 8
        logger.info(f"\n合并所有因子（渐进式 DuckDB SQL JOIN）...")
        logger.info(f"  待合并因子: {factor_names}")
        output_path = self.output_dir / 'factors_all.parquet'
        output_path_str = str(output_path).replace('\\', '/')

        for fname in factor_names:
            pq_file = self.output_dir / f'{fname}.parquet'
            if not pq_file.exists():
                raise FileNotFoundError(f"因子文件不存在: {pq_file}")
            size_mb = os.path.getsize(pq_file) / 1024 / 1024
            logger.info(f"    {fname}: {size_mb:.1f} MB")

        if len(factor_names) <= BATCH_SIZE:
            self._merge_batch(factor_names, output_path)
            return

        batch_files = []
        for batch_start in range(0, len(factor_names), BATCH_SIZE):
            batch = factor_names[batch_start: batch_start + BATCH_SIZE]
            batch_idx = batch_start // BATCH_SIZE + 1
            batch_path = self.output_dir / f'_batch_{batch_idx}.parquet'
            batch_files.append(str(batch_path).replace('\\', '/'))
            logger.info(f"\n  处理批次 {batch_idx}/{(len(factor_names) + BATCH_SIZE - 1) // BATCH_SIZE}: {batch}")
            self._merge_batch(batch, batch_path)

        logger.info(f"\n  最终合并 {len(batch_files)} 个批次文件...")
        self._merge_batch_files(batch_files, output_path)

        for bf in batch_files:
            bf_path = Path(bf)
            if bf_path.exists():
                bf_path.unlink()
                logger.info(f"    清理中间文件: {bf_path.name}")

        if output_path.exists():
            output_size = os.path.getsize(output_path)
            logger.info(f"  最终输出大小: {output_size / 1024 / 1024:.1f} MB")
            result_count = self.con.execute(
                f"SELECT COUNT(*) FROM read_parquet('{output_path_str}')"
            ).fetchone()[0]
            logger.info(f"  结果行数: {result_count:,}")

        merge_elapsed = time.time() - merge_start
        logger.info(f"\n✅ 渐进式合并完成，耗时: {merge_elapsed:.2f}秒")

    def _merge_batch(self, factor_names: list, output_path: Path):
        """合并一批因子到单个 parquet 文件"""
        import os
        output_path_str = str(output_path).replace('\\', '/')
        first = factor_names[0]
        rest = factor_names[1:]
        first_pq_path = str(self.output_dir / f'{first}.parquet').replace('\\', '/')
        # 聚合列用 ANY_VALUE 代替 GROUP BY（避免列名冲突 + 处理重复行）
        first_agg = f"ANY_VALUE({first}) AS {first}"
        from_clause = f"(SELECT ts_code, trade_date, {first_agg} FROM read_parquet('{first_pq_path}') GROUP BY ts_code, trade_date) t0"
        join_clauses = []
        for i, fname in enumerate(rest, 1):
            alias = f"t{i}"
            pq_path = str(self.output_dir / f'{fname}.parquet').replace('\\', '/')
            join_clauses.append(
                f"LEFT JOIN ("
                f"SELECT ts_code, trade_date, ANY_VALUE({fname}) AS {fname} FROM read_parquet('{pq_path}') GROUP BY ts_code, trade_date"
                f") {alias} "
                f"ON {alias}.ts_code = t0.ts_code AND {alias}.trade_date = t0.trade_date"
            )
        select_cols = [f"t0.{first}"] + [f"t{i}.{fname}" for i, fname in enumerate(rest, 1)]
        select_clause = 't0.ts_code, t0.trade_date, ' + ', '.join(select_cols)
        join_clause = '\n'.join(join_clauses)
        sql = f"COPY (SELECT {select_clause} FROM {from_clause} {join_clause}) TO '{output_path_str}' (FORMAT PARQUET)"
        try:
            self.con.execute(sql)
        except Exception as e:
            logger.error(f"  ❌ 批次合并失败: {e}")
            raise
        if not output_path.exists() or os.path.getsize(output_path) == 0:
            raise ValueError(f"批次合并输出文件为空: {output_path}")
        size = os.path.getsize(output_path) / 1024 / 1024
        logger.info(f"    批次完成: {len(factor_names)}个因子 -> {output_path.name} ({size:.1f} MB)")

    def _merge_batch_files(self, batch_files: list, output_path: Path):
        """合并多个批次文件为一个最终文件"""
        import os
        output_path_str = str(output_path).replace('\\', '/')
        first = batch_files[0]
        rest = batch_files[1:]
        first_cols = self.con.execute(f"SELECT * FROM read_parquet('{first}') LIMIT 0").fetchdf().columns.tolist()
        first_extra = [c for c in first_cols if c not in ('ts_code', 'trade_date')]
        first_agg = ', '.join([f"ANY_VALUE({c}) AS {c}" for c in first_extra])
        from_clause = f"(SELECT ts_code, trade_date, {first_agg} FROM read_parquet('{first}') GROUP BY ts_code, trade_date) t0"
        select_cols = list(first_extra)
        join_clauses = []
        for i, fpath in enumerate(rest, 1):
            alias = f"t{i}"
            sample_cols = self.con.execute(f"SELECT * FROM read_parquet('{fpath}') LIMIT 0").fetchdf().columns.tolist()
            extra_cols = [c for c in sample_cols if c not in ('ts_code', 'trade_date')]
            for col in extra_cols:
                select_cols.append(f"{alias}.{col}")
            agg = ', '.join([f"ANY_VALUE({c}) AS {c}" for c in extra_cols])
            join_clauses.append(
                f"LEFT JOIN ("
                f"SELECT ts_code, trade_date, {agg} FROM read_parquet('{fpath}') GROUP BY ts_code, trade_date"
                f") {alias} ON {alias}.ts_code = t0.ts_code AND {alias}.trade_date = t0.trade_date"
            )
        select_clause = 't0.ts_code, t0.trade_date, ' + ', '.join(select_cols)
        join_clause = '\n'.join(join_clauses)
        sql = f"COPY (SELECT {select_clause} FROM {from_clause} {join_clause}) TO '{output_path_str}' (FORMAT PARQUET)"
        try:
            self.con.execute(sql)
        except Exception as e:
            logger.error(f"  ❌ 批次文件最终合并失败: {e}")
            raise
        if not output_path.exists() or os.path.getsize(output_path) == 0:
            raise ValueError(f"最终合并输出文件为空: {output_path}")


    def compute(self, start_date: str, end_date: str, factor_names: list = None) -> "pd.DataFrame":
        """
        计算因子并返回宽表 DataFrame（内存返回，不写文件）。

        Args:
            start_date: 起始日期 (YYYYMMDD 或 YYYY-MM-DD)
            end_date: 截止日期
            factor_names: 因子列表（None=全部启用因子）

        Returns:
            DataFrame: ts_code, trade_date, factor1, factor2, ...（宽表）
        """
        start_dt = start_date.replace('-', '')
        end_dt = end_date.replace('-', '')

        from .config import get_factor_names
        if factor_names is None:
            factor_names = get_factor_names(enabled_only=True)

        factor_sqls = self._get_factor_sql_templates(start_dt, end_dt, factor_names)

        results = {}
        for fname, sql in factor_sqls.items():
            try:
                df = self.con.execute(sql).fetchdf()
                if df is not None and len(df) > 0:
                    id_vars = ['ts_code', 'trade_date']
                    value_cols = [c for c in df.columns if c not in id_vars]
                    if value_cols:
                        results[fname] = df.set_index(id_vars)[value_cols[0]]
            except Exception as e:
                logger.warning(f"因子 {fname} 计算失败: {e}")

        if not results:
            return pd.DataFrame(columns=['ts_code', 'trade_date'])

        result = pd.DataFrame(results).reset_index()
        # 重新排序列
        cols = ['ts_code', 'trade_date'] + list(results.keys())
        return result[cols]

    def compute_long(self, start_date: str, end_date: str, factor_names: list = None) -> "pd.DataFrame":
        """
        计算因子并返回长表 DataFrame（内存返回）。

        Returns:
            DataFrame: ts_code, trade_date, factor_name, factor_value（长表）
        """
        df_wide = self.compute(start_date, end_date, factor_names)
        if df_wide.empty or len(df_wide.columns) <= 2:
            return pd.DataFrame(columns=['ts_code', 'trade_date', 'factor_name', 'factor_value'])

        id_vars = ['ts_code', 'trade_date']
        value_vars = [c for c in df_wide.columns if c not in id_vars]
        return df_wide.melt(
            id_vars=id_vars, value_vars=value_vars,
            var_name='factor_name', value_name='factor_value'
        ).dropna(subset=['factor_value'])

    def compute_single_date(self, trade_date: str, factor_names: list = None) -> "pd.DataFrame":
        """
        计算单个交易日的因子值（回测用）。

        Returns:
            DataFrame: index=ts_code, columns=因子名
        """
        df = self.compute(trade_date, trade_date, factor_names)
        if df.empty:
            return pd.DataFrame()
        return df.set_index('ts_code').drop(columns=['trade_date'], errors='ignore')

    def close(self):
        self.con.close()

    def run_fullrange_parallel(self, start_date: str, end_date: str, factor_names=None, n_workers=None):
        """
        多进程按因子并行（全范围SQL模式，推荐用于全年批量生成）
        策略：
        - 外层：按因子分片到 n_workers 个进程
        - 内层：每个进程内，顺序执行其因子列表
        - 每个因子使用全范围 SQL（DuckDB 窗口函数只扫描一次数据）
        - 这比 run_batch() 的逐日期重算快 10-50x（尤其是滚动窗口因子）
        """
        import os, time, math
        from duckdb_factor_engine.config import get_factor_names

        start_dt = start_date.replace('-', '')
        end_dt = end_date.replace('-', '')

        if factor_names is None:
            factor_names = get_factor_names(enabled_only=True)

        if n_workers is None:
            n_workers = min(os.cpu_count() or 8, 16)

        n_factors = len(factor_names)
        logger.info(f"\n{'='*60}")
        logger.info(f"DuckDB因子引擎v7 - 全范围SQL多进程并行")
        logger.info(f"计算区间: {start_date} ~ {end_date}")
        logger.info(f"因子数量: {n_factors}, 并行度: {n_workers}")
        logger.info(f"{'='*60}")

        batch_size = max(1, (n_factors + n_workers - 1) // n_workers)
        batches = []
        for i in range(n_workers):
            start_i = i * batch_size
            end_i = min(start_i + batch_size, n_factors)
            if start_i < n_factors:
                batches.append(factor_names[start_i:end_i])

        batch_sizes = [len(b) for b in batches if b]
        logger.info(f"因子分批: {batch_sizes}, 共 {sum(batch_sizes)} 个")

        t0 = time.time()
        child_pids = []

        for w, batch in enumerate(batches):
            if not batch:
                continue
            pid = os.fork()
            if pid == 0:
                try:
                    self._run_fullrange_batch(start_dt, end_dt, batch)
                    logger.info(f"  Worker {w} 完成: {len(batch)} 个因子")
                except Exception as e:
                    logger.error(f"  Worker {w} 失败: {e}")
                os._exit(0)
            else:
                child_pids.append(pid)
                logger.info(f"启动 Worker {w}: {len(batch)} 个因子, PID={pid}")

        for pid in child_pids:
            os.waitpid(pid, 0)

        compute_t = time.time() - t0
        logger.info(f"\n并行计算完成: {n_factors} 因子, 耗时 {compute_t:.1f}s")

        # 合并前先用 pandas 去重（处理因子 SQL 可能产生的重复行）
        all_factor_files = []
        for fname in factor_names:
            fpath = self.output_dir / f'{fname}.parquet'
            if fpath.exists() and os.path.getsize(fpath) > 100:
                df = pd.read_parquet(fpath)
                before = len(df)
                df_dedup = df.drop_duplicates(subset=['ts_code', 'trade_date'], keep='first')
                after = len(df_dedup)
                if before != after:
                    logger.info(f"  {fname}: 去重 {before} -> {after} ({before-after} 重复行移除)")
                df_dedup.to_parquet(fpath, index=False)
                all_factor_files.append(fname)

        if all_factor_files:
            merge_t0 = time.time()
            self._merge_factors_duckdb(all_factor_files)
            logger.info(f"合并耗时: {time.time()-merge_t0:.1f}s")

        total_t = time.time() - t0
        logger.info(f"✅ 全部完成，总耗时: {total_t:.1f}s ({total_t/60:.1f}分钟)")
        return all_factor_files

    def run_process_pool(self, start_date: str, end_date: str, factor_names=None, n_workers=None):
        """
        进程池版因子计算（多进程 + 连接复用）
        改进自 run_fullrange_parallel：每个Worker进程预先初始化连接，
        复用连接处理其负责的所有因子，避免每个因子重复初始化的开销。
        """
        import os, time, multiprocessing
        from duckdb_factor_engine.config import get_factor_names

        start_dt = start_date.replace('-', '')
        end_dt = end_date.replace('-', '')

        if factor_names is None:
            factor_names = get_factor_names(enabled_only=True)

        if n_workers is None:
            n_workers = min(os.cpu_count() or 8, 16)

        n_factors = len(factor_names)
        logger.info(f"\n{'='*60}")
        logger.info(f"DuckDB因子引擎v9 - 进程池连接复用")
        logger.info(f"计算区间: {start_date} ~ {end_date}")
        logger.info(f"因子数量: {n_factors}, 并行度: {n_workers} 进程")
        logger.info(f"{'='*60}")

        # 均分因子到各进程
        batch_size = max(1, (n_factors + n_workers - 1) // n_workers)
        batches = []
        for i in range(n_workers):
            start_i = i * batch_size
            end_i = min(start_i + batch_size, n_factors)
            if start_i < n_factors:
                batches.append(factor_names[start_i:end_i])
        batches = [b for b in batches if b]

        t0 = time.time()

        # ===== P2优化：主进程预处理财务表，导出给所有worker共享 =====
        import tempfile
        import duckdb
        prep_dir = os.path.join(tempfile.gettempdir(), 'duckdb_factor_engine_prep')
        prep_marker = os.path.join(prep_dir, '.ready')
        if not os.path.exists(prep_marker):
            logger.info(f"  [P2优化] 主进程预处理财务表...")
            t_prep = time.time()
            # v7.4 修复：使用 self._prepare_financial_tables_fixed() 而非 standalone 函数
            # standalone 函数只创建7个prep表；class method 创建全部扩展表（含 income_sorted 等）
            self._prepare_financial_tables_fixed()
            _export_prep_tables_to_parquet(self.con, prep_dir)
            # 创建标记文件
            with open(prep_marker, 'w') as f:
                f.write('ready')
            logger.info(f"  [P2优化] 预处理完成，耗时: {time.time()-t_prep:.1f}s -> {prep_dir}")
        else:
            logger.info(f"  [P2优化] 复用已有预处理: {prep_dir}")
        # =================================================================

        # 预计算：提前启动所有进程，传入相同init_args
        ctx = multiprocessing.get_context('fork')
        with ctx.Pool(processes=len(batches)) as pool:
            async_results = []
            for bid, batch in enumerate(batches):
                r = pool.apply_async(
                    _worker_process_batch,
                    args=(start_dt, end_dt, batch, str(self.data_dir), str(self.output_dir), bid, prep_dir)
                )
                async_results.append(r)

            for r in async_results:
                try:
                    names = r.get()
                    logger.info(f"  Worker 完成: {len(names)} 因子")
                except Exception as e:
                    logger.error(f"  Worker 失败: {e}")

        compute_t = time.time() - t0
        logger.info(f"\n并行计算完成: {n_factors} 因子, 耗时 {compute_t:.1f}s")

        # 去重 + 合并
        all_factor_files = []
        for fname in factor_names:
            fpath = self.output_dir / f'{fname}.parquet'
            if fpath.exists() and os.path.getsize(fpath) > 100:
                df = pd.read_parquet(fpath)
                before = len(df)
                df_dedup = df.drop_duplicates(subset=['ts_code', 'trade_date'], keep='first')
                after = len(df_dedup)
                if before != after:
                    logger.info(f"  {fname}: 去重 {before} -> {after}")
                df_dedup.to_parquet(fpath, index=False)
                all_factor_files.append(fname)

        if all_factor_files:
            merge_t0 = time.time()
            self._merge_factors_duckdb(all_factor_files)
            logger.info(f"合并耗时: {time.time()-merge_t0:.1f}s")

        total_t = time.time() - t0
        logger.info(f"✅ 全部完成，总耗时: {total_t:.1f}s ({total_t/60:.1f}分钟)")
        return all_factor_files

    def _run_fullrange_batch(self, start_dt: str, end_dt: str, factor_names: list):
        """
        子进程执行：对自己分到的因子列表，使用全范围SQL顺序执行每个因子。
        每个因子的 SQL 覆盖 start_dt ~ end_dt 全区间，DuckDB 窗口函数只扫描一次。
        """
        import time
        from duckdb_factor_engine.config import get_factor_config
        from datetime import datetime, timedelta

        logger.info(f"  Worker 处理 {len(factor_names)} 个因子...")

        t0 = time.time()
        computed = []

        for fname in factor_names:
            config = get_factor_config(fname)
            if config is None or not config.get('enabled', True):
                continue

            dt_start = datetime.strptime(start_dt, '%Y%m%d')
            start_dt_20d = (dt_start - timedelta(days=30)).strftime('%Y%m%d')
            start_dt_60d = (dt_start - timedelta(days=90)).strftime('%Y%m%d')
            start_dt_5d = (dt_start - timedelta(days=7)).strftime('%Y%m%d')
            start_dt_90d = (dt_start - timedelta(days=95)).strftime('%Y%m%d')
            start_dt_1y = (dt_start - timedelta(days=370)).strftime('%Y%m%d')
            start_dt_2y = (dt_start - timedelta(days=740)).strftime('%Y%m%d')
            start_dt_1m = dt_start.replace(day=1).strftime('%Y%m%d')

            try:
                sql = config['sql_template'].format(
                    start_dt=start_dt,
                    end_dt=end_dt,
                    start_dt_20d=start_dt_20d,
                    start_dt_60d=start_dt_60d,
                    start_dt_5d=start_dt_5d,
                    start_dt_90d=start_dt_90d,
                    start_dt_1y=start_dt_1y,
                    start_dt_2y=start_dt_2y,
                    start_dt_1m=start_dt_1m,
                )
                df = self.con.execute(sql).fetchdf()
                if len(df) > 0:
                    output_path = self.output_dir / f'{fname}.parquet'
                    if output_path.exists():
                        existing = self.con.execute(
                            f"SELECT * FROM read_parquet('{output_path}')"
                        ).fetchdf()
                        combined = existing.merge(df, on=['ts_code', 'trade_date'], how='outer')
                        combined.to_parquet(output_path, index=False)
                    else:
                        df.to_parquet(output_path, index=False)
                    computed.append(fname)
                del df
            except Exception as e:
                logger.warning(f"Worker-{worker_id} 因子 {fname} 计算失败: {e}")

        elapsed = time.time() - t0
        logger.info(f"  Worker 完成 {len(factor_names)} 因子, 耗时 {elapsed:.1f}s")



def test_small_sample():
    """小样本测试"""
    print("\n" + "="*60)
    print("小样本测试：v7.2修复版（2017-01-01 ~ 2017-01-10）")
    print("="*60)
    engine = FactorEngineV72(data_dir='./data', output_dir='./output/v72_test_small')
    results = engine.run('2017-01-01', '2017-01-10')
    engine.close()
    print(f"\n✅ 小样本测试完成！")


if __name__ == '__main__':
    test_small_sample()

# 别名 — BatchEngine 即 FactorEngineV72
BatchEngine = FactorEngineV72
